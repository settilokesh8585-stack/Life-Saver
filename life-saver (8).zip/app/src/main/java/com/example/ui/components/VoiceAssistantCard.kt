package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.ImmersiveActiveGreen
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings
import com.example.voice.BodyPartCategory
import com.example.voice.PendingVoiceAction
import com.example.voice.VoiceConversationState

private data class StateBadgeConfig(
    val label: String,
    val bg: Color,
    val border: Color,
    val text: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceAssistantCard(
    lang: Language,
    conversationState: VoiceConversationState,
    pendingAction: PendingVoiceAction?,
    identifiedCategory: BodyPartCategory?,
    isListening: Boolean,
    recognizedText: String,
    assistantFeedback: String,
    isServiceActive: Boolean,
    onToggleListen: () -> Unit,
    onConfirmAction: () -> Unit,
    onCancelAction: () -> Unit,
    onToggleService: () -> Unit,
    onSpeakPhrase: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val micScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.2f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_scale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("voice_assistant_card"),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, ImmersiveBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header with State badge & Wake Word
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEFF6FF))
                            .border(1.dp, Color(0xFFBFDBFE), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Voice Assistant",
                            tint = Color(0xFF1D4ED8),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (lang == Language.TELUGU) "లైఫ్ సేవర్ తో మాట్లాడండి" else "Talk to Life Saver",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = ImmersiveTextPrimary
                        )
                        Text(
                            text = if (lang == Language.TELUGU) "వాయిస్ అత్యవసర అసిస్టెంట్" else "Voice Emergency Assistant",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ImmersiveTextSecondary
                        )
                    }
                }

                // Dynamic Conversation State Pill Badge
                val badgeConfig = when (conversationState) {
                    VoiceConversationState.IDLE ->
                        StateBadgeConfig("STANDBY", Color(0xFFF1F5F9), Color(0xFFCBD5E1), Color(0xFF475569))
                    VoiceConversationState.WAKE ->
                        StateBadgeConfig("⚡ WAKE ACTIVE", Color(0xFFEFF6FF), Color(0xFF93C5FD), Color(0xFF1D4ED8))
                    VoiceConversationState.GREETING ->
                        StateBadgeConfig("👋 HELLO", Color(0xFFEFF6FF), Color(0xFF93C5FD), Color(0xFF1D4ED8))
                    VoiceConversationState.LISTENING ->
                        StateBadgeConfig("🔴 LISTENING...", Color(0xFFFEF2F2), Color(0xFFFCA5A5), Color(0xFFDC2626))
                    VoiceConversationState.UNDERSTANDING ->
                        StateBadgeConfig("🧠 UNDERSTANDING", Color(0xFFFDF4FF), Color(0xFFF0ABFC), Color(0xFF9333EA))
                    VoiceConversationState.WHAT_HAPPENED ->
                        StateBadgeConfig("👂 LISTENING DETAILS", Color(0xFFEFF6FF), Color(0xFF93C5FD), Color(0xFF1D4ED8))
                    VoiceConversationState.SAFETY_CHECK ->
                        StateBadgeConfig("🛡️ SAFETY CHECK", Color(0xFFFEF3C7), Color(0xFFFCD34D), Color(0xFFB45309))
                    VoiceConversationState.LOCATION_CHECK ->
                        StateBadgeConfig("📍 LOCATION CHECK", Color(0xFFEFF6FF), Color(0xFF93C5FD), Color(0xFF1D4ED8))
                    VoiceConversationState.PERSON_ALONE_CHECK ->
                        StateBadgeConfig("👤 CHECKING ASSISTANCE", Color(0xFFFEF3C7), Color(0xFFFCD34D), Color(0xFFB45309))
                    VoiceConversationState.BODY_AREA ->
                        StateBadgeConfig("🩺 BODY AREA", Color(0xFFFEF3C7), Color(0xFFFCD34D), Color(0xFFB45309))
                    VoiceConversationState.SYMPTOM_DETAILS ->
                        StateBadgeConfig("💬 SYMPTOMS", Color(0xFFFDF4FF), Color(0xFFF0ABFC), Color(0xFF9333EA))
                    VoiceConversationState.SEVERITY ->
                        StateBadgeConfig("⚖️ SEVERITY", Color(0xFFFEF2F2), Color(0xFFFCA5A5), Color(0xFFDC2626))
                    VoiceConversationState.DANGER_CHECK ->
                        StateBadgeConfig("⚠️ CHECKING SIGNS", Color(0xFFFEF2F2), Color(0xFFFCA5A5), Color(0xFFDC2626))
                    VoiceConversationState.NEARBY_HELP ->
                        StateBadgeConfig("🏥 NEARBY HELP", Color(0xFFECFDF5), Color(0xFF6EE7B7), Color(0xFF047857))
                    VoiceConversationState.EMERGENCY_ASSESSMENT ->
                        StateBadgeConfig("🚨 ASSESSING", Color(0xFFFEF3C7), Color(0xFFFCD34D), Color(0xFFB45309))
                    VoiceConversationState.ACTION_CONFIRMATION ->
                        StateBadgeConfig("⚠️ CONFIRMATION", Color(0xFFFFFBEB), Color(0xFFF59E0B), Color(0xFFB45309))
                    VoiceConversationState.ACTION_EXECUTION ->
                        StateBadgeConfig("⚡ CALLING / ACTION", Color(0xFFECFDF5), Color(0xFF6EE7B7), Color(0xFF047857))
                    VoiceConversationState.SPOKEN_FEEDBACK, VoiceConversationState.FOLLOW_UP ->
                        StateBadgeConfig("📢 GUIDANCE READY", Color(0xFFEFF6FF), Color(0xFF93C5FD), Color(0xFF1D4ED8))
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(badgeConfig.bg)
                        .border(1.dp, badgeConfig.border, RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = badgeConfig.label,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = badgeConfig.text
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Central Hero Voice Button Area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (isListening) Color(0xFFFEF2F2) else Color(0xFFF8FAFC))
                    .border(
                        1.5.dp,
                        if (isListening) Color(0xFFEF4444) else ImmersiveBorder,
                        RoundedCornerShape(22.dp)
                    )
                    .padding(vertical = 16.dp, horizontal = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Large Pulsing Microphone Button
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .scale(if (isListening) micScale else 1f)
                        .clip(CircleShape)
                        .background(if (isListening) Color(0xFFDC2626) else Color(0xFF1D4ED8))
                        .border(
                            4.dp,
                            if (isListening) Color(0xFFFCA5A5) else Color(0xFF93C5FD),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = onToggleListen,
                        modifier = Modifier
                            .size(80.dp)
                            .testTag("voice_mic_button"),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Hearing else Icons.Default.Mic,
                            contentDescription = "Microphone",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isListening) {
                        if (lang == Language.TELUGU) "🔴 వింటోంది... మాట్లాడండి" else "🔴 LISTENING... SPEAK NOW"
                    } else {
                        if (lang == Language.TELUGU) "🎤 లైఫ్ సేవర్ తో మాట్లాడండి" else "🎤 TALK TO LIFE SAVER"
                    },
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isListening) Color(0xFFDC2626) else ImmersiveTextPrimary,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = if (lang == Language.TELUGU)
                        "'లైఫ్ సేవర్' అనండి లేదా మీ అత్యవసర పరిస్థితిని చెప్పండి"
                    else
                        "Say 'Life Saver' or your emergency situation",
                    fontSize = 12.sp,
                    color = ImmersiveTextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // CRITICAL VOICE CONFIRMATION CARD (When in CONFIRMATION state)
            AnimatedVisibility(visible = (conversationState == VoiceConversationState.ACTION_CONFIRMATION || conversationState == VoiceConversationState.CONFIRMATION) && pendingAction != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFFFFFBEB))
                        .border(2.dp, Color(0xFFF59E0B), RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "⚠️", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == Language.TELUGU) "అత్యవసర నిర్ధారణ అవసరం" else "Emergency Action Confirmation",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF92400E)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val promptQuery = when (pendingAction) {
                        is PendingVoiceAction.CallEmergency ->
                            if (lang == Language.TELUGU)
                                "మీరు ${pendingAction.labelTe}కి కాల్ చేయాలనుకుంటున్నారా?"
                            else
                                "Would you like to call ${pendingAction.labelEn}?"
                        is PendingVoiceAction.TriggerSos ->
                            if (lang == Language.TELUGU)
                                "మీరు అత్యవసర ఎస్ఓఎస్ ప్రారంభించాలనుకుంటున్నారా?"
                            else
                                "Would you like to trigger Emergency SOS?"
                        is PendingVoiceAction.SendSosMessage ->
                            if (lang == Language.TELUGU)
                                "${pendingAction.targetName}కి ఎస్ఓఎస్ సందేశం పంపమంటారా?"
                            else
                                "Send emergency SOS SMS to ${pendingAction.targetName}?"
                        else ->
                            if (lang == Language.TELUGU) "చర్యను కొనసాగించమంటారా?" else "Confirm this action?"
                    }

                    Text(
                        text = promptQuery,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF78350F),
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (lang == Language.TELUGU)
                            "సమాధానం చెప్పండి: 'అవును' / 'వద్దు' లేదా క్రింద తాకండి"
                        else
                            "Say 'Yes' / 'No' or tap below:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF92400E)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // TWO HUGE ACCESSIBLE BUTTONS: YES (Green) & NO (Red)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // YES Button
                        Button(
                            onClick = onConfirmAction,
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .testTag("voice_confirm_yes_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Confirm",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (lang == Language.TELUGU) "అవును (కాల్)" else "YES (CALL)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                        }

                        // NO Button
                        Button(
                            onClick = onCancelAction,
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .testTag("voice_cancel_no_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Cancel",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (lang == Language.TELUGU) "వద్దు (రద్దు)" else "NO (CANCEL)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Real-time voice transcript & assistant feedback
            AnimatedVisibility(visible = recognizedText.isNotBlank() || assistantFeedback.isNotBlank()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFF8FAFC))
                        .border(1.5.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    if (recognizedText.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🗣️", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "\"$recognizedText\"",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0369A1)
                            )
                        }
                    }
                    if (assistantFeedback.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.Top) {
                            Text(text = "📢", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = assistantFeedback,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ImmersiveTextPrimary,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            // Natural Spoken Examples & Symptom Chips
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = if (lang == Language.TELUGU) "సహజంగా మాట్లాడండి లేదా తాకండి:" else "Speak naturally or tap any symptom:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = ImmersiveTextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            val emergencyChips = if (lang == Language.TELUGU) {
                listOf(
                    "🫁 శ్వాస ఆడట్లేదు" to "నాకు ఊపిరి తీసుకోవడం కష్టంగా ఉంది",
                    "❤️ ఛాతిలో నొప్పి" to "నాకు ఛాతిలో నొప్పి ఉంది",
                    "🧠 తల తిరుగుతోంది" to "నాకు తల తిరుగుతోంది",
                    "🦵 కాలు విరిగింది" to "నా కాలు విరిగింది",
                    "🩸 రక్తం వస్తోంది" to "నాకు రక్తం వస్తోంది",
                    "🩺 కడుపు నొప్పి" to "నాకు కడుపు నొప్పిగా ఉంది",
                    "🩹 కాలింది / మంట" to "నాకు మంటగా ఉంది",
                    "🚗 ప్రమాదం జరిగింది" to "నాకు ప్రమాదం జరిగింది",
                    "🚑 అంబులెన్స్ కావాలి" to "అంబులెన్స్ కావాలి",
                    "👮 పోలీసులు కావాలి" to "పోలీసులు కావాలి",
                    "🆘 సహాయం కావాలి" to "నాకు సహాయం కావాలి"
                )
            } else {
                listOf(
                    "🫁 Breathing Difficulty" to "difficulty breathing",
                    "❤️ Chest Pain" to "chest pain",
                    "🧠 Dizziness / Head" to "dizziness",
                    "🦵 Broken Leg" to "broken leg",
                    "🩸 Severe Bleeding" to "bleeding",
                    "🩺 Stomach Pain" to "stomach pain",
                    "🩹 Burns" to "burns",
                    "🚗 Road Accident" to "accident occurred",
                    "🚑 Need Ambulance" to "need ambulance",
                    "👮 Need Police" to "need police",
                    "🆘 Emergency Help" to "i need help"
                )
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                emergencyChips.forEach { (display, phrase) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF1F5F9))
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
                            .clickable {
                                onSpeakPhrase?.invoke(phrase)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = display,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveTextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Background Service Toggle Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = EmergencyStrings.backgroundServiceToggle(lang),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveTextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = EmergencyStrings.backgroundServiceDesc(lang),
                        fontSize = 11.sp,
                        color = ImmersiveTextSecondary,
                        lineHeight = 14.sp
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Switch(
                    checked = isServiceActive,
                    onCheckedChange = { onToggleService() },
                    modifier = Modifier.testTag("voice_service_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = ImmersiveActiveGreen,
                        uncheckedThumbColor = ImmersiveTextSecondary,
                        uncheckedTrackColor = Color(0xFFE2E8F0)
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Crucial Android OS privacy requirement display
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEFF6FF))
                    .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Notice",
                    tint = Color(0xFF1D4ED8),
                    modifier = Modifier
                        .size(16.dp)
                        .padding(top = 1.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = EmergencyStrings.osPrivacyNotice(lang),
                    fontSize = 11.sp,
                    color = Color(0xFF1E3A8A),
                    lineHeight = 14.sp
                )
            }
        }
    }
}
