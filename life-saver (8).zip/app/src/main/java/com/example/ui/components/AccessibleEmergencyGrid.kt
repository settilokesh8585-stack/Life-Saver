package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings

/**
 * Modern 3D-Style High-Accessibility Emergency Action Grid:
 * Features 6 prominent emergency cards designed for rapid recognition,
 * high contrast, and immediate accessibility even for non-literate or elderly users.
 *
 * 1. 🚑 Ambulance 108
 * 2. 🚓 Emergency / Police 112
 * 3. 🚒 Fire 101
 * 4. 🏥 Nearby Hospitals
 * 5. 💊 Medical Shops
 * 6. 📍 My Location
 */
@Composable
fun AccessibleEmergencyGrid(
    lang: Language,
    address: String?,
    onDialAmbulance: () -> Unit,
    onDialPolice: () -> Unit,
    onDialFire: () -> Unit,
    onOpenHospitals: () -> Unit,
    onMyLocationClick: () -> Unit,
    onOpenMedicalShops: () -> Unit = {},
    onVoiceHelpClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Row 1: Ambulance 108 & Police 112
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            AccessibleEmergencyActionCard(
                number = "108",
                label = EmergencyStrings.ambulanceLabel(lang),
                subLabel = EmergencyStrings.tapToCall(lang),
                icon = Icons.Default.LocalHospital,
                gradientColors = listOf(Color(0xFF059669), Color(0xFF047857)),
                iconTint = Color(0xFF059669),
                iconBgColor = Color(0xFFECFDF5),
                borderColor = Color(0xFFA7F3D0),
                numberColor = Color(0xFF065F46),
                testTag = "dial_108_button",
                modifier = Modifier.weight(1f),
                onClick = onDialAmbulance
            )

            AccessibleEmergencyActionCard(
                number = "112",
                label = EmergencyStrings.policeLabel(lang),
                subLabel = EmergencyStrings.tapToCall(lang),
                icon = Icons.Default.Security,
                gradientColors = listOf(Color(0xFF1D4ED8), Color(0xFF1E3A8A)),
                iconTint = Color(0xFF1D4ED8),
                iconBgColor = Color(0xFFEFF6FF),
                borderColor = Color(0xFFBFDBFE),
                numberColor = Color(0xFF1E40AF),
                testTag = "dial_112_button",
                modifier = Modifier.weight(1f),
                onClick = onDialPolice
            )
        }

        // Row 2: Fire 101 & Hospital (Nearby Maps)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            AccessibleEmergencyActionCard(
                number = "101",
                label = EmergencyStrings.fireLabel(lang),
                subLabel = EmergencyStrings.tapToCall(lang),
                icon = Icons.Default.LocalFireDepartment,
                gradientColors = listOf(Color(0xFFEA580C), Color(0xFFC2410C)),
                iconTint = Color(0xFFEA580C),
                iconBgColor = Color(0xFFFFF7ED),
                borderColor = Color(0xFFFED7AA),
                numberColor = Color(0xFFC2410C),
                testTag = "dial_101_button",
                modifier = Modifier.weight(1f),
                onClick = onDialFire
            )

            AccessibleEmergencyActionCard(
                number = null,
                badgeTag = "HOSPITALS",
                label = EmergencyStrings.hospitalLabel(lang),
                subLabel = EmergencyStrings.nearbyMaps(lang),
                icon = Icons.Default.MedicalServices,
                gradientColors = listOf(Color(0xFF0284C7), Color(0xFF0369A1)),
                iconTint = Color(0xFF0284C7),
                iconBgColor = Color(0xFFF0F9FF),
                borderColor = Color(0xFFBAE6FD),
                numberColor = Color(0xFF0369A1),
                testTag = "nearby_hospitals_button",
                modifier = Modifier.weight(1f),
                onClick = onOpenHospitals
            )
        }

        // Row 3: Medical Shops & My Location
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            AccessibleEmergencyActionCard(
                number = null,
                badgeTag = "PHARMACY",
                label = EmergencyStrings.medicalShopsLabel(lang),
                subLabel = EmergencyStrings.medicalShopsDesc(lang),
                icon = Icons.Default.LocalPharmacy,
                gradientColors = listOf(Color(0xFF0D9488), Color(0xFF0F766E)),
                iconTint = Color(0xFF0D9488),
                iconBgColor = Color(0xFFF0FDFA),
                borderColor = Color(0xFF99F6E4),
                numberColor = Color(0xFF115E59),
                testTag = "nearby_medical_shops_button",
                modifier = Modifier.weight(1f),
                onClick = onOpenMedicalShops
            )

            AccessibleEmergencyActionCard(
                number = null,
                badgeTag = "GPS",
                label = EmergencyStrings.myLocationLabel(lang),
                subLabel = EmergencyStrings.findMyLocation(lang),
                icon = Icons.Default.LocationOn,
                gradientColors = listOf(Color(0xFFD97706), Color(0xFFB45309)),
                iconTint = Color(0xFFD97706),
                iconBgColor = Color(0xFFFFFBEB),
                borderColor = Color(0xFFFDE68A),
                numberColor = Color(0xFFB45309),
                testTag = "my_location_action_button",
                modifier = Modifier.weight(1f),
                onClick = onMyLocationClick
            )
        }
    }
}

@Composable
private fun AccessibleEmergencyActionCard(
    number: String?,
    label: String,
    subLabel: String,
    icon: ImageVector,
    gradientColors: List<Color>,
    iconTint: Color,
    iconBgColor: Color,
    borderColor: Color,
    numberColor: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    badgeTag: String? = null,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor.copy(alpha = 0.85f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp, pressedElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.White,
                            iconBgColor.copy(alpha = 0.35f)
                        )
                    )
                )
                .padding(horizontal = 12.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Modern 3D-feel circular badge with gradient border & soft inner depth
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(iconBgColor, Color.White)
                        )
                    )
                    .border(2.5.dp, borderColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconTint,
                    modifier = Modifier.size(34.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Number if helpline, or prominent title
            if (number != null) {
                Text(
                    text = number,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = numberColor,
                    textAlign = TextAlign.Center
                )
            } else if (badgeTag != null) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(iconBgColor)
                        .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeTag,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = numberColor,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = label,
                fontSize = if (number != null) 15.sp else 16.sp,
                fontWeight = FontWeight.Bold,
                color = ImmersiveTextPrimary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subLabel,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = ImmersiveTextSecondary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
