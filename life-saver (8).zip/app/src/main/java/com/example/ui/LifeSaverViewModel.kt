package com.example.ui

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.OfflineMapsRepository
import com.example.data.PreferencesManager
import com.example.location.LocationHelper
import com.example.model.GpsLocationState
import com.example.model.Language
import com.example.model.MedicalProfile
import com.example.model.OfflineMapArea
import com.example.model.UserEmergencyProfile
import com.example.service.VoiceEmergencyService
import com.example.util.BatteryMonitor
import com.example.util.BatteryState
import com.example.util.EmergencyActions
import com.example.util.EmergencyAlarmManager
import com.example.util.EmergencyStrings
import com.example.util.ShakeDetector
import com.example.voice.BodyPartCategory
import com.example.voice.PendingVoiceAction
import com.example.voice.VoiceConversationState
import com.example.voice.VoiceTriageEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class LifeSaverViewModel(application: Application) : AndroidViewModel(application), RecognitionListener, TextToSpeech.OnInitListener {

    private val prefsManager = PreferencesManager(application)
    private val locationHelper = LocationHelper(application)
    private val alarmManager = EmergencyAlarmManager(application)
    private val batteryMonitor = BatteryMonitor(application)
    private val offlineMapsRepo = OfflineMapsRepository(application)

    val userProfile: StateFlow<UserEmergencyProfile> = prefsManager.userProfile
    val language: StateFlow<Language> = prefsManager.language
    val isVoiceServiceActive: StateFlow<Boolean> = prefsManager.isVoiceServiceActive
    val isShakeSosEnabled: StateFlow<Boolean> = prefsManager.isShakeSosEnabled
    val isAudioFeedbackEnabled: StateFlow<Boolean> = prefsManager.isAudioFeedbackEnabled

    val batteryState: StateFlow<BatteryState> = batteryMonitor.batteryState
    val isInternetAvailable: StateFlow<Boolean> = offlineMapsRepo.isInternetAvailable
    val cachedMapAreas: StateFlow<List<OfflineMapArea>> = offlineMapsRepo.cachedAreas
    val selectedMapArea: StateFlow<OfflineMapArea?> = offlineMapsRepo.selectedArea

    private val _isCachingArea = MutableStateFlow(false)
    val isCachingArea: StateFlow<Boolean> = _isCachingArea.asStateFlow()

    private val _locationState = MutableStateFlow(GpsLocationState(isLoading = true))
    val locationState: StateFlow<GpsLocationState> = _locationState.asStateFlow()

    private val _sosCountdown = MutableStateFlow<Int?>(null)
    val sosCountdown: StateFlow<Int?> = _sosCountdown.asStateFlow()

    private val _shakeSosCountdown = MutableStateFlow<Int?>(null)
    val shakeSosCountdown: StateFlow<Int?> = _shakeSosCountdown.asStateFlow()

    private val _isOfflineSmsDialogOpen = MutableStateFlow(false)
    val isOfflineSmsDialogOpen: StateFlow<Boolean> = _isOfflineSmsDialogOpen.asStateFlow()

    private val _isMedicalEditDialogOpen = MutableStateFlow(false)
    val isMedicalEditDialogOpen: StateFlow<Boolean> = _isMedicalEditDialogOpen.asStateFlow()

    private val _isSirenActive = MutableStateFlow(false)
    val isSirenActive: StateFlow<Boolean> = _isSirenActive.asStateFlow()

    private val _isStrobeActive = MutableStateFlow(false)
    val isStrobeActive: StateFlow<Boolean> = _isStrobeActive.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _conversationState = MutableStateFlow(VoiceConversationState.IDLE)
    val conversationState: StateFlow<VoiceConversationState> = _conversationState.asStateFlow()

    private val _conversationSession = MutableStateFlow(com.example.voice.EmergencyConversationSession())
    val conversationSession: StateFlow<com.example.voice.EmergencyConversationSession> = _conversationSession.asStateFlow()

    private val _pendingVoiceAction = MutableStateFlow<PendingVoiceAction?>(null)
    val pendingVoiceAction: StateFlow<PendingVoiceAction?> = _pendingVoiceAction.asStateFlow()

    private val _identifiedCategory = MutableStateFlow<BodyPartCategory?>(null)
    val identifiedCategory: StateFlow<BodyPartCategory?> = _identifiedCategory.asStateFlow()

    private val _voiceRecognizedText = MutableStateFlow("")
    val voiceRecognizedText: StateFlow<String> = _voiceRecognizedText.asStateFlow()

    private val _voiceFeedback = MutableStateFlow("")
    val voiceFeedback: StateFlow<String> = _voiceFeedback.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private var countdownJob: Job? = null
    private var shakeCountdownJob: Job? = null
    private var inAppSpeechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private val shakeDetector = ShakeDetector(application) {
        triggerShakeSos()
    }

    // Compute ready-to-share message automatically whenever profile, location or language changes
    val readySosMessage: StateFlow<String> = combine(
        language,
        userProfile,
        locationState
    ) { lang, profile, loc ->
        EmergencyStrings.buildSosMessage(
            lang = lang,
            myPhone = profile.myPhoneNumber,
            latitude = loc.latitude,
            longitude = loc.longitude,
            address = loc.address,
            timestamp = loc.timestampFormatted.ifBlank { "Just now" },
            customNote = profile.customNote,
            medicalProfile = profile.medicalProfile
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ""
    )

    private val voiceCommandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val command = intent?.getStringExtra(VoiceEmergencyService.EXTRA_DETECTED_TEXT) ?: return
            _voiceRecognizedText.value = command
            handleVoiceCommand(command)
        }
    }

    init {
        tts = TextToSpeech(application, this)
        batteryMonitor.startMonitoring()
        refreshLocation()

        alarmManager.isAudioEnabled = isAudioFeedbackEnabled.value
        shakeDetector.setEnabled(isShakeSosEnabled.value)

        val filter = IntentFilter(VoiceEmergencyService.ACTION_VOICE_COMMAND_DETECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            application.registerReceiver(voiceCommandReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            application.registerReceiver(voiceCommandReceiver, filter)
        }
    }

    fun toggleLanguage() {
        val next = if (language.value == Language.ENGLISH) Language.TELUGU else Language.ENGLISH
        prefsManager.setLanguage(next)
        updateTtsLocale(next)
        speak(EmergencyStrings.speakLanguageSwitched(next))
    }

    fun setLanguage(lang: Language) {
        prefsManager.setLanguage(lang)
        updateTtsLocale(lang)
        speak(EmergencyStrings.speakLanguageSwitched(lang))
    }

    fun saveProfile(profile: UserEmergencyProfile) {
        prefsManager.saveProfile(profile)
        _isSettingsOpen.value = false
    }

    fun saveMedicalProfile(medicalProfile: MedicalProfile) {
        prefsManager.saveMedicalProfile(medicalProfile)
    }

    fun setShakeSosEnabled(enabled: Boolean) {
        prefsManager.setShakeSosEnabled(enabled)
        shakeDetector.setEnabled(enabled)
    }

    fun setAudioFeedbackEnabled(enabled: Boolean) {
        prefsManager.setAudioFeedbackEnabled(enabled)
        alarmManager.isAudioEnabled = enabled
    }

    fun startShakeDetection() {
        if (isShakeSosEnabled.value) {
            shakeDetector.startListening()
        }
    }

    fun stopShakeDetection() {
        shakeDetector.stopListening()
    }

    fun triggerShakeSos() {
        if (_shakeSosCountdown.value != null || _sosCountdown.value != null) return
        shakeCountdownJob?.cancel()
        _shakeSosCountdown.value = 5

        speak(
            if (language.value == Language.TELUGU) "ఫోన్ షేక్ గుర్తించబడింది. 5 సెకన్లలో ఎస్ఓఎస్."
            else "Phone shake detected. Emergency SOS triggering in 5 seconds."
        )

        shakeCountdownJob = viewModelScope.launch {
            for (sec in 5 downTo 1) {
                _shakeSosCountdown.value = sec
                delay(1000)
            }
            _shakeSosCountdown.value = null
            executeSosNow(getApplication<Application>())
        }
    }

    fun cancelShakeSos() {
        shakeCountdownJob?.cancel()
        shakeCountdownJob = null
        _shakeSosCountdown.value = null
        speak(
            if (language.value == Language.TELUGU) "షేక్ ఎస్ఓఎస్ రద్దు చేయబడింది"
            else "Shake SOS cancelled"
        )
    }

    fun openOfflineSmsDialog() {
        _isOfflineSmsDialogOpen.value = true
    }

    fun closeOfflineSmsDialog() {
        _isOfflineSmsDialogOpen.value = false
    }

    fun openMedicalEditDialog() {
        _isMedicalEditDialogOpen.value = true
    }

    fun closeMedicalEditDialog() {
        _isMedicalEditDialogOpen.value = false
    }

    fun sendOfflineSms(context: Context, recipientPhone: String, message: String) {
        _isOfflineSmsDialogOpen.value = false
        EmergencyActions.sendSmsToContact(context, recipientPhone, message)
    }

    fun setSettingsOpen(open: Boolean) {
        _isSettingsOpen.value = open
    }

    fun refreshLocation(speakFeedback: Boolean = false) {
        viewModelScope.launch {
            _locationState.value = _locationState.value.copy(isLoading = true, errorMessage = null)
            val updated = locationHelper.getCurrentLocation()
            _locationState.value = updated
            if (updated.latitude != null && updated.longitude != null) {
                offlineMapsRepo.recalculateDistances(updated.latitude, updated.longitude)
            }
            if (speakFeedback) {
                val feedback = if (updated.isValid) {
                    if (language.value == Language.TELUGU) "మీ లొకేషన్ తీసుకున్నాను."
                    else "Acquired your GPS location."
                } else {
                    if (language.value == Language.TELUGU) "లొకేషన్ అందుబాటులో లేదు. ఫోన్ GPS ఆన్ ఉందో చూడండి."
                    else "Location unavailable. Please check if phone GPS is turned on."
                }
                _voiceFeedback.value = feedback
                speak(feedback)
            }
        }
    }

    fun cacheCurrentArea(customName: String? = null) {
        viewModelScope.launch {
            _isCachingArea.value = true
            val loc = _locationState.value
            val lat = loc.latitude ?: 17.4399
            val lng = loc.longitude ?: 78.3908
            val addr = loc.address ?: "Current Location Area"

            delay(500) // Brief UI feedback
            offlineMapsRepo.cacheCurrentArea(
                latitude = lat,
                longitude = lng,
                address = addr,
                customName = customName
            )
            offlineMapsRepo.recalculateDistances(lat, lng)
            _isCachingArea.value = false

            speak(
                if (language.value == Language.TELUGU) "ప్రాంతం విజయవంతంగా ఆఫ్‌లైన్ కోసం సేవ్ చేయబడింది"
                else "Area cached successfully for offline use"
            )
        }
    }

    fun selectMapArea(areaId: String) {
        offlineMapsRepo.selectArea(areaId)
        val loc = _locationState.value
        offlineMapsRepo.recalculateDistances(loc.latitude, loc.longitude)
    }

    fun deleteMapArea(areaId: String) {
        offlineMapsRepo.deleteArea(areaId)
    }

    fun startSosCountdown(context: Context) {
        if (_sosCountdown.value != null) return
        countdownJob?.cancel()
        _sosCountdown.value = 5

        speak(EmergencyStrings.speakSosTriggered(language.value))

        countdownJob = viewModelScope.launch {
            for (sec in 5 downTo 1) {
                _sosCountdown.value = sec
                delay(1000)
            }
            _sosCountdown.value = null
            executeSosNow(context)
        }
    }

    fun cancelSosCountdown() {
        countdownJob?.cancel()
        countdownJob = null
        _sosCountdown.value = null
        speak(EmergencyStrings.speakSosCancelled(language.value))
    }

    fun executeSosNow(context: Context) {
        _sosCountdown.value = null
        // Trigger loud siren
        if (!_isSirenActive.value) {
            toggleSiren()
        }
        // Also trigger strobe
        if (!_isStrobeActive.value) {
            toggleStrobe()
        }

        val profile = userProfile.value
        val message = readySosMessage.value

        // If user has a primary emergency contact, send SMS
        if (profile.primaryContact.phone.isNotBlank()) {
            EmergencyActions.sendSmsToContact(
                context = context,
                phoneNumber = profile.primaryContact.phone,
                message = message
            )
        } else {
            // General share chooser
            EmergencyActions.shareSosMessage(context, message)
        }

        speak(
            if (language.value == Language.TELUGU) "అత్యవసర సందేశం పంపబడింది. సైరన్ మోగుతోంది."
            else "Emergency alert sent. Alarm is sounding."
        )
    }

    fun toggleSiren() {
        alarmManager.toggleSiren { isPlaying ->
            _isSirenActive.value = isPlaying
            speak(EmergencyStrings.speakSiren(language.value, isPlaying))
        }
    }

    fun toggleStrobe() {
        alarmManager.toggleStrobe { isPlaying ->
            _isStrobeActive.value = isPlaying
            speak(EmergencyStrings.speakStrobe(language.value, isPlaying))
        }
    }

    fun toggleVoiceService(context: Context) {
        val newState = !isVoiceServiceActive.value
        prefsManager.setVoiceServiceActive(newState)
        if (newState) {
            VoiceEmergencyService.start(context)
            speak(
                if (language.value == Language.TELUGU) "లైఫ్ సేవర్ వాయిస్ సర్వీస్ ఆన్ చేయబడింది"
                else "Life Saver voice service activated"
            )
        } else {
            VoiceEmergencyService.stop(context)
            speak(
                if (language.value == Language.TELUGU) "వాయిస్ సర్వీస్ ఆఫ్ చేయబడింది"
                else "Voice service stopped"
            )
        }
    }

    private fun vibrateTactile(patternMs: Long = 70) {
        try {
            val vibrator = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(patternMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(patternMs)
            }
        } catch (e: Exception) {
            // Ignore if device lacks vibrator
        }
    }

    fun startListeningInApp(context: Context) {
        if (_isListening.value) {
            stopListeningInApp()
            return
        }

        vibrateTactile(80)
        try {
            if (inAppSpeechRecognizer == null) {
                inAppSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(this@LifeSaverViewModel)
                }
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                val langTag = if (language.value == Language.TELUGU) "te-IN" else "en-US"
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(
                    RecognizerIntent.EXTRA_PROMPT,
                    if (language.value == Language.TELUGU) "నేను వింటున్నాను. ఏమైంది? నెమ్మదిగా చెప్పండి..." else "I am listening. What happened? Speak slowly..."
                )
            }

            _voiceRecognizedText.value = ""
            _conversationState.value = VoiceConversationState.LISTENING
            val feedback = if (language.value == Language.TELUGU) "నేను వింటున్నాను. ఏమైంది? నెమ్మదిగా చెప్పండి."
            else "I am listening. What happened? Speak slowly."
            _voiceFeedback.value = feedback
            _isListening.value = true

            inAppSpeechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isListening.value = false
            _conversationState.value = VoiceConversationState.IDLE
            _voiceFeedback.value = "Speech recognition error: ${e.message}"
        }
    }

    fun stopListeningInApp() {
        _isListening.value = false
        if (_conversationState.value == VoiceConversationState.LISTENING) {
            _conversationState.value = VoiceConversationState.IDLE
        }
        try {
            inAppSpeechRecognizer?.stopListening()
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun handleVoiceCommand(spokenText: String) {
        _voiceRecognizedText.value = spokenText
        _conversationState.value = VoiceConversationState.UNDERSTANDING
        vibrateTactile(50)
        val context = getApplication<Application>()

        val places = selectedMapArea.value?.places ?: emptyList()
        val turnResult = VoiceTriageEngine.processConversationTurn(
            spokenText = spokenText,
            session = _conversationSession.value,
            gpsLocationState = _locationState.value,
            cachedPlaces = places,
            defaultLang = language.value
        )

        _conversationSession.value = turnResult.updatedSession
        _conversationState.value = turnResult.updatedSession.currentStep
        _identifiedCategory.value = turnResult.identifiedCategory ?: turnResult.updatedSession.identifiedCategory
        _voiceFeedback.value = turnResult.spokenResponse
        _pendingVoiceAction.value = turnResult.pendingAction

        speak(turnResult.spokenResponse)

        if (turnResult.pendingAction != null && turnResult.updatedSession.currentStep == VoiceConversationState.ACTION) {
            confirmPendingVoiceAction(context)
        } else if (turnResult.shouldListenAgain) {
            viewModelScope.launch {
                delay(3200)
                if (!_isListening.value && _conversationState.value != VoiceConversationState.IDLE && _conversationState.value != VoiceConversationState.ACTION) {
                    startListeningInApp(context)
                }
            }
        }
    }

    fun confirmPendingVoiceAction(context: Context) {
        val action = _pendingVoiceAction.value ?: return
        _conversationState.value = VoiceConversationState.ACTION
        vibrateTactile(150)

        when (action) {
            is PendingVoiceAction.CallEmergency -> {
                val confirmVoice = if (language.value == Language.TELUGU) {
                    "${action.labelTe} కాల్ చేయబడుతోంది"
                } else {
                    "Calling ${action.labelEn}"
                }
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
                EmergencyActions.dialEmergency(context, action.number)
            }
            is PendingVoiceAction.CallContact -> {
                val confirmVoice = if (language.value == Language.TELUGU) {
                    "${action.contactName}కి కాల్ చేయబడుతోంది"
                } else {
                    "Calling ${action.contactName}"
                }
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
                EmergencyActions.dialEmergency(context, action.number)
            }
            is PendingVoiceAction.TriggerSos -> {
                val confirmVoice = if (language.value == Language.TELUGU) {
                    "అత్యవసర ఎస్ఓఎస్ ప్రారంభించబడుతోంది"
                } else {
                    "Triggering Emergency SOS"
                }
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
                startSosCountdown(context)
            }
            is PendingVoiceAction.SendSosMessage -> {
                EmergencyActions.sendSmsToContact(context, action.targetPhone, readySosMessage.value)
                val confirmVoice = if (language.value == Language.TELUGU) {
                    "${action.targetName}కి అత్యవసర ఎస్ఓఎస్ సందేశం పంపబడింది"
                } else {
                    "Emergency SOS message sent to ${action.targetName}"
                }
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
            }
            is PendingVoiceAction.OpenHospitalMaps -> {
                val confirmVoice = if (language.value == Language.TELUGU) "సమీప ఆసుపత్రులు తెరవబడుతున్నాయి" else "Opening nearby hospitals on maps"
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
                EmergencyActions.openNearbyHospitals(context, locationState.value.latitude, locationState.value.longitude)
            }
            is PendingVoiceAction.OpenMedicalShopsMaps -> {
                val confirmVoice = if (language.value == Language.TELUGU) "సమీప మెడికల్ షాపులు తెరవబడుతున్నాయి" else "Opening nearby medical shops on maps"
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
                EmergencyActions.openNearbyMedicalShops(context, locationState.value.latitude, locationState.value.longitude)
            }
            is PendingVoiceAction.OpenPoliceMaps -> {
                val confirmVoice = if (language.value == Language.TELUGU) "సమీప పోలీస్ స్టేషన్లు తెరవబడుతున్నాయి" else "Opening nearby police stations on maps"
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
                EmergencyActions.openNearbyPolice(context, locationState.value.latitude, locationState.value.longitude)
            }
            is PendingVoiceAction.OpenFireMaps -> {
                val confirmVoice = if (language.value == Language.TELUGU) "సమీప అగ్నిమాపక కేంద్రాలు తెరవబడుతున్నాయి" else "Opening nearby fire stations on maps"
                _voiceFeedback.value = confirmVoice
                speak(confirmVoice)
                EmergencyActions.openNearbyFire(context, locationState.value.latitude, locationState.value.longitude)
            }
            is PendingVoiceAction.RefreshGpsLocation -> {
                refreshLocation(speakFeedback = true)
            }
        }
        _pendingVoiceAction.value = null
        _conversationState.value = VoiceConversationState.SPOKEN_FEEDBACK
    }

    fun onAmbulanceTapped(context: Context) {
        val speech = if (language.value == Language.TELUGU)
            "ఇది అంబులెన్స్ సహాయం కోసం. 108కి కాల్ చేయడానికి సిద్ధంగా ఉన్నాను."
        else
            "This is for ambulance assistance. Ready to dial 108."
        speak(speech)
        EmergencyActions.dialEmergency(context, "108")
    }

    fun onPoliceTapped(context: Context) {
        val speech = if (language.value == Language.TELUGU)
            "ఇది పోలీస్ మరియు అత్యవసర సహాయం కోసం. 112కి కాల్ చేయాలా?"
        else
            "This is for police and emergency assistance. Dialing 112."
        speak(speech)
        EmergencyActions.dialEmergency(context, "112")
    }

    fun onFireTapped(context: Context) {
        val speech = if (language.value == Language.TELUGU)
            "ఇది ఫైర్ ఎమర్జెన్సీ కోసం. 101కి కాల్ చేయాలా?"
        else
            "This is for fire emergency assistance. Dialing 101."
        speak(speech)
        EmergencyActions.dialEmergency(context, "101")
    }

    fun onNearbyHospitalsTapped(context: Context) {
        val speech = if (language.value == Language.TELUGU)
            "దగ్గరలో అందుబాటులో ఉన్న ఆసుపత్రుల సమాచారాన్ని చూస్తున్నాను."
        else
            "Looking up available nearby hospital information."
        speak(speech)
        EmergencyActions.openNearbyHospitals(context, locationState.value.latitude, locationState.value.longitude)
    }

    fun onNearbyMedicalShopsTapped(context: Context) {
        val speech = if (language.value == Language.TELUGU)
            "దగ్గరలో అందుబాటులో ఉన్న మెడికల్ షాపుల సమాచారాన్ని చూస్తున్నాను."
        else
            "Looking up available nearby medical shops."
        speak(speech)
        EmergencyActions.openNearbyMedicalShops(context, locationState.value.latitude, locationState.value.longitude)
    }

    fun onLocationCardTapped() {
        val loc = locationState.value
        val speech = if (loc.isValid) {
            val addr = loc.address ?: "అక్షాంశం: ${loc.latitude}, రేఖాంశం: ${loc.longitude}"
            if (language.value == Language.TELUGU) "మీ లొకేషన్ సమాచారాన్ని చూస్తున్నాను. $addr" else "Checking your location information. $addr"
        } else {
            if (language.value == Language.TELUGU) "మీ లొకేషన్ సమాచారాన్ని చూస్తున్నాను. GPS ఆన్ చేసుకోండి." else "Checking your location. Please turn on GPS."
        }
        speak(speech)
        refreshLocation(speakFeedback = false)
    }

    fun cancelPendingVoiceAction() {
        _conversationState.value = VoiceConversationState.SPOKEN_FEEDBACK
        _pendingVoiceAction.value = null
        vibrateTactile(60)
        val cancelVoice = if (language.value == Language.TELUGU) {
            "రద్దు చేయబడింది. మీరు సురక్షితంగా ఉండండి."
        } else {
            "Action cancelled. Please stay safe."
        }
        _voiceFeedback.value = cancelVoice
        speak(cancelVoice)
    }

    fun speak(text: String) {
        if (!isAudioFeedbackEnabled.value) return
        val isTeluguText = VoiceTriageEngine.detectLanguage(text) == Language.TELUGU
        val targetLocale = if (isTeluguText) Locale("te", "IN") else Locale.US
        val res = tts?.setLanguage(targetLocale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            val fallbackTe = tts?.setLanguage(Locale("te"))
            if (fallbackTe == TextToSpeech.LANG_MISSING_DATA || fallbackTe == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "life_saver_in_app")
    }

    private fun updateTtsLocale(lang: Language) {
        val loc = if (lang == Language.TELUGU) Locale("te", "IN") else Locale.US
        val res = tts?.setLanguage(loc)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            updateTtsLocale(language.value)
        }
    }

    override fun onResults(results: Bundle?) {
        _isListening.value = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spoken = matches[0]
            _voiceRecognizedText.value = spoken
            handleVoiceCommand(spoken)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            _voiceRecognizedText.value = matches[0]
        }
    }

    override fun onError(error: Int) {
        _isListening.value = false
        val isTe = language.value == Language.TELUGU
        val message = when (error) {
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                if (isTe) "మీరు మాట్లాడవచ్చు. నేను వింటున్నాను." else "You can speak. I am listening."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                if (isTe) "మైక్రోఫోన్ అనుమతి అవసరం. దయచేసి సెట్టింగ్స్ లో అనుమతించండి." else "Microphone permission is required. Please allow it in settings."
            else ->
                if (isTe) "మీ మాట సరిగ్గా వినిపించలేదు. మళ్లీ నెమ్మదిగా చెప్పండి." else "Could not hear clearly. Please speak slowly again."
        }
        _voiceFeedback.value = message
        speak(message)
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {
        _isListening.value = false
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onCleared() {
        countdownJob?.cancel()
        shakeCountdownJob?.cancel()
        shakeDetector.stopListening()
        alarmManager.releaseAll()
        batteryMonitor.stopMonitoring()
        try {
            inAppSpeechRecognizer?.destroy()
        } catch (e: Exception) {
            // Ignore
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // Ignore
        }
        try {
            getApplication<Application>().unregisterReceiver(voiceCommandReceiver)
        } catch (e: Exception) {
            // Ignore
        }
        super.onCleared()
    }
}
