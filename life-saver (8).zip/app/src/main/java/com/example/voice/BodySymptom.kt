package com.example.voice

import com.example.model.Language

/**
 * Body-Symptom categories supported by the Voice Emergency Assistant
 */
enum class BodyPartCategory(val displayNameEn: String, val displayNameTe: String, val icon: String) {
    HEAD("Head", "తల", "🧠"),
    FACE("Face", "ముఖం", "🙂"),
    EYES("Eyes", "కళ్ళు", "👁️"),
    EARS("Ears", "చెవులు", "👂"),
    NOSE("Nose", "ముక్కు", "👃"),
    MOUTH("Mouth", "నోరు", "👄"),
    NECK("Neck", "మెడ", "🧣"),
    CHEST_HEART("Chest / Heart", "ఛాతీ / గుండె", "❤️"),
    LUNGS_BREATHING("Lungs / Breathing", "ఊపిరితిత్తులు / శ్వాస", "🫁"),
    STOMACH_ABDOMEN("Stomach / Abdomen", "కడుపు", "🩺"),
    BACK("Back / Spine", "వెన్నుముక", "🧍"),
    WAIST_PELVIS("Waist / Pelvis", "నడుము / పెల్విస్", "🩻"),
    SHOULDERS("Shoulders", "భుజాలు", "🥋"),
    ARMS_HANDS("Arms / Hands", "చేతులు", "💪"),
    FINGERS("Fingers", "చేతి వేళ్ళు", "🖐️"),
    LEGS_FEET("Legs / Feet", "కాళ్ళు", "🦵"),
    KNEES("Knees", "మోకాలు", "🦿"),
    FEET_TOES("Feet / Toes", "పాదాలు / కాలి వేళ్ళు", "🦶"),
    SKIN_WHOLE_BODY("Skin / Whole Body", "చర్మం / శరీరం", "🩹"),
    GENERAL_EMERGENCY("General Emergency", "సాధారణ అత్యవసరం", "🆘");

    companion object {
        val FACE_MOUTH: BodyPartCategory get() = FACE
    }
}

data class BodySymptom(
    val category: BodyPartCategory,
    val symptomNameEn: String,
    val symptomNameTe: String,
    val isCritical: Boolean,
    val recommendedServiceNumber: String? = null // e.g. "108" for Ambulance, "112" for Police/Universal
)
