package com.example.voice

import com.example.model.CachedEmergencyPlace
import com.example.model.GpsLocationState
import com.example.model.Language
import com.example.model.PlaceType
import java.util.Locale

data class TriageResult(
    val spokenResponse: String,
    val isEmergency: Boolean,
    val pendingAction: PendingVoiceAction? = null,
    val identifiedCategory: BodyPartCategory? = null,
    val detectedLanguage: Language = Language.ENGLISH,
    val isTriageQuestion: Boolean = false
)

data class ConversationTurnResult(
    val updatedSession: EmergencyConversationSession,
    val spokenResponse: String,
    val shouldListenAgain: Boolean,
    val isEmergency: Boolean = false,
    val pendingAction: PendingVoiceAction? = null,
    val identifiedCategory: BodyPartCategory? = null
)

object VoiceTriageEngine {

    /**
     * Detects if the utterance contains Telugu script or characteristic transliterated Telugu phrases.
     */
    fun detectLanguage(text: String): Language {
        for (char in text) {
            if (char in '\u0C00'..'\u0C7F') {
                return Language.TELUGU
            }
        }
        val lower = text.lowercase(Locale.ROOT)
        val teluguPhonetic = listOf(
            "naku", "undhi", "undi", "kavali", "jarigindi", "sahayam", "oppiri", "noppi",
            "ekkad", "ekkada", "cheppandi", "chala", "ibbandi", "emayindi", "vaddu"
        )
        if (teluguPhonetic.any { lower.contains(it) }) {
            return Language.TELUGU
        }
        return Language.ENGLISH
    }

    /**
     * Checks if spoken text is the Wake Phrase "Life Saver" or "లైఫ్ సేవర్"
     */
    fun isWakeWord(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        return lower.contains("life saver") || lower.contains("lifesaver") ||
                lower.contains("లైఫ్ సేవర్") || lower.contains("లైఫ్సేవర్") ||
                lower.contains("హలో లైఫ్ సేవర్") || lower.contains("hello life saver")
    }

    /**
     * Checks if spoken text expresses explicit confirmation (Yes / Call / Proceed)
     */
    fun isConfirmation(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        val yesKeywords = listOf(
            "అవును", "కాల్ చేయి", "చేయి", "చెయ్యి", "సరే", "అవునండి", "కాల్", "పిలవండి",
            "yes", "yeah", "yep", "call", "proceed", "sure", "ok", "okay", "confirm", "dial", "please call"
        )
        return yesKeywords.any { lower.contains(it) }
    }

    fun isConfirmationAffirmative(text: String): Boolean = isConfirmation(text)

    /**
     * Checks if spoken text expresses explicit cancellation / rejection (No / Don't / Cancel)
     */
    fun isCancellation(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        val noKeywords = listOf(
            "వద్దు", "వద్దండి", "ఆపు", "రద్దు", "చేయవద్దు", "వద్దు వద్దు", "వద్దులే",
            "no", "nope", "cancel", "stop", "don't", "dont", "never", "abort"
        )
        return noKeywords.any { lower.contains(it) }
    }

    fun isConfirmationNegative(text: String): Boolean = isCancellation(text)

    /**
     * Primary Triage Engine: Evaluates symptoms across all body areas and generates short, calm spoken guidance.
     * High-priority acute conditions (Snake bite, burns, heavy bleeding, chest pain, breathing difficulty)
     * are evaluated first to prevent false matching with generic body parts.
     */
    fun triageSymptom(spokenText: String, defaultLang: Language): TriageResult {
        val detectedLang = detectLanguage(spokenText).takeIf { it == Language.TELUGU } ?: defaultLang
        val lower = spokenText.lowercase(Locale.ROOT)

        // 1. POISONING / SNAKE BITE (Checked FIRST before legs/arms so "snake bit my leg" matches snake bite)
        if (lower.contains("పాము") || lower.contains("విషం") || lower.contains("snake") ||
            lower.contains("poison") || lower.contains("bite") || lower.contains("sting")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "పాము కాటు లేదా విషం విషయంలో రోగిని ప్రశాంతంగా, కదలకుండా ఉంచండి. గాయాన్ని కోయవద్దు లేదా కట్టవద్దు. మీరు వెంటనే 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Stay calm and keep still. Do not cut or tourniquet the bite. Would you like to call 108 Ambulance immediately?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.SKIN_WHOLE_BODY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 2. BURNS / FIRE / SCALDS
        if (lower.contains("మంటగా") || lower.contains("కాలింది") || lower.contains("మంటలు") ||
            lower.contains("burn") || lower.contains("fire") || lower.contains("scald")
        ) {
            val isFireCall = lower.contains("మంటలు") || lower.contains("fire")
            val targetNumber = if (isFireCall) "101" else "108"
            val targetLabelTe = if (isFireCall) "101 అగ్నిమాపక దళం" else "108 అంబులెన్స్"
            val targetLabelEn = if (isFireCall) "101 Fire Brigade" else "108 Ambulance"

            val response = if (detectedLang == Language.TELUGU) {
                "కాలిన భాగాన్ని వెంటనే 10 నిమిషాల పాటు చల్లని నీటితో కడగండి. మంచు లేదా నూనె రాయవద్దు. మీరు $targetLabelTe కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Cool the burn with cool running water for 10 minutes immediately. Never apply ice or oil. Would you like to call $targetLabelEn?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency(targetNumber, targetLabelTe, targetLabelEn),
                identifiedCategory = BodyPartCategory.SKIN_WHOLE_BODY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 3. SEVERE BLEEDING / CUTS / WOUNDS
        if (lower.contains("రక్తం") || lower.contains("గాయం") || lower.contains("bleed") ||
            lower.contains("cut") || lower.contains("wound")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "గాయంపై శుభ్రమైన గుడ్డతో లేదా వస్త్రంతో గట్టిగా ఒత్తిడి ఉంచండి. రక్తం ఆగకుండా ఉంటే అత్యవసరం. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Apply continuous firm pressure on the wound with a clean cloth. Do not remove it. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.SKIN_WHOLE_BODY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 4. LUNGS / BREATHING (Shortness of breath, choking, severe coughing)
        if (lower.contains("ఊపిరి") || lower.contains("శ్వాస") || lower.contains("breath") ||
            lower.contains("chok") || lower.contains("దగ్గు") || lower.contains("shortness of breath")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీకు శ్వాస తీసుకోవడంలో ఇబ్బంది ఉందని అర్థమైంది. ప్రశాంతంగా నిశ్శబ్దంగా కూర్చోండి. ఇది అత్యవసర పరిస్థితి కావచ్చు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "I understand you are having difficulty breathing. Please sit upright and stay calm. This may be an emergency. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.LUNGS_BREATHING,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 5. CHEST / HEART (Chest pain, pressure, palpitations)
        if (lower.contains("chest") || lower.contains("heart") || lower.contains("ఛాతి") ||
            lower.contains("ఛాతీ") || lower.contains("గుండె") || lower.contains("గుండె నొప్పి")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "ఛాతీ లేదా గుండె నొప్పి తీవ్రమైన హెచ్చరిక కావచ్చు. వెంటనే నిటారుగా కూర్చోండి, శ్రమ పడవద్దు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Chest pain can be a critical emergency. Please sit upright and rest immediately. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.CHEST_HEART,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 6. ACCIDENT / ROAD CRASH (Major accident, trauma, fall)
        if (lower.contains("accident") || lower.contains("crash") || lower.contains("ప్రమాదం") ||
            lower.contains("యాక్సిడెంట్") || lower.contains("పడిపోయాను") || lower.contains("fell down")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు సురక్షితంగా ఉన్నారా? గాయాలు ఉంటే మెడను కదల్చవద్దు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Are you in a safe spot? If injured, stay still and do not move the neck. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 7. FACE / STROKE (Facial droop, slurred speech)
        if (lower.contains("ముఖం వంకర") || lower.contains("మాట ముద్ద") || lower.contains("slurr") ||
            lower.contains("facial droop") || lower.contains("stroke") || lower.contains("పక్షవాతం")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "ముఖం వంకర లేదా మాట ముద్దబడటం పక్షవాతం హెచ్చరిక కావచ్చు. సమయం చాలా ముఖ్యం. మీరు వెంటనే 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Facial droop or speech difficulty may indicate a stroke. Every minute counts. Would you like to call 108 Ambulance immediately?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.FACE_MOUTH,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 8. HEAD (Headache, dizziness, unconsciousness, faint)
        if (lower.contains("తల తిరుగు") || lower.contains("తల నొప్పి") || lower.contains("స్పృహ") ||
            lower.contains("headache") || lower.contains("dizzy") || lower.contains("unconscious") ||
            lower.contains("faint") || lower.contains("confusion")
        ) {
            val isUnconscious = lower.contains("స్పృహ") || lower.contains("unconscious") || lower.contains("faint")
            val response = if (detectedLang == Language.TELUGU) {
                if (isUnconscious) {
                    "రోగి శ్వాస తీసుకుంటున్నారా చూడండి. మెడను అస్సలు కదల్చవద్దు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
                } else {
                    "తల తిరుగుడు లేదా తీవ్ర తలనొప్పి ఉంటే ప్రశాంతంగా పడుకోండి. నీరు నెమ్మదిగా తాగండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
                }
            } else {
                if (isUnconscious) {
                    "Check if the person is breathing. Do not move their neck. Would you like to call 108 Ambulance?"
                } else {
                    "Sit or lie down safely to prevent a fall. Would you like to call 108 Ambulance for assistance?"
                }
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.HEAD,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 9. LEGS / FEET (Fracture, severe pain, inability to walk, broken leg)
        if (lower.contains("కాలు విరిగింది") || lower.contains("కాలు") || lower.contains("విరిగింది") ||
            lower.contains("నడవలే") || lower.contains("fracture") || lower.contains("broken leg") ||
            lower.contains("leg") || lower.contains("foot") || lower.contains("bone") || lower.contains("మోకాలు")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "గాయపడిన కాలును బలవంతంగా కదల్చవద్దు. కాలు కింద దిండు లేదా మద్దతు ఉంచండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Do not move the injured leg or attempt to stand. Keep it supported and still. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.LEGS_FEET,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 10. ARMS / HANDS (Wrist pain, arm fracture, numbness)
        if (lower.contains("చేయి") || lower.contains("చేతులు") || lower.contains("మొద్దుబారి") ||
            lower.contains("arm") || lower.contains("hand") || lower.contains("wrist") || lower.contains("finger")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "గాయపడిన చేయిని సున్నితంగా పట్టుకోండి మరియు కదల్చవద్దు. రక్తం వస్తుంటే ఒత్తిడి ఉంచండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Support the injured arm gently and keep it still. Apply pressure if bleeding. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.ARMS_HANDS,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 11. STOMACH / ABDOMEN
        if (lower.contains("కడుపు నొప్పి") || lower.contains("కడుపు") || lower.contains("వాంతులు") ||
            lower.contains("stomach") || lower.contains("abdomen") || lower.contains("vomit")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "కడుపుపై ఎటువంటి ఒత్తిడి పెట్టవద్దు. విశ్రాంతిగా పడుకోండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Lie down comfortably and avoid pressure on your stomach. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.STOMACH_ABDOMEN,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 12. BACK / SPINE
        if (lower.contains("వెన్ను") || lower.contains("వెనుక") || lower.contains("నడుము") ||
            lower.contains("back") || lower.contains("spine")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "వెన్నుముక లేదా నడుము నొప్పితో రోగిని నేలపై కదలకుండా ఉంచండి. మెడను తిప్పవద్దు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Keep the back and spine completely still. Do not twist or bend. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.BACK,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 13. EYES / EARS
        if (lower.contains("కళ్ళు") || lower.contains("కన్ను") || lower.contains("eye") ||
            lower.contains("చెవి") || lower.contains("ear")
        ) {
            val isEye = lower.contains("కళ్ళ") || lower.contains("కన్ను") || lower.contains("eye")
            val cat = if (isEye) BodyPartCategory.EYES else BodyPartCategory.EARS
            val response = if (detectedLang == Language.TELUGU) {
                "కంటిని లేదా చెవిని నలపవద్దు లేదా వస్తువులతో గుచ్చవద్దు. శుభ్రమైన నీటితో సున్నితంగా కడగవచ్చు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Do not rub the eye or poke the ear. Keep it shielded. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = cat,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 14. DIRECT SERVICE INTENTS (Ambulance, Police, Fire, SOS)
        if (lower.contains("ambulance") || lower.contains("108") || lower.contains("అంబులెన్స్")) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        if (lower.contains("police") || lower.contains("112") || lower.contains("పోలీస్") || lower.contains("పోలీసులు")) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు 112 జాతీయ అత్యవసర పోలీసులకు కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Would you like to call 112 National Emergency Police?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("112", "112 జాతీయ అత్యవసరం", "112 National Emergency"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        if (lower.contains("fire") || lower.contains("101") || lower.contains("ఫైర్")) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు 101 అగ్నిమాపక దళానికి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Would you like to call 101 Fire Brigade?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("101", "101 అగ్నిమాపక దళం", "101 Fire Brigade"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 15. GENERAL HELP REQUEST ("నాకు సహాయం కావాలి", "i need help", "sos")
        if (lower.contains("సహాయం") || lower.contains("కాపాడండి") || lower.contains("help") || lower.contains("sos")) {
            val response = if (detectedLang == Language.TELUGU) {
                "నేను మీకు సహాయం చేయడానికి సిద్ధంగా ఉన్నాను. మీ సమస్య ఏమిటి? శ్వాస, ఛాతీ నొప్పి, గాయం, లేదా ప్రమాదమా? లేదా ఎస్ఓఎస్ ప్రారంభించమంటారా?"
            } else {
                "I am here to help you. What happened? Tell me your symptom: breathing, chest pain, bleeding, accident, or should I send SOS?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.TriggerSos,
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // Default friendly fallback
        val defaultReply = if (detectedLang == Language.TELUGU) {
            "మీ సమస్యను సహజంగా చెప్పండి: 'ఊపిరి ఆడట్లేదు', 'ఛాతిలో నొప్పి', 'ప్రమాదం జరిగింది', 'రక్తం వస్తోంది', లేదా 'అంబులెన్స్ కావాలి'."
        } else {
            "Please describe what you are feeling: 'difficulty breathing', 'chest pain', 'accident', 'bleeding', or say 'need ambulance'."
        }
        return TriageResult(
            spokenResponse = defaultReply,
            isEmergency = false,
            pendingAction = null,
            identifiedCategory = null,
            detectedLanguage = detectedLang,
            isTriageQuestion = false
        )
    }

    /**
     * Complete Multi-Turn Conversational Process:
     * Maintains human-like empathy, remembers conversation context across turns,
     * asks ONLY ONE focused question at a time, answers natural location queries
     * using real GPS / cached facilities without hallucinating, and verifies user confirmation.
     */
    fun processConversationTurn(
        spokenText: String,
        session: EmergencyConversationSession,
        gpsLocationState: GpsLocationState,
        cachedPlaces: List<CachedEmergencyPlace>,
        defaultLang: Language
    ): ConversationTurnResult {
        val detectedLang = detectLanguage(spokenText).takeIf { it == Language.TELUGU } ?: defaultLang
        val lower = spokenText.lowercase(Locale.ROOT).trim()
        val isTe = detectedLang == Language.TELUGU

        // --- 1. Wake word / Initial greeting ---
        if (isWakeWord(spokenText) || lower == "hello" || lower == "హలో" || (session.currentStep == VoiceConversationState.IDLE && lower.isEmpty())) {
            val greeting = if (isTe) {
                "నేను Life Saver. మీకు ఏమైంది? నెమ్మదిగా చెప్పండి. నేను వింటున్నాను."
            } else {
                "I am Life Saver. Tell me what is happening. Speak slowly, I am listening."
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.LISTENING,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, greeting)
                ),
                spokenResponse = greeting,
                shouldListenAgain = true,
                isEmergency = false
            )
        }

        // --- 2. If currently waiting for Confirmation of an emergency action ---
        if ((session.currentStep == VoiceConversationState.ACTION_CONFIRMATION || session.currentStep == VoiceConversationState.CONFIRMATION) && session.pendingAction != null) {
            if (isConfirmation(spokenText)) {
                val actionConfirm = when (val act = session.pendingAction) {
                    is PendingVoiceAction.CallEmergency -> if (isTe) "${act.labelTe} కాల్ చేయబడుతోంది" else "Calling ${act.labelEn} now"
                    is PendingVoiceAction.TriggerSos -> if (isTe) "అత్యవసర ఎస్ఓఎస్ ప్రారంభించబడుతోంది" else "Triggering Emergency SOS now"
                    is PendingVoiceAction.OpenHospitalMaps -> if (isTe) "సమీప ఆసుపత్రులు తెరవబడుతున్నాయి" else "Opening nearby hospitals"
                    is PendingVoiceAction.OpenMedicalShopsMaps -> if (isTe) "సమీప మెడికల్ షాపులు తెరవబడుతున్నాయి" else "Opening nearby medical shops"
                    is PendingVoiceAction.OpenPoliceMaps -> if (isTe) "సమీప పోలీస్ స్టేషన్లు తెరవబడుతున్నాయి" else "Opening nearby police stations"
                    is PendingVoiceAction.OpenFireMaps -> if (isTe) "సమీప ఫైర్ స్టేషన్లు తెరవబడుతున్నాయి" else "Opening nearby fire stations"
                    else -> if (isTe) "చర్య అమలు చేయబడుతోంది" else "Executing action"
                }
                return ConversationTurnResult(
                    updatedSession = session.copy(
                        currentStep = VoiceConversationState.ACTION_EXECUTION,
                        turnsCount = session.turnsCount + 1,
                        conversationHistory = session.conversationHistory + Pair(spokenText, actionConfirm)
                    ),
                    spokenResponse = actionConfirm,
                    shouldListenAgain = false,
                    isEmergency = true,
                    pendingAction = session.pendingAction
                )
            } else if (isCancellation(spokenText)) {
                val cancelReply = if (isTe) {
                    "సరే, కాల్ చేయడం లేదు. మీరు విశ్రాంతి తీసుకోండి. ఏదైనా ఇబ్బంది ఉంటే వెంటనే చెప్పండి."
                } else {
                    "Understood. Cancelling the call. Rest safely and let me know immediately if you feel unwell."
                }
                return ConversationTurnResult(
                    updatedSession = session.copy(
                        currentStep = VoiceConversationState.FOLLOW_UP,
                        pendingAction = null,
                        turnsCount = session.turnsCount + 1,
                        conversationHistory = session.conversationHistory + Pair(spokenText, cancelReply)
                    ),
                    spokenResponse = cancelReply,
                    shouldListenAgain = false,
                    isEmergency = false
                )
            }
        }

        // --- 3. Explicit Location and Nearby Facility Queries ---
        // Hospital queries
        if (lower.contains("hospital") || lower.contains("ఆసుపత్రి") || lower.contains("హాస్పిటల్") ||
            (lower.contains("nearest") && lower.contains("medical"))
        ) {
            val nearestHospital = cachedPlaces.filter { it.type == PlaceType.HOSPITAL }
                .minByOrNull { it.distanceKm }

            val response = if (nearestHospital != null && gpsLocationState.isValid) {
                if (isTe) {
                    "మీ దగ్గరలో ఉన్న ఆసుపత్రి ${nearestHospital.name}, సుమారుగా ${nearestHospital.distanceKm} కిలోమీటర్ల దూరంలో ఉంది. 108 అంబులెన్స్ కి కాల్ చేయాలా?"
                } else {
                    "The nearest available hospital is ${nearestHospital.name}, approximately ${nearestHospital.distanceKm} km away. Would you like to call 108 Ambulance?"
                }
            } else {
                if (isTe) {
                    "ప్రస్తుతం దగ్గరలోని ఆసుపత్రి సమాచారాన్ని ధృవీకరించలేకపోతున్నాను. 108 అంబులెన్స్ కి కాల్ చేయాలా?"
                } else {
                    "Current nearby hospital information cannot be verified without GPS. Would you like to call 108 Ambulance?"
                }
            }

            val action = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance")
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.ACTION_CONFIRMATION,
                    pendingAction = action,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false,
                pendingAction = action
            )
        }

        // Medical shop / Pharmacy queries
        if (lower.contains("medical shop") || lower.contains("pharmacy") || lower.contains("chemist") ||
            lower.contains("మెడికల్ షాప్") || lower.contains("మందులు")
        ) {
            val nearestPharmacy = cachedPlaces.filter { it.type == PlaceType.PHARMACY }
                .minByOrNull { it.distanceKm } ?: cachedPlaces.firstOrNull { it.type == PlaceType.HOSPITAL }

            val response = if (nearestPharmacy != null && gpsLocationState.isValid) {
                if (isTe) {
                    "మీ దగ్గరలో ఉన్న మెడికల్ షాప్ ${nearestPharmacy.name}, సుమారుగా ${nearestPharmacy.distanceKm} కిలోమీటర్ల దూరంలో ఉంది. మ్యాప్స్ తెరవమంటారా?"
                } else {
                    "The nearest available medical shop is ${nearestPharmacy.name}, approximately ${nearestPharmacy.distanceKm} km away. Would you like to open maps?"
                }
            } else {
                if (isTe) {
                    "ప్రస్తుతం దగ్గరలోని మెడికల్ షాపుల సమాచారాన్ని ధృవీకరించలేకపోతున్నాను. మ్యాప్స్ తెరవమంటారా?"
                } else {
                    "Current nearby pharmacy information cannot be verified without GPS. Would you like to open maps?"
                }
            }

            val action = PendingVoiceAction.OpenMedicalShopsMaps
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.ACTION_CONFIRMATION,
                    pendingAction = action,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false,
                pendingAction = action
            )
        }

        // Police station queries
        if (lower.contains("police station") || lower.contains("పోలీస్ స్టేషన్") || lower.contains("పోలీస్ స్టేషను")) {
            val nearestPolice = cachedPlaces.filter { it.type == PlaceType.POLICE }
                .minByOrNull { it.distanceKm }

            val response = if (nearestPolice != null && gpsLocationState.isValid) {
                if (isTe) {
                    "మీ దగ్గరలో ఉన్న పోలీస్ స్టేషన్ ${nearestPolice.name}, సుమారుగా ${nearestPolice.distanceKm} కిలోమీటర్ల దూరంలో ఉంది. 112 అత్యవసర పోలీసులకు కాల్ చేయాలా?"
                } else {
                    "The nearest police station is ${nearestPolice.name}, approximately ${nearestPolice.distanceKm} km away. Would you like to call 112 Police Emergency?"
                }
            } else {
                if (isTe) {
                    "ప్రస్తుతం సమీప పోలీస్ స్టేషన్ సమాచారాన్ని ధృవీకరించలేకపోతున్నాను. 112 అత్యవసర పోలీసులకు కాల్ చేయాలా?"
                } else {
                    "Nearby police station info cannot be verified right now. Would you like to call 112 National Emergency Police?"
                }
            }

            val action = PendingVoiceAction.CallEmergency("112", "112 జాతీయ అత్యవసరం", "112 National Emergency Police")
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.ACTION_CONFIRMATION,
                    pendingAction = action,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false,
                pendingAction = action
            )
        }

        // Fire station queries
        if (lower.contains("fire station") || lower.contains("ఫైర్ స్టేషన్") || lower.contains("అగ్నిమాపక")) {
            val nearestFire = cachedPlaces.filter { it.type == PlaceType.FIRE }
                .minByOrNull { it.distanceKm }

            val response = if (nearestFire != null && gpsLocationState.isValid) {
                if (isTe) {
                    "మీ దగ్గరలో ఉన్న ఫైర్ స్టేషన్ ${nearestFire.name}, సుమారుగా ${nearestFire.distanceKm} కిలోమీటర్ల దూరంలో ఉంది. 101 అగ్నిమాపక దళానికి కాల్ చేయాలా?"
                } else {
                    "The nearest fire station is ${nearestFire.name}, approximately ${nearestFire.distanceKm} km away. Would you like to call 101 Fire Brigade?"
                }
            } else {
                if (isTe) {
                    "ఫైర్ స్టేషన్ సమాచారాన్ని ప్రస్తుతం ధృవీకరించలేకపోతున్నాను. 101 కి కాల్ చేయాలా?"
                } else {
                    "Nearby fire station info cannot be verified right now. Would you like to call 101 Fire Brigade?"
                }
            }

            val action = PendingVoiceAction.CallEmergency("101", "101 అగ్నిమాపక దళం", "101 Fire Brigade")
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.ACTION_CONFIRMATION,
                    pendingAction = action,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false,
                pendingAction = action
            )
        }

        // "Where am I?" / "నేను ఎక్కడ ఉన్నాను?" queries
        if (lower.contains("where am i") || lower.contains("నేను ఎక్కడ ఉన్నాను") ||
            lower.contains("నా లొకేషన్") || lower.contains("my location")
        ) {
            val response = if (gpsLocationState.isValid) {
                val locText = gpsLocationState.address?.takeIf { it.isNotBlank() }
                    ?: "అక్షాంశం: %.4f, రేఖాంశం: %.4f".format(gpsLocationState.latitude, gpsLocationState.longitude)
                if (isTe) {
                    "మీ లొకేషన్ నాకు దొరికింది: $locText."
                } else {
                    "I have your location: ${gpsLocationState.address ?: "Coordinates: %.4f, %.4f".format(gpsLocationState.latitude, gpsLocationState.longitude)}."
                }
            } else {
                if (isTe) {
                    "మీ లొకేషన్ ప్రస్తుతం అందుబాటులో లేదు. దయచేసి ఫోన్ GPS ఆన్ చేశారో లేదో చూడండి."
                } else {
                    "Your GPS location is not currently available. Please ensure location services are turned on."
                }
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.LOCATION_CHECK,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = false,
                isEmergency = false
            )
        }

        // --- 4. Human-like Conversational Multi-turn Flow ---

        // State: WHAT_HAPPENED or user reports a fall / incident
        val isFallIncident = lower.contains("పడిపోయాను") || lower.contains("పడ్డాను") ||
                lower.contains("fell down") || lower.contains("fall") || lower.contains("fallen") ||
                lower.contains("slip") || lower.contains("జారిపడ్డాను")

        if (isFallIncident) {
            val response = if (isTe) {
                "సరే. మీరు ఇప్పుడు సురక్షితంగా ఉన్నారా?"
            } else {
                "Okay. Are you safe right now?"
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.SAFETY_CHECK,
                    whatHappened = spokenText,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false
            )
        }

        // State: SAFETY_CHECK -> Handling user answering safety and reporting leg pain / body pain
        if (session.currentStep == VoiceConversationState.SAFETY_CHECK) {
            val hasLegPain = lower.contains("కాలి") || lower.contains("కాలు") || lower.contains("leg") || lower.contains("నొప్పి")
            if (hasLegPain) {
                val response = if (isTe) {
                    "అర్థమైంది. మీ కాలికి చాలా నొప్పిగా ఉందన్నారు. మీరు నిలబడగలుగుతున్నారా?"
                } else {
                    "Understood. You mentioned severe pain in your leg. Are you able to stand?"
                }
                return ConversationTurnResult(
                    updatedSession = session.copy(
                        currentStep = VoiceConversationState.SYMPTOM_DETAILS,
                        identifiedCategory = BodyPartCategory.LEGS_FEET,
                        reportedSymptom = "Leg pain",
                        isSafe = isConfirmation(spokenText),
                        turnsCount = session.turnsCount + 1,
                        conversationHistory = session.conversationHistory + Pair(spokenText, response)
                    ),
                    spokenResponse = response,
                    shouldListenAgain = true,
                    isEmergency = false,
                    identifiedCategory = BodyPartCategory.LEGS_FEET
                )
            }
        }

        // State: Handling response to "Are you able to stand?"
        if (session.currentStep == VoiceConversationState.SYMPTOM_DETAILS && session.identifiedCategory == BodyPartCategory.LEGS_FEET) {
            val cannotStand = isCancellation(spokenText) || lower.contains("లేను") || lower.contains("నిలబడలేను") ||
                    lower.contains("cannot") || lower.contains("can't") || lower.contains("unable")

            if (cannotStand) {
                val response = if (isTe) {
                    "సరే. మీతో ఎవరైనా ఉన్నారా?"
                } else {
                    "Okay. Is anyone with you?"
                }
                return ConversationTurnResult(
                    updatedSession = session.copy(
                        currentStep = VoiceConversationState.PERSON_ALONE_CHECK,
                        canStandOrWalk = false,
                        turnsCount = session.turnsCount + 1,
                        conversationHistory = session.conversationHistory + Pair(spokenText, response)
                    ),
                    spokenResponse = response,
                    shouldListenAgain = true,
                    isEmergency = false,
                    identifiedCategory = BodyPartCategory.LEGS_FEET
                )
            }
        }

        // State: PERSON_ALONE_CHECK -> Answering "Is anyone with you?"
        if (session.currentStep == VoiceConversationState.PERSON_ALONE_CHECK) {
            val isAlone = isCancellation(spokenText) || lower.contains("లేదు") || lower.contains("లేరు") ||
                    lower.contains("ఎవరూ లేరు") || lower.contains("alone") || lower.contains("no one")

            val action = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance")
            val response = if (isTe) {
                if (isAlone) {
                    "అర్థమైంది, మీరు ఒంటరిగా ఉన్నారు మరియు నడవలేకపోతున్నారు. 108కి అంబులెన్స్కు కాల్ చేయాలా?"
                } else {
                    "సమీపంలో ఉన్నవారి సహాయం తీసుకోండి. 108కి అంబులెన్స్కు కాల్ చేయాలా?"
                }
            } else {
                if (isAlone) {
                    "Understood, you are alone and unable to walk. Would you like to call 108 Ambulance?"
                } else {
                    "Please ask the person with you for assistance. Would you like to call 108 Ambulance?"
                }
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.ACTION_CONFIRMATION,
                    isAlone = isAlone,
                    pendingAction = action,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = true,
                pendingAction = action
            )
        }

        // Example 2: Dizziness / Head ("నాకు తల తిరుగుతోంది")
        val isDizziness = lower.contains("తల తిరుగుతోంది") || lower.contains("తల తిరుగు") ||
                lower.contains("dizzy") || lower.contains("dizziness") || lower.contains("spinning")

        if (isDizziness) {
            val response = if (isTe) {
                "సరే. తల తిరుగుతోందన్నారు. మీరు ఇప్పుడు నిలబడకుండా కూర్చోగలరా?"
            } else {
                "Okay. You mentioned dizziness. Can you sit down instead of standing?"
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.SAFETY_CHECK,
                    identifiedCategory = BodyPartCategory.HEAD,
                    reportedSymptom = "Dizziness",
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false,
                identifiedCategory = BodyPartCategory.HEAD
            )
        }

        // If in SAFETY_CHECK for dizziness and user confirms sitting down
        if (session.currentStep == VoiceConversationState.SAFETY_CHECK && session.identifiedCategory == BodyPartCategory.HEAD) {
            val canSit = isConfirmation(spokenText) || lower.contains("కూర్చున్నాను") || lower.contains("sitting")
            if (canSit) {
                val response = if (isTe) {
                    "బాగుంది. మీతో ఎవరైనా ఉన్నారా?"
                } else {
                    "Good. Is anyone with you?"
                }
                return ConversationTurnResult(
                    updatedSession = session.copy(
                        currentStep = VoiceConversationState.PERSON_ALONE_CHECK,
                        isSafe = true,
                        turnsCount = session.turnsCount + 1,
                        conversationHistory = session.conversationHistory + Pair(spokenText, response)
                    ),
                    spokenResponse = response,
                    shouldListenAgain = true,
                    isEmergency = false,
                    identifiedCategory = BodyPartCategory.HEAD
                )
            }
        }

        // If in PERSON_ALONE_CHECK after dizziness and user answers
        if (session.currentStep == VoiceConversationState.PERSON_ALONE_CHECK && session.identifiedCategory == BodyPartCategory.HEAD) {
            val isAlone = isCancellation(spokenText) || lower.contains("లేదు") || lower.contains("లేరు") || lower.contains("no")
            val response = if (isTe) {
                if (isAlone) {
                    "సరే. మీరు ఒంటరిగా ఉన్నారని అర్థమైంది. ఇప్పుడు మీకు ఛాతిలో నొప్పి లేదా శ్వాస తీసుకోవడంలో ఇబ్బంది ఉందా?"
                } else {
                    "సరే. ఇప్పుడు మీకు ఛాతిలో నొప్పి లేదా శ్వాస తీసుకోవడంలో ఇబ్బంది ఉందా?"
                }
            } else {
                if (isAlone) {
                    "Understood, you are alone. Do you have chest pain or trouble breathing?"
                } else {
                    "Okay. Do you have chest pain or difficulty breathing?"
                }
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.DANGER_CHECK,
                    isAlone = isAlone,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false,
                identifiedCategory = BodyPartCategory.HEAD
            )
        }

        // Example 3: Chest pain ("నాకు ఛాతిలో నొప్పిగా ఉంది")
        val isChestPain = lower.contains("ఛాతిలో నొప్పి") || lower.contains("ఛాతీ") || lower.contains("గుండె నొప్పి") ||
                lower.contains("chest pain") || lower.contains("heart pain")

        if (isChestPain) {
            val response = if (isTe) {
                "అర్థమైంది. ఛాతిలో నొప్పిగా ఉందన్నారు. ఎప్పటి నుంచి ఉంది?"
            } else {
                "Understood. You mentioned chest pain. How long have you had this?"
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.SYMPTOM_DETAILS,
                    identifiedCategory = BodyPartCategory.CHEST_HEART,
                    reportedSymptom = "Chest pain",
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = true,
                identifiedCategory = BodyPartCategory.CHEST_HEART
            )
        }

        // Chest pain duration answer -> Ask about breathing difficulty
        if (session.currentStep == VoiceConversationState.SYMPTOM_DETAILS && session.identifiedCategory == BodyPartCategory.CHEST_HEART) {
            val response = if (isTe) {
                "సరే. శ్వాస తీసుకోవడంలో ఇబ్బంది ఉందా?"
            } else {
                "Okay. Are you having difficulty breathing?"
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.DANGER_CHECK,
                    durationText = spokenText,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = true,
                identifiedCategory = BodyPartCategory.CHEST_HEART
            )
        }

        // Handling DANGER_CHECK response (breathing difficulty answer)
        if (session.currentStep == VoiceConversationState.DANGER_CHECK) {
            val hasDanger = isConfirmation(spokenText) || lower.contains("ఉంది") || lower.contains("yes") ||
                    lower.contains("ఆడట్లేదు") || lower.contains("difficulty")

            val action = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance")
            val response = if (isTe) {
                if (hasDanger) {
                    "ఛాతీ నొప్పి మరియు శ్వాస ఇబ్బంది అత్యవసరమైనవి. నిటారుగా కూర్చోండి. 108కి అంబులెన్స్కు కాల్ చేయాలా?"
                } else {
                    "సరే. ప్రశాంతంగా విశ్రాంతి తీసుకోండి. జాగ్రత్త కోసం 108కి అంబులెన్స్కు కాల్ చేయాలా?"
                }
            } else {
                if (hasDanger) {
                    "Chest pain and difficulty breathing require immediate emergency care. Sit upright. Would you like to call 108 Ambulance?"
                } else {
                    "Rest quietly. For safety, would you like to call 108 Ambulance?"
                }
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.ACTION_CONFIRMATION,
                    hasBreathingDifficulty = hasDanger,
                    pendingAction = action,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = true,
                pendingAction = action,
                identifiedCategory = session.identifiedCategory
            )
        }

        // Vague distress: "I'm feeling very weak" / "నాకు చాలా ఇబ్బందిగా ఉంది" / "నొప్పిగా ఉంది"
        if (lower.contains("weak") || lower.contains("ఇబ్బంది") || lower.contains("నొప్పిగా ఉంది") ||
            lower.contains("బాధగా") || lower.contains("sick") || lower.contains("unwell")
        ) {
            val response = if (isTe) {
                "పర్లేదు. నేను మీతో ఉన్నాను. ఏమైంది? నెమ్మదిగా చెప్పండి."
            } else {
                "It's okay. I am here with you. What happened? Speak slowly."
            }
            return ConversationTurnResult(
                updatedSession = session.copy(
                    currentStep = VoiceConversationState.WHAT_HAPPENED,
                    turnsCount = session.turnsCount + 1,
                    conversationHistory = session.conversationHistory + Pair(spokenText, response)
                ),
                spokenResponse = response,
                shouldListenAgain = true,
                isEmergency = false
            )
        }

        // --- 5. Standalone Comprehensive Triage ---
        val triage = triageSymptom(spokenText, defaultLang)
        val nextStep = if (triage.pendingAction != null) VoiceConversationState.ACTION_CONFIRMATION else VoiceConversationState.SPOKEN_FEEDBACK

        return ConversationTurnResult(
            updatedSession = session.copy(
                currentStep = nextStep,
                identifiedCategory = triage.identifiedCategory,
                pendingAction = triage.pendingAction,
                turnsCount = session.turnsCount + 1,
                conversationHistory = session.conversationHistory + Pair(spokenText, triage.spokenResponse)
            ),
            spokenResponse = triage.spokenResponse,
            shouldListenAgain = triage.pendingAction != null,
            isEmergency = triage.isEmergency,
            pendingAction = triage.pendingAction,
            identifiedCategory = triage.identifiedCategory
        )
    }
}
