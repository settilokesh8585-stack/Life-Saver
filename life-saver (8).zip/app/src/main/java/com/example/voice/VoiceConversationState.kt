package com.example.voice

import com.example.model.Language

/**
 * Robust conversation state machine for the Human-like AI Emergency Companion:
 * GREETING
 * -> LISTENING
 * -> UNDERSTANDING
 * -> WHAT_HAPPENED
 * -> SAFETY_CHECK
 * -> LOCATION_CHECK
 * -> PERSON_ALONE_CHECK
 * -> BODY_AREA
 * -> SYMPTOM_DETAILS
 * -> SEVERITY
 * -> DANGER_CHECK
 * -> EMERGENCY_ASSESSMENT
 * -> ACTION_CONFIRMATION
 * -> ACTION_EXECUTION
 * -> FOLLOW_UP
 * -> SPOKEN_FEEDBACK
 */
enum class VoiceConversationState {
    IDLE,
    GREETING,
    WAKE,
    LISTENING,
    UNDERSTANDING,
    WHAT_HAPPENED,
    SAFETY_CHECK,
    LOCATION_CHECK,
    PERSON_ALONE_CHECK,
    BODY_AREA,
    SYMPTOM_DETAILS,
    SEVERITY,
    DANGER_CHECK,
    EMERGENCY_ASSESSMENT,
    NEARBY_HELP,
    ACTION_CONFIRMATION,
    ACTION_EXECUTION,
    FOLLOW_UP,
    SPOKEN_FEEDBACK;

    // Backward-compatible alias properties
    companion object {
        val PERSON_ALONE: VoiceConversationState get() = PERSON_ALONE_CHECK
        val CONFIRMATION: VoiceConversationState get() = ACTION_CONFIRMATION
        val ACTION: VoiceConversationState get() = ACTION_EXECUTION
    }

    fun getDisplayLabel(lang: Language): String = when (this) {
        IDLE -> if (lang == Language.TELUGU) "సిద్ధంగా ఉంది (మాట్లాడండి లేదా తాకండి)" else "Ready (Speak or Tap)"
        GREETING -> if (lang == Language.TELUGU) "లైఫ్ సేవర్ మాట్లాడుతోంది..." else "Life Saver greeting..."
        WAKE -> if (lang == Language.TELUGU) "లైఫ్ సేవర్ మేల్కొంది!" else "Life Saver Awakened!"
        LISTENING -> if (lang == Language.TELUGU) "శ్రద్ధగా వింటోంది..." else "Listening carefully..."
        UNDERSTANDING -> if (lang == Language.TELUGU) "పరిస్థితిని అర్థం చేసుకుంటోంది..." else "Understanding situation..."
        WHAT_HAPPENED -> if (lang == Language.TELUGU) "ఏమైందో తెలుసుకుంటోంది..." else "Understanding what happened..."
        SAFETY_CHECK -> if (lang == Language.TELUGU) "మీ భద్రతను తనిఖీ చేస్తోంది..." else "Checking safety..."
        LOCATION_CHECK -> if (lang == Language.TELUGU) "మీ లొకేషన్ తనిఖీ చేస్తోంది..." else "Checking your location..."
        PERSON_ALONE_CHECK -> if (lang == Language.TELUGU) "మీతో ఎవరైనా ఉన్నారా తనిఖీ చేస్తోంది..." else "Checking if person is alone..."
        BODY_AREA -> if (lang == Language.TELUGU) "బాధ ఉన్న భాగాన్ని గుర్తిస్తోంది..." else "Identifying body area..."
        SYMPTOM_DETAILS -> if (lang == Language.TELUGU) "లక్షణాల వివరాలు తెలుసుకుంటోంది..." else "Understanding symptoms..."
        SEVERITY -> if (lang == Language.TELUGU) "తీవ్రతను అంచనా వేస్తోంది..." else "Assessing severity..."
        DANGER_CHECK -> if (lang == Language.TELUGU) "ప్రమాద లక్షణాలు తనిఖీ చేస్తోంది..." else "Checking critical signs..."
        EMERGENCY_ASSESSMENT -> if (lang == Language.TELUGU) "అత్యవసర పరిస్థితి అంచనా..." else "Assessing Emergency..."
        NEARBY_HELP -> if (lang == Language.TELUGU) "సమీప అత్యవసర కేంద్రాలు..." else "Locating nearby emergency services..."
        ACTION_CONFIRMATION -> if (lang == Language.TELUGU) "మీ నిర్ధారణ కోసం వేచి చూస్తోంది..." else "Awaiting your confirmation..."
        ACTION_EXECUTION -> if (lang == Language.TELUGU) "చర్య అమలు చేయబడుతోంది..." else "Executing action..."
        FOLLOW_UP -> if (lang == Language.TELUGU) "తదుపరి సహాయ మార్గదర్శకత్వం..." else "Follow-up emergency guidance..."
        SPOKEN_FEEDBACK -> if (lang == Language.TELUGU) "వాయిస్ గైడెన్స్ చెబుతోంది..." else "Speaking guidance..."
    }
}

/**
 * Action awaiting explicit user confirmation (Voice or One-Tap)
 */
sealed class PendingVoiceAction {
    data class CallEmergency(
        val number: String,
        val labelTe: String,
        val labelEn: String
    ) : PendingVoiceAction()

    data class CallContact(
        val number: String,
        val contactName: String
    ) : PendingVoiceAction()

    data class SendSosMessage(
        val targetPhone: String,
        val targetName: String
    ) : PendingVoiceAction()

    object TriggerSos : PendingVoiceAction()

    object OpenHospitalMaps : PendingVoiceAction()

    object OpenMedicalShopsMaps : PendingVoiceAction()

    object OpenPoliceMaps : PendingVoiceAction()

    object OpenFireMaps : PendingVoiceAction()

    object RefreshGpsLocation : PendingVoiceAction()
}

/**
 * Multi-turn emergency conversation state session
 * Remembers user responses across turns to maintain true conversational continuity.
 */
data class EmergencyConversationSession(
    val currentStep: VoiceConversationState = VoiceConversationState.IDLE,
    val whatHappened: String? = null,
    val isSafe: Boolean? = null,
    val isAlone: Boolean? = null,
    val identifiedCategory: BodyPartCategory? = null,
    val reportedSymptom: String? = null,
    val durationText: String? = null,
    val severityLevel: String? = null,
    val canStandOrWalk: Boolean? = null,
    val hasBreathingDifficulty: Boolean? = null,
    val hasBleeding: Boolean? = null,
    val pendingAction: PendingVoiceAction? = null,
    val turnsCount: Int = 0,
    val conversationHistory: List<Pair<String, String>> = emptyList()
)
