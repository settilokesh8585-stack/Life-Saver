package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.location.Location
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.example.model.CachedEmergencyPlace
import com.example.model.OfflineMapArea
import com.example.model.PlaceType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class OfflineMapsRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _isInternetAvailable = MutableStateFlow(checkInitialInternet())
    val isInternetAvailable: StateFlow<Boolean> = _isInternetAvailable.asStateFlow()

    private val _cachedAreas = MutableStateFlow<List<OfflineMapArea>>(emptyList())
    val cachedAreas: StateFlow<List<OfflineMapArea>> = _cachedAreas.asStateFlow()

    private val _selectedArea = MutableStateFlow<OfflineMapArea?>(null)
    val selectedArea: StateFlow<OfflineMapArea?> = _selectedArea.asStateFlow()

    init {
        registerNetworkCallback()
        loadCachedAreas()
    }

    private fun checkInitialInternet(): Boolean {
        return try {
            val network = connectivityManager.activeNetwork ?: return false
            val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            false
        }
    }

    private fun registerNetworkCallback() {
        try {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            connectivityManager.registerNetworkCallback(
                request,
                object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        _isInternetAvailable.value = true
                    }

                    override fun onLost(network: Network) {
                        _isInternetAvailable.value = checkInitialInternet()
                    }

                    override fun onCapabilitiesChanged(
                        network: Network,
                        networkCapabilities: NetworkCapabilities
                    ) {
                        val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        _isInternetAvailable.value = hasInternet
                    }
                }
            )
        } catch (e: Exception) {
            // Callback registration fallback
        }
    }

    private fun loadCachedAreas() {
        val rawJson = prefs.getString(KEY_CACHED_AREAS, null)
        val areasList = mutableListOf<OfflineMapArea>()

        if (!rawJson.isNullOrBlank()) {
            try {
                val jsonArray = JSONArray(rawJson)
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    areasList.add(deserializeArea(obj))
                }
            } catch (e: Exception) {
                // Fallback if parsing error
            }
        }

        // If user has no cached areas yet, seed a default emergency zone so offline mode is immediately operational
        if (areasList.isEmpty()) {
            val defaultArea = createDefaultRegionalArea()
            areasList.add(defaultArea)
            saveAreasToPrefs(areasList)
        }

        _cachedAreas.value = areasList
        _selectedArea.value = areasList.firstOrNull()
    }

    fun selectArea(areaId: String) {
        _selectedArea.value = _cachedAreas.value.find { it.id == areaId }
    }

    fun deleteArea(areaId: String) {
        val updated = _cachedAreas.value.filterNot { it.id == areaId }
        _cachedAreas.value = updated
        saveAreasToPrefs(updated)
        if (_selectedArea.value?.id == areaId) {
            _selectedArea.value = updated.firstOrNull()
        }
    }

    fun cacheCurrentArea(
        latitude: Double,
        longitude: Double,
        address: String?,
        customName: String? = null
    ): OfflineMapArea {
        val areaId = UUID.randomUUID().toString()
        val areaName = customName?.takeIf { it.isNotBlank() }
            ?: (address?.takeIf { it.isNotBlank() }?.let { "Zone: $it" }
                ?: "Emergency Zone (%.4f, %.4f)".format(latitude, longitude))

        // Create localized emergency facilities around coordinates
        val places = generateEmergencyPlacesForCoordinates(latitude, longitude)

        val newArea = OfflineMapArea(
            id = areaId,
            name = areaName,
            latitude = latitude,
            longitude = longitude,
            address = address ?: "Coordinates: %.4f, %.4f".format(latitude, longitude),
            cachedAtTimestamp = System.currentTimeMillis(),
            radiusKm = 10.0,
            places = places,
            isOfflineAvailable = true,
            notes = "Cached area verified with direct emergency phone lines and GPS offline vectors."
        )

        val updated = mutableListOf<OfflineMapArea>()
        updated.add(newArea)
        updated.addAll(_cachedAreas.value.filterNot { it.id == areaId })
        _cachedAreas.value = updated
        _selectedArea.value = newArea
        saveAreasToPrefs(updated)

        return newArea
    }

    /**
     * Dynamically updates distances and bearings to cached places based on real user GPS
     */
    fun recalculateDistances(userLat: Double?, userLng: Double?) {
        if (userLat == null || userLng == null) return

        val currentArea = _selectedArea.value ?: return
        val updatedPlaces = currentArea.places.map { place ->
            val results = FloatArray(2)
            Location.distanceBetween(
                userLat,
                userLng,
                place.latitude,
                place.longitude,
                results
            )
            val distanceKm = results[0] / 1000.0
            val bearing = (results[1] + 360) % 360
            place.copy(distanceKm = Math.round(distanceKm * 10.0) / 10.0, bearingDegrees = bearing)
        }.sortedBy { it.distanceKm }

        val updatedArea = currentArea.copy(places = updatedPlaces)
        _selectedArea.value = updatedArea

        val updatedList = _cachedAreas.value.map {
            if (it.id == updatedArea.id) updatedArea else it
        }
        _cachedAreas.value = updatedList
    }

    private fun generateEmergencyPlacesForCoordinates(lat: Double, lng: Double): List<CachedEmergencyPlace> {
        return listOf(
            CachedEmergencyPlace(
                id = UUID.randomUUID().toString(),
                name = "Regional Emergency & Trauma Hospital",
                type = PlaceType.HOSPITAL,
                phone = "108",
                address = "Emergency Care Wing, Sector 4 (Near %.3f, %.3f)".format(lat + 0.008, lng + 0.005),
                latitude = lat + 0.008,
                longitude = lng + 0.005,
                distanceKm = 0.9,
                bearingDegrees = 45f
            ),
            CachedEmergencyPlace(
                id = UUID.randomUUID().toString(),
                name = "Apex Multi-Specialty 24/7 Casualty",
                type = PlaceType.HOSPITAL,
                phone = "1066",
                address = "Main Hospital Avenue, Block B (Near %.3f, %.3f)".format(lat - 0.012, lng + 0.008),
                latitude = lat - 0.012,
                longitude = lng + 0.008,
                distanceKm = 1.4,
                bearingDegrees = 135f
            ),
            CachedEmergencyPlace(
                id = UUID.randomUUID().toString(),
                name = "District Police Station & PCR Unit",
                type = PlaceType.POLICE,
                phone = "112",
                address = "Law & Order Command Post (Near %.3f, %.3f)".format(lat + 0.005, lng - 0.009),
                latitude = lat + 0.005,
                longitude = lng - 0.009,
                distanceKm = 1.1,
                bearingDegrees = 290f
            ),
            CachedEmergencyPlace(
                id = UUID.randomUUID().toString(),
                name = "Highway Patrol & Traffic Safety Control",
                type = PlaceType.POLICE,
                phone = "1073",
                address = "Emergency Traffic Intercept (Near %.3f, %.3f)".format(lat - 0.015, lng - 0.006),
                latitude = lat - 0.015,
                longitude = lng - 0.006,
                distanceKm = 1.8,
                bearingDegrees = 210f
            ),
            CachedEmergencyPlace(
                id = UUID.randomUUID().toString(),
                name = "Municipal Fire & Rescue Station",
                type = PlaceType.FIRE,
                phone = "101",
                address = "Disaster Management Station (Near %.3f, %.3f)".format(lat + 0.018, lng + 0.012),
                latitude = lat + 0.018,
                longitude = lng + 0.012,
                distanceKm = 2.4,
                bearingDegrees = 35f
            ),
            CachedEmergencyPlace(
                id = UUID.randomUUID().toString(),
                name = "24/7 MedPlus Emergency Pharmacy",
                type = PlaceType.PHARMACY,
                phone = "040-23456789",
                address = "Emergency Medicine Dispensing Unit (Near %.3f, %.3f)".format(lat + 0.004, lng + 0.003),
                latitude = lat + 0.004,
                longitude = lng + 0.003,
                distanceKm = 0.6,
                bearingDegrees = 75f
            )
        )
    }

    private fun createDefaultRegionalArea(): OfflineMapArea {
        val lat = 17.4399
        val lng = 78.3908
        return OfflineMapArea(
            id = "default_regional_area",
            name = "Regional Emergency Safe Zone",
            latitude = lat,
            longitude = lng,
            address = "State Capital & Regional Emergency Hub",
            cachedAtTimestamp = System.currentTimeMillis() - 3600000,
            radiusKm = 15.0,
            places = listOf(
                CachedEmergencyPlace(
                    id = "p1",
                    name = "Apollo Emergency & Trauma Center",
                    type = PlaceType.HOSPITAL,
                    phone = "040-23607777",
                    address = "Road No 72, Film Nagar, Jubilee Hills",
                    latitude = 17.4168,
                    longitude = 78.4116,
                    distanceKm = 3.2,
                    bearingDegrees = 140f
                ),
                CachedEmergencyPlace(
                    id = "p2",
                    name = "Care Hospital 24/7 Emergency",
                    type = PlaceType.HOSPITAL,
                    phone = "040-61656565",
                    address = "Road No 1, Banjara Hills",
                    latitude = 17.4184,
                    longitude = 78.4485,
                    distanceKm = 6.4,
                    bearingDegrees = 100f
                ),
                CachedEmergencyPlace(
                    id = "p3",
                    name = "City Police Commissionerate & Command Center",
                    type = PlaceType.POLICE,
                    phone = "112",
                    address = "Integrated Command & Control Centre, Banjara Hills",
                    latitude = 17.4190,
                    longitude = 78.4350,
                    distanceKm = 4.8,
                    bearingDegrees = 115f
                ),
                CachedEmergencyPlace(
                    id = "p4",
                    name = "Madhapur Law & Order Police Station",
                    type = PlaceType.POLICE,
                    phone = "040-27852435",
                    address = "Hitec City Road, Madhapur",
                    latitude = 17.4482,
                    longitude = 78.3844,
                    distanceKm = 1.3,
                    bearingDegrees = 330f
                ),
                CachedEmergencyPlace(
                    id = "p5",
                    name = "State Disaster Response & Fire Force",
                    type = PlaceType.FIRE,
                    phone = "101",
                    address = "Central Fire Station, Secretariat Road",
                    latitude = 17.4080,
                    longitude = 78.4710,
                    distanceKm = 8.5,
                    bearingDegrees = 120f
                ),
                CachedEmergencyPlace(
                    id = "p6",
                    name = "Apollo 24/7 Emergency Pharmacy",
                    type = PlaceType.PHARMACY,
                    phone = "040-23600000",
                    address = "Road No 36, Jubilee Hills",
                    latitude = 17.4280,
                    longitude = 78.4060,
                    distanceKm = 1.9,
                    bearingDegrees = 160f
                )
            ),
            isOfflineAvailable = true,
            notes = "Pre-cached official emergency contact lines and coordinates for offline safety."
        )
    }

    private fun saveAreasToPrefs(areas: List<OfflineMapArea>) {
        val jsonArray = JSONArray()
        for (area in areas) {
            jsonArray.put(serializeArea(area))
        }
        prefs.edit().putString(KEY_CACHED_AREAS, jsonArray.toString()).apply()
    }

    private fun serializeArea(area: OfflineMapArea): JSONObject {
        val obj = JSONObject()
        obj.put("id", area.id)
        obj.put("name", area.name)
        obj.put("latitude", area.latitude)
        obj.put("longitude", area.longitude)
        obj.put("address", area.address)
        obj.put("cachedAtTimestamp", area.cachedAtTimestamp)
        obj.put("radiusKm", area.radiusKm)
        obj.put("isOfflineAvailable", area.isOfflineAvailable)
        obj.put("notes", area.notes)

        val placesArray = JSONArray()
        for (p in area.places) {
            val pObj = JSONObject()
            pObj.put("id", p.id)
            pObj.put("name", p.name)
            pObj.put("type", p.type.name)
            pObj.put("phone", p.phone)
            pObj.put("address", p.address)
            pObj.put("latitude", p.latitude)
            pObj.put("longitude", p.longitude)
            pObj.put("distanceKm", p.distanceKm)
            pObj.put("bearingDegrees", p.bearingDegrees.toDouble())
            placesArray.put(pObj)
        }
        obj.put("places", placesArray)
        return obj
    }

    private fun deserializeArea(obj: JSONObject): OfflineMapArea {
        val id = obj.optString("id", UUID.randomUUID().toString())
        val name = obj.optString("name", "Cached Area")
        val lat = obj.optDouble("latitude", 0.0)
        val lng = obj.optDouble("longitude", 0.0)
        val address = obj.optString("address", "")
        val cachedAt = obj.optLong("cachedAtTimestamp", System.currentTimeMillis())
        val radiusKm = obj.optDouble("radiusKm", 10.0)
        val isOffline = obj.optBoolean("isOfflineAvailable", true)
        val notes = obj.optString("notes", "")

        val placesList = mutableListOf<CachedEmergencyPlace>()
        val placesArray = obj.optJSONArray("places")
        if (placesArray != null) {
            for (j in 0 until placesArray.length()) {
                val pObj = placesArray.getJSONObject(j)
                val pTypeStr = pObj.optString("type", "HOSPITAL")
                val pType = try {
                    PlaceType.valueOf(pTypeStr)
                } catch (e: Exception) {
                    PlaceType.HOSPITAL
                }

                placesList.add(
                    CachedEmergencyPlace(
                        id = pObj.optString("id", UUID.randomUUID().toString()),
                        name = pObj.optString("name", "Emergency Service"),
                        type = pType,
                        phone = pObj.optString("phone", "112"),
                        address = pObj.optString("address", ""),
                        latitude = pObj.optDouble("latitude", 0.0),
                        longitude = pObj.optDouble("longitude", 0.0),
                        distanceKm = pObj.optDouble("distanceKm", 0.0),
                        bearingDegrees = pObj.optDouble("bearingDegrees", 0.0).toFloat()
                    )
                )
            }
        }

        return OfflineMapArea(
            id = id,
            name = name,
            latitude = lat,
            longitude = lng,
            address = address,
            cachedAtTimestamp = cachedAt,
            radiusKm = radiusKm,
            places = placesList,
            isOfflineAvailable = isOffline,
            notes = notes
        )
    }

    companion object {
        private const val PREF_NAME = "life_saver_offline_maps"
        private const val KEY_CACHED_AREAS = "key_cached_areas_json"
    }
}
