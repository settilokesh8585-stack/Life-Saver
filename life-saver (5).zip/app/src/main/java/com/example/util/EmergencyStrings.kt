package com.example.util

import com.example.model.Language

object EmergencyStrings {

    fun appTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Life Saver"
        Language.TELUGU -> "లైఫ్ సేవర్"
    }

    fun appSubtitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency Help"
        Language.TELUGU -> "అత్యవసర సహాయం"
    }

    fun sendSos(lang: Language): String = when (lang) {
        Language.ENGLISH -> "SEND SOS"
        Language.TELUGU -> "అత్యవసర సహాయం (SOS)"
    }

    fun tapToTrigger(lang: Language): String = when (lang) {
        Language.ENGLISH -> "TAP FOR IMMEDIATE HELP"
        Language.TELUGU -> "తక్షణ సహాయం కోసం తాకండి"
    }

    fun sosTriggeringIn(lang: Language, seconds: Int): String = when (lang) {
        Language.ENGLISH -> "SOS Triggering in $seconds..."
        Language.TELUGU -> "$seconds సెకన్లలో SOS ప్రారంభమవుతుంది..."
    }

    fun cancel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "CANCEL"
        Language.TELUGU -> "రద్దు చేయండి"
    }

    fun sirenAlarm(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Siren Alarm"
        Language.TELUGU -> "సైరన్ అలారం"
    }

    fun strobeLight(lang: Language): String = when (lang) {
        Language.ENGLISH -> "SOS Strobe"
        Language.TELUGU -> "SOS ఫ్లాష్‌లైట్"
    }

    // Emergency Numbers
    fun dial112Title(lang: Language): String = "112"
    fun dial112Label(lang: Language): String = when (lang) {
        Language.ENGLISH -> "National Emergency"
        Language.TELUGU -> "జాతీయ అత్యవసరం (ఆల్-ఇన్-వన్)"
    }
    fun dial112Desc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Police, Fire, Medical, Disaster"
        Language.TELUGU -> "పోలీస్, ఫైర్, వైద్య సహాయం"
    }

    fun dial108Title(lang: Language): String = "108"
    fun dial108Label(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Ambulance"
        Language.TELUGU -> "అంబులెన్స్ సర్వీస్"
    }
    fun dial108Desc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Toll-Free Medical Emergency"
        Language.TELUGU -> "ఉచిత అత్యవసర వైద్య సేవలు"
    }

    fun dial101Title(lang: Language): String = "101"
    fun dial101Label(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Fire Brigade"
        Language.TELUGU -> "అగ్నిమాపక దళం"
    }
    fun dial101Desc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Fire & Rescue Services"
        Language.TELUGU -> "అగ్ని ప్రమాద రక్షణ సేవా విభాగం"
    }

    // Maps
    fun nearbyHospitalsTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Nearby Hospitals"
        Language.TELUGU -> "సమీప ఆసుపత్రులు"
    }
    fun nearbyHospitalsDesc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Open in Google Maps"
        Language.TELUGU -> "గూగుల్ మ్యాప్స్‌లో తెరవండి"
    }

    fun nearbyPoliceTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Nearby Police"
        Language.TELUGU -> "సమీప పోలీస్ స్టేషన్లు"
    }
    fun nearbyPoliceDesc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Find closest station"
        Language.TELUGU -> "దగ్గరి పోలీస్ స్టేషన్"
    }

    // GPS & Location
    fun locationTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Live GPS Location"
        Language.TELUGU -> "ప్రత్యక్ష GPS లొకేషన్"
    }

    fun refreshLocation(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Refresh GPS"
        Language.TELUGU -> "GPS రిఫ్రెష్ చేయండి"
    }

    fun fetchingLocation(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Acquiring GPS satellite fix..."
        Language.TELUGU -> "GPS శాటిలైట్ లొకేషన్ పొందుతోంది..."
    }

    fun locationUnavailable(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Location unavailable. Tap Refresh GPS to detect."
        Language.TELUGU -> "లొకేషన్ లభ్యం కాలేదు. GPS రిఫ్రెష్ నొక్కండి."
    }

    fun accuracy(lang: Language, meters: Float): String = when (lang) {
        Language.ENGLISH -> "Accuracy: ±${meters.toInt()} meters"
        Language.TELUGU -> "ఖచ్చితత్వం: ±${meters.toInt()} మీటర్లు"
    }

    // SOS Message preview and share
    fun sosMessageHeader(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Ready-to-Share SOS Message"
        Language.TELUGU -> "షేర్ చేయడానికి సిద్ధంగా ఉన్న SOS సందేశం"
    }

    fun copyMessage(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Copy"
        Language.TELUGU -> "కాపీ చేయండి"
    }

    fun shareWhatsAppAll(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Share SOS (WhatsApp/All)"
        Language.TELUGU -> "షేర్ చేయండి (WhatsApp/ఇతర)"
    }

    fun sendSmsContact(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Send SMS to Contact"
        Language.TELUGU -> "కాంటాక్ట్‌కు SMS పంపండి"
    }

    fun messageCopied(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency message copied to clipboard!"
        Language.TELUGU -> "అత్యవసర సందేశం కాపీ చేయబడింది!"
    }

    fun buildSosMessage(
        lang: Language,
        myPhone: String,
        latitude: Double?,
        longitude: Double?,
        address: String?,
        timestamp: String,
        customNote: String?,
        medicalProfile: com.example.model.MedicalProfile? = null
    ): String {
        val phoneLine = if (myPhone.isNotBlank()) myPhone else "Not configured"
        val latLngLine = if (latitude != null && longitude != null) {
            "%.5f, %.5f".format(latitude, longitude)
        } else {
            "Acquiring GPS..."
        }
        val mapsLink = if (latitude != null && longitude != null) {
            "https://maps.google.com/?q=$latitude,$longitude"
        } else {
            "Location pending"
        }
        val noteLine = if (!customNote.isNullOrBlank()) "\nNote: $customNote" else ""
        val addressLine = if (!address.isNullOrBlank()) "\nAddress: $address" else ""

        val medicalSummary = buildString {
            if (medicalProfile != null && medicalProfile.isConfigured) {
                if (medicalProfile.bloodGroup.isNotBlank()) append("🩸 Blood: ${medicalProfile.bloodGroup} ")
                if (medicalProfile.allergies.isNotBlank()) append("⚠️ Allergies: ${medicalProfile.allergies} ")
                if (medicalProfile.medicalConditions.isNotBlank()) append("📋 Conditions: ${medicalProfile.medicalConditions} ")
                if (medicalProfile.medications.isNotBlank()) append("💊 Meds: ${medicalProfile.medications}")
            }
        }.trim()
        val medicalLine = if (medicalSummary.isNotBlank()) "\n🩺 Medical: $medicalSummary" else ""

        return when (lang) {
            Language.ENGLISH -> """
🚨 EMERGENCY SOS ALERT from Life Saver!
I urgently need help. Please contact emergency services or reach me.
📱 My Phone: $phoneLine
📍 Location Coordinates: $latLngLine$addressLine
🗺️ Google Maps: $mapsLink
⏰ Time: $timestamp$noteLine$medicalLine
            """.trimIndent()

            Language.TELUGU -> """
🚨 అత్యవసర సహాయం (SOS అలర్ట్) - Life Saver!
నాకు తక్షణ సహాయం కావాలి. దయచేసి నన్ను సంప్రదించండి లేదా సహాయం అందించండి.
📱 నా ఫోన్ నంబర్: $phoneLine
📍 GPS స్థానం: $latLngLine$addressLine
🗺️ గూగుల్ మ్యాప్స్ లింక్: $mapsLink
⏰ సమయం: $timestamp$noteLine$medicalLine
            """.trimIndent()
        }
    }

    // Voice Assistant
    fun voiceAssistantTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Voice Emergency Assistant"
        Language.TELUGU -> "వాయిస్ ఎమర్జెన్సీ అసిస్టెంట్"
    }

    fun wakeWordBadge(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Wake phrase: \"Life Saver\""
        Language.TELUGU -> "వేక్ ఫ్రేజ్: \"Life Saver\" / \"లైఫ్ సేవర్\""
    }

    fun startListening(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Tap to Speak Command"
        Language.TELUGU -> "మాట్లాడటానికి తాకండి"
    }

    fun listeningNow(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Listening for \"Life Saver\" or command..."
        Language.TELUGU -> "\"Life Saver\" లేదా ఆదేశం కోసం వింటోంది..."
    }

    fun voiceCommandsHint(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Try saying: \"Life Saver\", \"Help\", \"Call Ambulance\", \"Call 112\", \"Where am I\", \"Send SOS\""
        Language.TELUGU -> "చెప్పండి: \"Life Saver\", \"సహాయం\", \"108 అంబులెన్స్\", \"112 పోలీస్\", \"నేను ఎక్కడ ఉన్నాను\""
    }

    fun backgroundServiceToggle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Background Voice Listening Service"
        Language.TELUGU -> "బ్యాక్‌గ్రౌండ్ వాయిస్ లిజనింగ్ సర్వీస్"
    }

    fun backgroundServiceDesc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Keeps active foreground notification so wake phrase \"Life Saver\" can trigger SOS while the app is active in background."
        Language.TELUGU -> "యాప్ బ్యాక్‌గ్రౌండ్‌లో ఉన్నప్పుడు \"Life Saver\" వేక్ ఫ్రేజ్ గుర్తించడానికి యాక్టివ్ నోటిఫికేషన్ ఉంచుతుంది."
    }

    fun osPrivacyNotice(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Note: Per Android privacy and battery guidelines, third-party apps can listen when active or in foreground-service, but cannot listen when the phone is completely powered off."
        Language.TELUGU -> "గమనిక: ఆండ్రాయిడ్ భద్రతా నిబంధనల ప్రకారం, ఫోన్ పూర్తిగా స్విచ్ ఆఫ్ అయినప్పుడు ఏ యాప్ కూడా వినలేదు. ఫోన్ ఆన్‌లో ఉన్నప్పుడు ఈ సర్వీస్ పనిచేస్తుంది."
    }

    // Settings
    fun settingsTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency Settings & Contacts"
        Language.TELUGU -> "అత్యవసర సెట్టింగ్‌లు & కాంటాక్ట్‌లు"
    }

    fun myPhoneNumberLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "My Phone Number"
        Language.TELUGU -> "నా ఫోన్ నంబర్"
    }

    fun primaryContactName(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency Contact Name"
        Language.TELUGU -> "అత్యవసర కాంటాక్ట్ పేరు"
    }

    fun primaryContactPhone(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency Contact Phone"
        Language.TELUGU -> "అత్యవసర కాంటాక్ట్ ఫోన్ నంబర్"
    }

    fun secondaryContactPhone(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Secondary Contact Phone (Optional)"
        Language.TELUGU -> "రెండవ కాంటాక్ట్ నంబర్ (ఐచ్ఛికం)"
    }

    fun save(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Save Settings"
        Language.TELUGU -> "భద్రపరచండి"
    }

    fun settingsSaved(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency settings saved successfully!"
        Language.TELUGU -> "సెట్టింగ్‌లు విజయవంతంగా భద్రపరచబడ్డాయి!"
    }

    // Battery Alert Feature Strings
    fun batteryTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Battery Status"
        Language.TELUGU -> "బ్యాటరీ స్థితి"
    }

    fun batteryNormal(lang: Language, level: Int, isCharging: Boolean): String = when (lang) {
        Language.ENGLISH -> if (isCharging) "Battery: $level% ⚡ Charging" else "Battery: $level% • Ready"
        Language.TELUGU -> if (isCharging) "బ్యాటరీ: $level% ⚡ ఛార్జ్ అవుతోంది" else "బ్యాటరీ: $level% • సిద్ధంగా ఉంది"
    }

    fun lowBatteryWarningTitle(lang: Language, level: Int): String = when (lang) {
        Language.ENGLISH -> "⚠️ LOW BATTERY WARNING ($level%)"
        Language.TELUGU -> "⚠️ తక్కువ బ్యాటరీ హెచ్చరిక ($level%)"
    }

    fun lowBatteryWarningDesc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Battery dropped below 20%. Please conserve battery or share your emergency coordinates before power drains."
        Language.TELUGU -> "బ్యాటరీ 20% కంటే తక్కువకు పడిపోయింది. ఫోన్ ఆగిపోయేముందు అత్యవసర సమాచారం లేదా లొకేషన్ షేర్ చేయండి."
    }

    fun criticalBatteryWarningTitle(lang: Language, level: Int): String = when (lang) {
        Language.ENGLISH -> "🚨 CRITICAL BATTERY: $level% - SHUTDOWN IMMINENT!"
        Language.TELUGU -> "🚨 అత్యంత క్లిష్టమైన బ్యాటరీ: $level% - ఫోన్ స్విచ్ ఆఫ్ అయ్యే ప్రమాదం ఉంది!"
    }

    fun criticalBatteryWarningDesc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Battery is below 10%! Immediately trigger SOS alert or broadcast your GPS position to emergency contacts."
        Language.TELUGU -> "బ్యాటరీ 10% కంటే తక్కువగా ఉంది! వెంటనే అత్యవసర SOS అలర్ట్ పంపండి లేదా కాంటాక్ట్‌లకు లొకేషన్ పంపండి."
    }

    fun batterySaverTip(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Tip: Screen brightness lowered. GPS and emergency SMS ready."
        Language.TELUGU -> "సూచన: స్క్రీన్ వెలుగు తగ్గించండి. GPS & ఎమర్జెన్సీ SMS సిద్ధంగా ఉన్నాయి."
    }

    // Offline Maps Cache Feature Strings
    fun offlineMapsSectionTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Offline Maps & Emergency Cache"
        Language.TELUGU -> "ఆఫ్‌లైన్ మ్యాప్స్ & అత్యవసర కాష్"
    }

    fun offlineMapsSubtitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Save map areas for 100% offline emergency access"
        Language.TELUGU -> "ఇంటర్నెట్ లేనప్పుడు ఉపయోగించడానికి మ్యాప్ ప్రాంతాన్ని సేవ్ చేసుకోండి"
    }

    fun networkStatusOnline(lang: Language): String = when (lang) {
        Language.ENGLISH -> "🟢 ONLINE: Live Google Maps active"
        Language.TELUGU -> "🟢 ఆన్‌లైన్: లైవ్ గూగుల్ మ్యాప్స్ అందుబాటులో ఉంది"
    }

    fun networkStatusOffline(lang: Language): String = when (lang) {
        Language.ENGLISH -> "🟠 OFFLINE: No internet • Using cached map data"
        Language.TELUGU -> "🟠 ఆఫ్‌లైన్: ఇంటర్నెట్ లేదు • సేవ్ చేసిన మ్యాప్ డేటా ఉపయోగంలో ఉంది"
    }

    fun cacheCurrentAreaButton(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Cache Current Area for Offline Use"
        Language.TELUGU -> "ఆఫ్‌లైన్ కోసం ప్రస్తుత ప్రాంతాన్ని సేవ్ చేయండి"
    }

    fun cachingInProgress(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Caching emergency area data..."
        Language.TELUGU -> "ప్రాంత వివరాలు కాష్ చేయబడుతున్నాయి..."
    }

    fun cachedSuccessMessage(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Area cached successfully! Available offline without data."
        Language.TELUGU -> "ప్రాంతం విజయవంతంగా సేవ్ చేయబడింది! ఇంటర్నెట్ లేకుండా అందుబాటులో ఉంటుంది."
    }

    fun areaAvailableOfflineBadge(lang: Language): String = when (lang) {
        Language.ENGLISH -> "OFFLINE READY"
        Language.TELUGU -> "ఆఫ్‌లైన్ సిద్ధం"
    }

    fun areaNotCachedBadge(lang: Language): String = when (lang) {
        Language.ENGLISH -> "ONLINE ONLY"
        Language.TELUGU -> "ఆన్‌లైన్ మాత్రమే"
    }

    fun cachedAtLabel(lang: Language, dateStr: String): String = when (lang) {
        Language.ENGLISH -> "Cached: $dateStr"
        Language.TELUGU -> "సేవ్ చేసిన సమయం: $dateStr"
    }

    fun offlineEmergencyFacilitiesTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Offline Emergency Facilities"
        Language.TELUGU -> "ఆఫ్‌లైన్ అత్యవసర కేంద్రాలు"
    }

    fun callDirectButton(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Call"
        Language.TELUGU -> "కాల్ చేయండి"
    }

    fun viewCoordinatesButton(lang: Language): String = when (lang) {
        Language.ENGLISH -> "View on Map"
        Language.TELUGU -> "మ్యాప్‌లో చూడండి"
    }

    fun openGoogleMapsOfflineTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Download Full Vector Map in Google Maps"
        Language.TELUGU -> "గూగుల్ మ్యాప్స్‌లో పూర్తి ఆఫ్‌లైన్ మ్యాప్‌ను డౌన్‌లోడ్ చేయండి"
    }

    fun offlineMapsDisclaimer(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Honest Notice: Live satellite imagery & dynamic Google traffic require an internet connection. Life Saver caches exact GPS coordinates, emergency phone numbers, and directional bearings so you can navigate and call for help even without cellular data. For full turn-by-turn road vector maps, open Google Maps > Offline Maps to download your city."
        Language.TELUGU -> "నిజాయితీ ప్రకటన: ప్రత్యక్ష శాటిలైట్ మ్యాప్‌లకు ఇంటర్నెట్ అవసరం. లైఫ్ సేవర్ అత్యవసర ఫోన్ నంబర్లు, జీపీఎస్ కోఆర్డినేట్లు, దిశా సూచికలను ఆఫ్‌లైన్‌లో నిల్వ చేస్తుంది. ఇంటర్నెట్ లేనప్పుడు కూడా కాల్ చేయవచ్చు. పూర్తి వీధి మ్యాప్స్ కోసం గూగుల్ మ్యాప్స్ యాప్‌లోని 'Offline Maps' ద్వారా మీ నగరాన్ని డౌన్‌లోడ్ చేసుకోవచ్చు."
    }

    fun deleteCachedArea(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Remove Cache"
        Language.TELUGU -> "కాష్ తొలగించండి"
    }

    // Medical Info Card Strings
    fun medicalInfoTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency Medical Info"
        Language.TELUGU -> "అత్యవసర వైద్య సమాచారం"
    }

    fun medicalInfoSubtitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Vital data for paramedics & emergency doctors"
        Language.TELUGU -> "పారామెడిక్స్ మరియు వైద్యులకు అవసరమైన కీలక సమాచారం"
    }

    fun bloodGroupLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Blood Group"
        Language.TELUGU -> "రక్త వర్గం"
    }

    fun allergiesLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Allergies"
        Language.TELUGU -> "అలెర్జీలు"
    }

    fun medicationsLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Medications"
        Language.TELUGU -> "వాడుతున్న మందులు"
    }

    fun conditionsLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Medical Conditions"
        Language.TELUGU -> "ఆరోగ్య సమస్యలు"
    }

    fun emergencyNotesLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency Notes"
        Language.TELUGU -> "అత్యవసర సూచనలు"
    }

    fun editMedicalInfo(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Edit Medical Info"
        Language.TELUGU -> "వైద్య వివరాలు సవరించండి"
    }

    fun addMedicalInfo(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Add Medical Info"
        Language.TELUGU -> "వైద్య వివరాలు జోడించండి"
    }

    fun importantMedicalNotes(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Important Medical Notes"
        Language.TELUGU -> "ముఖ్యమైన వైద్య సూచనలు"
    }

    fun tapToAddMedicalInfo(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Tap to add blood group, allergies & medications"
        Language.TELUGU -> "రక్త వర్గం, అలెర్జీలు, మందులు జోడించడానికి తాకండి"
    }

    fun medicalInfoNotSetNotice(lang: Language): String = when (lang) {
        Language.ENGLISH -> "No medical info set. Tap to add blood group & allergies for first responders."
        Language.TELUGU -> "వైద్య వివరాలు నమోదు చేయలేదు. రక్తం గ్రూప్ మరియు అలెర్జీలను నమోదు చేయండి."
    }

    fun medicalInfoSavedLocally(lang: Language): String = when (lang) {
        Language.ENGLISH -> "🔒 Stored locally on this phone. Never shared to cloud servers."
        Language.TELUGU -> "🔒 ఈ ఫోన్‌లో మాత్రమే భద్రపరచబడుతుంది. క్లౌడ్‌కు పంపబడదు."
    }

    // Offline SOS SMS Strings
    fun offlineSmsTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Offline SOS SMS"
        Language.TELUGU -> "ఆఫ్‌లైన్ ఎస్ఓఎస్ SMS"
    }

    fun offlineSmsSubtitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Send emergency alert via cellular SMS without internet"
        Language.TELUGU -> "ఇంటర్నెట్ లేకుండా మొబైల్ SMS ద్వారా అత్యవసర సందేశం పంపండి"
    }

    fun offlineSmsDisclaimer(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Notice: Works without internet or Wi-Fi using standard SIM cellular coverage. Does NOT work without mobile carrier network signal."
        Language.TELUGU -> "గమనిక: ఇంటర్నెట్ లేకపోయినా సిమ్ సెల్యులార్ నెట్‌వర్క్ ద్వారా పనిచేస్తుంది. మొబైల్ సిగ్నల్ తప్పనిసరిగా ఉండాలి."
    }

    fun offlineSmsConfirmTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Confirm SOS SMS Dispatch"
        Language.TELUGU -> "SMS పంపడాన్ని నిర్ధారించండి"
    }

    fun offlineSmsRecipient(lang: Language, name: String, phone: String): String = when (lang) {
        Language.ENGLISH -> "Recipient: $name ($phone)"
        Language.TELUGU -> "గ్రహీత: $name ($phone)"
    }

    fun sendViaSmsApp(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Open in SMS App & Send"
        Language.TELUGU -> "SMS యాప్‌లో తెరిచి పంపండి"
    }

    // Shake SOS Feature Strings
    fun shakeSosTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Shake SOS Detection"
        Language.TELUGU -> "ఫోన్ షేక్ SOS డిటెక్షన్"
    }

    fun shakeSosDesc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Vigorously shake phone to start emergency SOS with 5-second countdown & cancellation."
        Language.TELUGU -> "ఫోన్‌ను బలంగా ఊపితే 5 సెకన్ల కౌంట్‌డౌన్‌తో అత్యవసర SOS ప్రారంభమవుతుంది."
    }

    fun shakeSosSensorStatus(lang: Language, enabled: Boolean): String = when (lang) {
        Language.ENGLISH -> if (enabled) "Motion sensor active (Safe trigger)" else "Sensors off (Zero battery drain)"
        Language.TELUGU -> if (enabled) "మోషన్ సెన్సార్ ఆన్ (సురక్షిత SOS)" else "సెన్సార్లు ఆఫ్ (బ్యాటరీ ఖర్చు సున్నా)"
    }

    fun shakeSosTriggeredTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "⚠️ Phone Shake Detected!"
        Language.TELUGU -> "⚠️ ఫోన్ షేక్ గుర్తించబడింది!"
    }

    fun shakeSosCountdownMessage(lang: Language, seconds: Int): String = when (lang) {
        Language.ENGLISH -> "Emergency SOS triggering in $seconds seconds. Tap Cancel if accidental."
        Language.TELUGU -> "$seconds సెకన్లలో ఎమర్జెన్సీ SOS ప్రారంభమవుతుంది. పొరపాటున జరిగితే రద్దు నొక్కండి."
    }

    fun cancelShakeSos(lang: Language): String = when (lang) {
        Language.ENGLISH -> "CANCEL SHAKE SOS"
        Language.TELUGU -> "షేక్ SOS రద్దు చేయండి"
    }

    // Audio Feedback Setting Strings
    fun audioFeedbackTitle(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency Audio Feedback"
        Language.TELUGU -> "అత్యవసర ఆడియో & సైరన్ సౌండ్"
    }

    fun audioFeedbackDesc(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Play loud siren alarm and speak voice countdowns. Turn OFF for silent emergencies."
        Language.TELUGU -> "బిగ్గరగా సైరన్ మోగించడం మరియు వాయిస్ కౌంట్‌డౌన్. నిశ్శబ్ద అత్యవసరాలలో ఆఫ్ చేయండి."
    }

    fun audioFeedbackStatus(lang: Language, enabled: Boolean): String = when (lang) {
        Language.ENGLISH -> if (enabled) "🔊 Audio & Siren Enabled" else "🔕 Silent Mode (Visual Alerts Only)"
        Language.TELUGU -> if (enabled) "🔊 ఆడియో & సైరన్ ఆన్‌లో ఉంది" else "🔕 సైలెంట్ మోడ్ (స్క్రీన్ & ఫ్లాష్ మాత్రమే)"
    }

    // Accessible Short Labels for Emergency Buttons
    fun ambulanceLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Ambulance"
        Language.TELUGU -> "అంబులెన్స్"
    }

    fun policeLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Police 112"
        Language.TELUGU -> "పోలీస్ 112"
    }

    fun fireLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Fire 101"
        Language.TELUGU -> "ఫైర్ 101"
    }

    fun hospitalLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Hospital"
        Language.TELUGU -> "ఆసుపత్రి"
    }

    fun myLocationLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "My Location"
        Language.TELUGU -> "నా లొకేషన్"
    }

    fun voiceHelpLabel(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Voice Help"
        Language.TELUGU -> "వాయిస్ సహాయం"
    }

    fun tapToSpeak(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Speak emergency"
        Language.TELUGU -> "మాట్లాడండి"
    }

    fun tapToCall(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Tap to Call"
        Language.TELUGU -> "కాల్ చేయండి"
    }

    fun nearbyMaps(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Nearby Maps"
        Language.TELUGU -> "సమీప ఆసుపత్రులు"
    }

    fun findMyLocation(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Where am I"
        Language.TELUGU -> "ప్రస్తుత స్థానం"
    }

    // Voice Feedback (Text-to-Speech) spoken announcements
    fun speakAmbulance(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Calling Ambulance 108"
        Language.TELUGU -> "108 అంబులెన్స్ కాల్ చేయబడుతోంది"
    }

    fun speakPolice(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Calling Emergency Police 112"
        Language.TELUGU -> "112 అత్యవసర పోలీస్ కాల్ చేయబడుతోంది"
    }

    fun speakFire(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Calling Fire Brigade 101"
        Language.TELUGU -> "101 ఫైర్ సర్వీస్ కాల్ చేయబడుతోంది"
    }

    fun speakHospital(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Opening nearest hospitals on map"
        Language.TELUGU -> "సమీపంలోని ఆసుపత్రులను చూపిస్తున్నాము"
    }

    fun speakMyLocation(lang: Language, address: String?): String = when (lang) {
        Language.ENGLISH -> if (!address.isNullOrBlank()) "Your current location is: $address" else "Checking your current GPS location"
        Language.TELUGU -> if (!address.isNullOrBlank()) "మీ ప్రస్తుత స్థానం: $address" else "మీ ప్రస్తుత జీపీఎస్ స్థానాన్ని తనిఖీ చేస్తున్నాము"
    }

    fun speakVoiceHelp(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Listening. Please speak your emergency situation."
        Language.TELUGU -> "వినబడుతోంది. మీ అత్యవసర పరిస్థితిని చెప్పండి."
    }

    fun speakSosTriggered(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency SOS triggered. 5 seconds countdown started. Tap cancel to stop."
        Language.TELUGU -> "ఎమర్జెన్సీ ఎస్ ఓ ఎస్ ప్రారంభమైంది. 5 సెకన్లలో సందేశం పంపబడుతుంది. రద్దు చేయడానికి నొక్కండి."
    }

    fun speakSosCancelled(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Emergency SOS cancelled."
        Language.TELUGU -> "ఎమర్జెన్సీ ఎస్ ఓ ఎస్ రద్దు చేయబడింది."
    }

    fun speakLanguageSwitched(lang: Language): String = when (lang) {
        Language.ENGLISH -> "Language set to English"
        Language.TELUGU -> "భాష తెలుగుగా మార్చబడింది"
    }

    fun speakSiren(lang: Language, active: Boolean): String = when (lang) {
        Language.ENGLISH -> if (active) "Siren alarm turned on" else "Siren alarm turned off"
        Language.TELUGU -> if (active) "సైరన్ అలారం ప్రారంభించబడింది" else "సైరన్ అలారం ఆపబడింది"
    }

    fun speakStrobe(lang: Language, active: Boolean): String = when (lang) {
        Language.ENGLISH -> if (active) "Flashlight turned on" else "Flashlight turned off"
        Language.TELUGU -> if (active) "ఫ్లాష్‌లైట్ ఆన్ చేయబడింది" else "ఫ్లాష్‌లైట్ ఆఫ్ చేయబడింది"
    }
}
