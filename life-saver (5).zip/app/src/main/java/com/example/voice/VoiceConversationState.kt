package com.example.voice

import com.example.model.Language

/**
 * Explicit conversation state machine for the Voice Emergency Assistant:
 * IDLE -> WAKE -> LISTENING -> UNDERSTANDING -> EMERGENCY_ASSESSMENT -> CONFIRMATION -> ACTION -> SPOKEN_FEEDBACK
 */
enum class VoiceConversationState {
    IDLE,
    WAKE,
    LISTENING,
    UNDERSTANDING,
    EMERGENCY_ASSESSMENT,
    CONFIRMATION,
    ACTION,
    SPOKEN_FEEDBACK;

    fun getDisplayLabel(lang: Language): String = when (this) {
        IDLE -> if (lang == Language.TELUGU) "సిద్ధంగా ఉంది (మాట్లాడండి లేదా తాకండి)" else "Ready (Speak or Tap)"
        WAKE -> if (lang == Language.TELUGU) "లైఫ్ సేవర్ మేల్కొంది!" else "Life Saver Awakened!"
        LISTENING -> if (lang == Language.TELUGU) "శ్రద్ధగా వింటోంది..." else "Listening carefully..."
        UNDERSTANDING -> if (lang == Language.TELUGU) "సమస్యను అర్థం చేసుకుంటోంది..." else "Understanding symptom..."
        EMERGENCY_ASSESSMENT -> if (lang == Language.TELUGU) "అత్యవసర పరిస్థితి అంచనా..." else "Assessing Emergency..."
        CONFIRMATION -> if (lang == Language.TELUGU) "మీ నిర్ధారణ కోసం వేచి చూస్తోంది..." else "Awaiting your confirmation..."
        ACTION -> if (lang == Language.TELUGU) "చర్య అమలు చేయబడుతోంది..." else "Executing action..."
        SPOKEN_FEEDBACK -> if (lang == Language.TELUGU) "వాయిస్ గైడెన్స్ చెబుతోంది..." else "Speaking guidance..."
    }
}

/**
 * Action awaiting explicit user confirmation (Voice or One-Tap)
 */
sealed class PendingVoiceAction {
    data class CallEmergency(
        val number: String,
        val labelTe: String,
        val labelEn: String
    ) : PendingVoiceAction()

    data class SendSosMessage(
        val targetPhone: String,
        val targetName: String
    ) : PendingVoiceAction()

    object TriggerSos : PendingVoiceAction()

    object OpenHospitalMaps : PendingVoiceAction()

    object RefreshGpsLocation : PendingVoiceAction()
}
