package com.example.voice

import com.example.model.Language

/**
 * Body-Symptom categories supported by the Voice Emergency Assistant
 */
enum class BodyPartCategory(val displayNameEn: String, val displayNameTe: String, val icon: String) {
    HEAD("Head", "తల", "🧠"),
    EYES("Eyes", "కళ్ళు", "👁️"),
    EARS("Ears", "చెవులు", "👂"),
    FACE_MOUTH("Face / Mouth", "ముఖం / నోరు", "🗣️"),
    CHEST_HEART("Chest / Heart", "ఛాతీ / గుండె", "❤️"),
    LUNGS_BREATHING("Lungs / Breathing", "ఊపిరితిత్తులు / శ్వాస", "🫁"),
    STOMACH_ABDOMEN("Stomach / Abdomen", "కడుపు", "🩺"),
    BACK("Back / Spine", "వెన్నుముక", "🧍"),
    ARMS_HANDS("Arms / Hands", "చేతులు", "💪"),
    LEGS_FEET("Legs / Feet", "కాళ్ళు", "🦵"),
    SKIN_WHOLE_BODY("Skin / Whole Body", "చర్మం / శరీరం", "🩹"),
    GENERAL_EMERGENCY("General Emergency", "సాధారణ అత్యవసరం", "🆘")
}

data class BodySymptom(
    val category: BodyPartCategory,
    val symptomNameEn: String,
    val symptomNameTe: String,
    val isCritical: Boolean,
    val recommendedServiceNumber: String? = null // e.g. "108" for Ambulance, "112" for Police/Universal
)
