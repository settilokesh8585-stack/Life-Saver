package com.example.voice

import com.example.model.Language
import java.util.Locale

data class TriageResult(
    val spokenResponse: String,
    val isEmergency: Boolean,
    val pendingAction: PendingVoiceAction? = null,
    val identifiedCategory: BodyPartCategory? = null,
    val detectedLanguage: Language = Language.ENGLISH,
    val isTriageQuestion: Boolean = false
)

object VoiceTriageEngine {

    /**
     * Detects if the utterance contains Telugu script or characteristic transliterated Telugu phrases.
     */
    fun detectLanguage(text: String): Language {
        // Check for Unicode Telugu character block: U+0C00 - U+0C7F
        for (char in text) {
            if (char in '\u0C00'..'\u0C7F') {
                return Language.TELUGU
            }
        }
        val lower = text.lowercase(Locale.ROOT)
        val teluguPhonetic = listOf("naku", "undhi", "undi", "kavali", "jarigindi", "sahayam", "oppiri", "noppi")
        if (teluguPhonetic.any { lower.contains(it) }) {
            return Language.TELUGU
        }
        return Language.ENGLISH
    }

    /**
     * Checks if spoken text is the Wake Phrase "Life Saver" or "లైఫ్ సేవర్"
     */
    fun isWakeWord(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        return lower.contains("life saver") || lower.contains("lifesaver") ||
                lower.contains("లైఫ్ సేవర్") || lower.contains("లైఫ్సేవర్")
    }

    /**
     * Checks if spoken text expresses explicit confirmation (Yes / Call / Proceed)
     */
    fun isConfirmation(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        val yesKeywords = listOf(
            "అవును", "కాల్ చేయి", "చేయి", "చెయ్యి", "సరే", "అవునండి", "కాల్", "పిలవండి",
            "yes", "yeah", "yep", "call", "proceed", "sure", "ok", "okay", "confirm", "dial"
        )
        return yesKeywords.any { lower.contains(it) }
    }

    /**
     * Checks if spoken text expresses explicit cancellation / rejection (No / Don't / Cancel)
     */
    fun isCancellation(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        val noKeywords = listOf(
            "వద్దు", "వద్దండి", "ఆపు", "రద్దు", "చేయవద్దు", "వద్దు వద్దు",
            "no", "nope", "cancel", "stop", "don't", "dont", "never", "abort"
        )
        return noKeywords.any { lower.contains(it) }
    }

    /**
     * Primary Triage Engine: Evaluates symptoms across all body areas and generates short, calm spoken guidance.
     * ONE simple question or confirmation step at a time.
     */
    fun triageSymptom(spokenText: String, defaultLang: Language): TriageResult {
        val detectedLang = detectLanguage(spokenText).takeIf { it == Language.TELUGU } ?: defaultLang
        val lower = spokenText.lowercase(Locale.ROOT)

        // 1. CHEST / HEART (Chest pain, pressure, breathing difficulty, palpitations)
        if (lower.contains("chest") || lower.contains("heart") || lower.contains("ఛాతి") ||
            lower.contains("ఛాతీ") || lower.contains("గుండె") || lower.contains("గుండె నొప్పి")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "ఛాతీ లేదా గుండె నొప్పి తీవ్రమైన హెచ్చరిక కావచ్చు. వెంటనే నిటారుగా కూర్చోండి, శ్రమ పడవద్దు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Chest pain can be a critical emergency. Please sit upright and rest immediately. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.CHEST_HEART,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 2. LUNGS / BREATHING (Shortness of breath, choking, severe coughing)
        if (lower.contains("ఊపిరి") || lower.contains("శ్వాస") || lower.contains("breath") ||
            lower.contains("chok") || lower.contains("దగ్గు") || lower.contains("shortness of breath")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీకు శ్వాస తీసుకోవడంలో ఇబ్బంది ఉందని అర్థమైంది. ఇది అత్యవసర పరిస్థితి కావచ్చు. మీరు ఒంటరిగా ఉంటే దగ్గరలో ఉన్న వ్యక్తిని సహాయం కోసం పిలవండి. అత్యవసర సహాయం అవసరమైతే 112కు కాల్ చేయవచ్చు. మీరు 112కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "I understand you are having difficulty breathing. This may be an emergency. If alone, alert someone nearby. Would you like to call 112 National Emergency?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("112", "112 జాతీయ అత్యవసరం", "112 National Emergency"),
                identifiedCategory = BodyPartCategory.LUNGS_BREATHING,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 3. ACCIDENT / ROAD CRASH (Major accident, trauma)
        if (lower.contains("accident") || lower.contains("crash") || lower.contains("ప్రమాదం") || lower.contains("యాక్సిడెంట్")) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు సురక్షితంగా ఉన్నారా? గాయాలు ఉన్నాయా? మీకు అంబులెన్స్ అవసరమైతే నేను సహాయం చేసే చర్యలను చూపిస్తాను. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Are you in a safe spot? If there are injuries, stay calm and do not move the neck. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 4. HEAD (Headache, dizziness, unconsciousness, confusion, speech difficulty)
        if (lower.contains("తల తిరుగు") || lower.contains("తల నొప్పి") || lower.contains("స్పృహ") ||
            lower.contains("headache") || lower.contains("dizzy") || lower.contains("unconscious") ||
            lower.contains("faint") || lower.contains("confusion")
        ) {
            val isUnconscious = lower.contains("స్పృహ") || lower.contains("unconscious") || lower.contains("faint")
            val response = if (detectedLang == Language.TELUGU) {
                if (isUnconscious) {
                    "రోగి శ్వాస తీసుకుంటున్నారా చూడండి. మెడను అస్సలు కదల్చవద్దు. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
                } else {
                    "తల తిరుగుడు లేదా తీవ్ర తలనొప్పి ఉంటే ప్రశాంతంగా పడుకోండి. నీరు నెమ్మదిగా తాగండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
                }
            } else {
                if (isUnconscious) {
                    "Check if the person is breathing. Do not move their neck. Would you like to call 108 Ambulance?"
                } else {
                    "Sit or lie down safely to prevent a fall. Would you like to call 108 Ambulance for assistance?"
                }
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.HEAD,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 5. LEGS / FEET (Fracture, severe pain, inability to walk, broken leg)
        if (lower.contains("కాలు విరిగింది") || lower.contains("కాలు") || lower.contains("విరిగింది") ||
            lower.contains("నడవలే") || lower.contains("fracture") || lower.contains("broken leg") ||
            lower.contains("leg") || lower.contains("foot") || lower.contains("bone")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "గాయపడిన కాలును బలవంతంగా కదల్చవద్దు. కాలు కింద దిండు లేదా మద్దతు ఉంచండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Do not move the injured leg or attempt to stand. Keep it supported and still. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.LEGS_FEET,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 6. SEVERE BLEEDING / CUTS / WOUNDS (Arms, Hands, Body)
        if (lower.contains("రక్తం") || lower.contains("గాయం") || lower.contains("bleed") ||
            lower.contains("cut") || lower.contains("wound")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "గాయంపై శుభ్రమైన గుడ్డ లేదా వస్త్రంతో గట్టిగా ఒత్తిడి ఉంచండి. రక్తం ఆగకుండా ఉంటే అత్యవసరం. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Apply continuous firm pressure on the wound with a clean cloth. Do not remove it. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.SKIN_WHOLE_BODY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 7. BURNS / FIRE / SCALDS
        if (lower.contains("మంటగా") || lower.contains("కాలింది") || lower.contains("మంటలు") ||
            lower.contains("burn") || lower.contains("fire") || lower.contains("scald")
        ) {
            val isFireCall = lower.contains("మంటలు") || lower.contains("fire")
            val targetNumber = if (isFireCall) "101" else "108"
            val targetLabelTe = if (isFireCall) "101 అగ్నిమాపక దళం" else "108 అంబులెన్స్"
            val targetLabelEn = if (isFireCall) "101 Fire Brigade" else "108 Ambulance"

            val response = if (detectedLang == Language.TELUGU) {
                "కాలిన భాగాన్ని వెంటనే 10 నిమిషాల పాటు చల్లని నీటితో కడగండి. మంచు లేదా నూనె రాయవద్దు. మీరు $targetLabelTe కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Cool the burn with cool running water for 10 minutes immediately. Never apply ice or oil. Would you like to call $targetLabelEn?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency(targetNumber, targetLabelTe, targetLabelEn),
                identifiedCategory = BodyPartCategory.SKIN_WHOLE_BODY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 8. STOMACH / ABDOMEN (Severe abdominal pain, vomiting, bleeding)
        if (lower.contains("కడుపు నొప్పి") || lower.contains("కడుపు") || lower.contains("వాంతులు") ||
            lower.contains("stomach") || lower.contains("abdomen") || lower.contains("vomit")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "కడుపుపై ఎటువంటి ఒత్తిడి పెట్టవద్దు. విశ్రాంతిగా పడుకోండి. తీవ్రమైన నొప్పి లేదా వాంతులు ఉంటే 108 అంబులెన్స్ పిలవండి. మీరు 108కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Lie down comfortably and avoid solid food or pressure on your stomach. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.STOMACH_ABDOMEN,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 9. FACE / MOUTH (Facial weakness/droop, difficulty speaking or swallowing)
        if (lower.contains("ముఖం") || lower.contains("మాట") || lower.contains("మింగలే") ||
            lower.contains("face") || lower.contains("slurr") || lower.contains("swallow") || lower.contains("stroke")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "ముఖం వంకర లేదా మాట ముద్దబడటం పక్షవాతం హెచ్చరిక కావచ్చు. సమయం చాలా ముఖ్యం. మీరు వెంటనే 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Facial droop or speech difficulty may indicate a stroke. Every minute counts. Would you like to call 108 Ambulance immediately?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.FACE_MOUTH,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 10. EYES (Sudden vision loss, eye injury, severe eye pain)
        if (lower.contains("కళ్ళు") || lower.contains("కంటి") || lower.contains("చూపు") ||
            lower.contains("eye") || lower.contains("vision") || lower.contains("blind")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "కంటిని అస్సలు రుద్దవద్దు. శుభ్రమైన వస్త్రంతో తేలికగా కప్పి ఉంచండి. మీరు సమీప నేత్ర ఆసుపత్రి సహాయం కోసం 108కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Do not rub your eye. Cover it gently with a clean cloth without pressure. Would you like to call 108 for medical assistance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.EYES,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 11. EARS (Hearing loss, ear bleeding, ear injury)
        if (lower.contains("చెవి") || lower.contains("చెవులు") || lower.contains("ear") || lower.contains("hearing")) {
            val response = if (detectedLang == Language.TELUGU) {
                "చెవి లోపల ఎటువంటి వస్తువులు పెట్టవద్దు. రక్తం కారుతుంటే తలను పక్కకు ఉంచండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Do not insert anything into the ear. Keep head tilted if fluid or blood drains. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.EARS,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 12. BACK / SPINE (Severe back pain, spinal trauma)
        if (lower.contains("వెన్ను") || lower.contains("నడుము") || lower.contains("spine") || lower.contains("back")) {
            val response = if (detectedLang == Language.TELUGU) {
                "వెన్నుముక గాయం అనుమానం ఉంటే రోగిని అస్సలు కదల్చవద్దు. సమతలంగా ఉంచండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Keep the person flat and still. Do not twist or move the spine. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.BACK,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 13. ARMS / HANDS (Arm weakness, numbness, severe bleeding, fracture)
        if (lower.contains("చేయి") || lower.contains("చేతులు") || lower.contains("చేతికి") ||
            lower.contains("arm") || lower.contains("hand") || lower.contains("wrist")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "గాయపడిన చేతిని ఆధారంతో కదలకుండా ఉంచండి. రక్తం కారుతుంటే ఒత్తిడి పెట్టండి. మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Support the injured arm gently and keep it still. Apply pressure if bleeding. Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.ARMS_HANDS,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 14. POISONING / SNAKE BITE (Toxic, venom)
        if (lower.contains("పాము") || lower.contains("విషం") || lower.contains("snake") ||
            lower.contains("poison") || lower.contains("bite")
        ) {
            val response = if (detectedLang == Language.TELUGU) {
                "రోగిని ప్రశాంతంగా, కదలకుండా ఉంచండి. గాయాన్ని కోయవద్దు లేదా కట్టవద్దు. మీరు వెంటనే 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Keep the patient calm and still. Do not cut or tourniquet the bite. Would you like to call 108 Ambulance immediately?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.SKIN_WHOLE_BODY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 15. DIRECT SERVICE INTENTS (Ambulance, Police, Fire, SOS)
        if (lower.contains("ambulance") || lower.contains("108") || lower.contains("అంబులెన్స్")) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు 108 అంబులెన్స్ కి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Would you like to call 108 Ambulance?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("108", "108 అంబులెన్స్", "108 Ambulance"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        if (lower.contains("police") || lower.contains("112") || lower.contains("పోలీస్") || lower.contains("పోలీసులు")) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు 112 జాతీయ అత్యవసర పోలీసులకు కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Would you like to call 112 National Emergency Police?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("112", "112 జాతీయ అత్యవసరం", "112 National Emergency"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        if (lower.contains("fire") || lower.contains("101") || lower.contains("ఫైర్")) {
            val response = if (detectedLang == Language.TELUGU) {
                "మీరు 101 అగ్నిమాపక దళానికి కాల్ చేయాలనుకుంటున్నారా?"
            } else {
                "Would you like to call 101 Fire Brigade?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.CallEmergency("101", "101 అగ్నిమాపక దళం", "101 Fire Brigade"),
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // 16. GENERAL HELP REQUEST ("నాకు సహాయం కావాలి", "i need help")
        if (lower.contains("సహాయం") || lower.contains("కాపాడండి") || lower.contains("help") || lower.contains("sos")) {
            val response = if (detectedLang == Language.TELUGU) {
                "నేను మీకు సహాయం చేయడానికి సిద్ధంగా ఉన్నాను. మీ సమస్య ఏమిటి? శ్వాస, ఛాతీ నొప్పి, గాయం, లేదా ప్రమాదమా? లేదా ఎస్ఓఎస్ ప్రారంభించమంటారా?"
            } else {
                "I am here to help you. What happened? Tell me your symptom: breathing, chest pain, bleeding, accident, or should I send SOS?"
            }
            return TriageResult(
                spokenResponse = response,
                isEmergency = true,
                pendingAction = PendingVoiceAction.TriggerSos,
                identifiedCategory = BodyPartCategory.GENERAL_EMERGENCY,
                detectedLanguage = detectedLang,
                isTriageQuestion = true
            )
        }

        // Default friendly fallback
        val defaultReply = if (detectedLang == Language.TELUGU) {
            "మీ సమస్యను సహజంగా చెప్పండి: 'ఊపిరి ఆడట్లేదు', 'ఛాతిలో నొప్పి', 'ప్రమాదం జరిగింది', 'రక్తం వస్తోంది', లేదా 'అంబులెన్స్ కావాలి'."
        } else {
            "Please describe what you are feeling: 'difficulty breathing', 'chest pain', 'accident', 'bleeding', or say 'need ambulance'."
        }
        return TriageResult(
            spokenResponse = defaultReply,
            isEmergency = false,
            pendingAction = null,
            identifiedCategory = null,
            detectedLanguage = detectedLang,
            isTriageQuestion = false
        )
    }

    fun isConfirmationAffirmative(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        return lower.contains("yes") || lower.contains("yeah") || lower.contains("call") ||
                lower.contains("sure") || lower.contains("ok") || lower.contains("okay") ||
                lower.contains("అవును") || lower.contains("చెయ్యి") || lower.contains("చేయి") ||
                lower.contains("కాల్") || lower.contains("సరే") || lower.contains("ఖచ్చితంగా")
    }

    fun isConfirmationNegative(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        return lower.contains("no") || lower.contains("cancel") || lower.contains("stop") ||
                lower.contains("don't") || lower.contains("dont") ||
                lower.contains("వద్దు") || lower.contains("రద్దు") || lower.contains("ఆపు") ||
                lower.contains("చేయవద్దు") || lower.contains("వద్దులే")
    }
}
