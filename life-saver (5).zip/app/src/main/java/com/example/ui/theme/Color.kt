package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// "Public Safety Emergency" Clean Bright Theme Palette
val ImmersiveBackground = Color(0xFFF8FAFC) // Slate 50 - clean, bright, professional canvas
val ImmersiveSurface = Color(0xFFFFFFFF) // Crisp white
val ImmersiveSurfaceVariant = Color(0xFFF1F5F9) // Slate 100
val ImmersiveSurfaceCard = Color(0xFFFFFFFF) // Elevated white card
val ImmersiveBorder = Color(0xFFE2E8F0) // Slate 200 - refined, clean border
val ImmersiveTextPrimary = Color(0xFF0F172A) // Slate 900 - ultra-high contrast, legible
val ImmersiveTextSecondary = Color(0xFF475569) // Slate 600 - crisp secondary label

// Emergency Action Accents
val ImmersiveRedSos = Color(0xFFD32F2F) // Deep, authoritative emergency red
val ImmersiveRedActive = Color(0xFFB71C1C)
val ImmersiveRedBorder = Color(0xFFFFCDD2) // Soft red border
val ImmersiveRedGlow = Color(0x2ED32F2F) // Subtle, clean emergency glow
val ImmersiveRedText = Color(0xFFB71C1C) // Deep readable red

// Deep Trust Navy & Blue Accents
val ImmersiveLavender = Color(0xFF1E3A8A) // Authoritative Deep Safety Navy
val ImmersiveLavenderDark = Color(0xFFEFF6FF) // Soft blue tint container
val ImmersiveHospitalBlue = Color(0xFF0284C7) // Medical sky blue
val ImmersiveHospitalBlueDark = Color(0xFFF0F9FF) // Soft cyan tint
val ImmersiveActiveGreen = Color(0xFF16A34A) // Trust emerald green

// High-contrast emergency theme colors
val EmergencyRed = Color(0xFFD32F2F)
val EmergencyRedDark = Color(0xFFB71C1C)
val EmergencyRedBright = Color(0xFFEF4444)
val EmergencyRedContainer = Color(0xFFFEE2E2)
val EmergencyRedOnContainer = Color(0xFF7F1D1D)

val EmergencyAmbulanceTeal = Color(0xFF059669)
val EmergencyAmbulanceTealDark = Color(0xFF065F46)

val EmergencyFireOrange = Color(0xFFEA580C)
val EmergencyFireOrangeDark = Color(0xFF9A3412)

val EmergencyPoliceBlue = Color(0xFF1D4ED8)
val EmergencyPoliceBlueDark = Color(0xFF1E3A8A)

val EmergencyHospitalGreen = Color(0xFF15803D)
val EmergencyAlertYellow = Color(0xFFD97706)

val DarkSurface = Color(0xFFFFFFFF)
val DarkSurfaceElevated = Color(0xFFF8FAFC)
val DarkSurfaceCard = Color(0xFFFFFFFF)
val DarkBorder = Color(0xFFE2E8F0)
val LightSurface = Color(0xFFF8FAFC)
val LightSurfaceCard = Color(0xFFFFFFFF)
