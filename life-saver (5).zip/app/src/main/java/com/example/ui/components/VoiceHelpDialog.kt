package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.Language
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.voice.PendingVoiceAction
import com.example.voice.VoiceConversationState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceHelpDialog(
    lang: Language,
    conversationState: VoiceConversationState,
    pendingAction: PendingVoiceAction?,
    isListening: Boolean,
    recognizedText: String,
    assistantFeedback: String,
    onStartListening: () -> Unit,
    onConfirmAction: () -> Unit,
    onCancelAction: () -> Unit,
    onSelectEmergencySituation: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_help_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.22f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_help_scale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(28.dp))
                .testTag("voice_help_dialog"),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, ImmersiveBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEFF6FF))
                                .border(1.dp, Color(0xFFBFDBFE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Voice Help",
                                tint = Color(0xFF1D4ED8),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (lang == Language.TELUGU) "వాయిస్ సహాయం" else "Voice Emergency Help",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = ImmersiveTextPrimary
                            )
                            Text(
                                text = if (lang == Language.TELUGU) "పరిస్థితిని మాట్లాడండి లేదా తాకండి" else "Speak your emergency or tap below",
                                fontSize = 11.sp,
                                color = Color(0xFF1D4ED8),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_voice_help_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = ImmersiveTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Central Large Pulsing Microphone Button
                Box(
                    modifier = Modifier.size(130.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Pulsing Outer Aura
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                if (isListening) Color(0xFFFEE2E2)
                                else Color(0xFFDBEAFE)
                            )
                    )

                    // Central Interactive Mic Disc
                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                            .background(
                                if (isListening) Color(0xFFDC2626)
                                else Color(0xFF1D4ED8)
                            )
                            .border(
                                4.dp,
                                if (isListening) Color(0xFFFCA5A5) else Color(0xFF93C5FD),
                                CircleShape
                            )
                            .clickable(onClick = onStartListening)
                            .testTag("voice_help_mic_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Hearing else Icons.Default.Mic,
                            contentDescription = "Microphone",
                            tint = Color.White,
                            modifier = Modifier.size(46.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Status Text
                Text(
                    text = if (isListening) {
                        if (lang == Language.TELUGU) "వినబడుతోంది... మీ సమస్యను చెప్పండి" else "Listening... Please speak now"
                    } else {
                        if (lang == Language.TELUGU) "మాట్లాడటానికి మైక్ తాకండి" else "Tap Mic to Speak"
                    },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isListening) Color(0xFFDC2626) else Color(0xFF1D4ED8),
                    textAlign = TextAlign.Center
                )

                // CRITICAL VOICE CONFIRMATION BANNER
                AnimatedVisibility(visible = conversationState == VoiceConversationState.CONFIRMATION && pendingAction != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFFFFFBEB))
                            .border(2.dp, Color(0xFFF59E0B), RoundedCornerShape(20.dp))
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "⚠️", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == Language.TELUGU) "నిర్ధారణ అవసరం" else "Confirmation Required",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF92400E)
                            )
                        }

                        val queryText = when (pendingAction) {
                            is PendingVoiceAction.CallEmergency ->
                                if (lang == Language.TELUGU)
                                    "మీరు ${pendingAction.labelTe}కి కాల్ చేయాలనుకుంటున్నారా?"
                                else
                                    "Would you like to call ${pendingAction.labelEn}?"
                            is PendingVoiceAction.TriggerSos ->
                                if (lang == Language.TELUGU)
                                    "మీరు అత్యవసర ఎస్ఓఎస్ ప్రారంభించాలనుకుంటున్నారా?"
                                else
                                    "Would you like to trigger Emergency SOS?"
                            is PendingVoiceAction.SendSosMessage ->
                                if (lang == Language.TELUGU)
                                    "${pendingAction.targetName}కి ఎస్ఓఎస్ పంపమంటారా?"
                                else
                                    "Send emergency SOS to ${pendingAction.targetName}?"
                            else ->
                                if (lang == Language.TELUGU) "చర్యను కొనసాగించమంటారా?" else "Confirm this action?"
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = queryText,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF78350F)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onConfirmAction,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("voice_dialog_yes_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = "Yes", tint = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (lang == Language.TELUGU) "అవును (కాల్)" else "YES",
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Button(
                                onClick = onCancelAction,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("voice_dialog_no_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "No", tint = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (lang == Language.TELUGU) "వద్దు (ఆపు)" else "NO",
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }

                // Spoken Transcript & Feedback Card
                AnimatedVisibility(visible = recognizedText.isNotBlank() || assistantFeedback.isNotBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFFF8FAFC))
                            .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        if (recognizedText.isNotBlank()) {
                            Text(
                                text = "🗣️ \"$recognizedText\"",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0284C7)
                            )
                        }
                        if (assistantFeedback.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "📢 $assistantFeedback",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = ImmersiveTextPrimary,
                                lineHeight = 19.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // One-Tap Quick Emergency Situation Chips (Covering all requested scenarios)
                Text(
                    text = if (lang == Language.TELUGU) "లేదా అత్యవసర సమస్యను ఎంచుకోండి:" else "Or tap for instant spoken guidance:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = ImmersiveTextSecondary,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EmergencyTopicChip(
                        emoji = "🫁",
                        title = if (lang == Language.TELUGU) "శ్వాస ఆడట్లేదు" else "Shortness of Breath",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నాకు ఊపిరి తీసుకోవడం కష్టంగా ఉంది" else "difficulty breathing") }
                    )

                    EmergencyTopicChip(
                        emoji = "❤️",
                        title = if (lang == Language.TELUGU) "గుండె నొప్పి" else "Chest Pain / Heart",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నాకు ఛాతిలో నొప్పి ఉంది" else "chest pain") }
                    )

                    EmergencyTopicChip(
                        emoji = "🧠",
                        title = if (lang == Language.TELUGU) "తల తిరుగుతోంది" else "Dizziness / Head",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నాకు తల తిరుగుతోంది" else "dizziness") }
                    )

                    EmergencyTopicChip(
                        emoji = "🦵",
                        title = if (lang == Language.TELUGU) "కాలు విరిగింది" else "Broken Leg",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నా కాలు విరిగింది" else "broken leg") }
                    )

                    EmergencyTopicChip(
                        emoji = "🩸",
                        title = if (lang == Language.TELUGU) "రక్తం వస్తోంది" else "Severe Bleeding",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నాకు రక్తం వస్తోంది" else "bleeding") }
                    )

                    EmergencyTopicChip(
                        emoji = "🩺",
                        title = if (lang == Language.TELUGU) "కడుపు నొప్పి" else "Stomach Pain",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నాకు కడుపు నొప్పిగా ఉంది" else "stomach pain") }
                    )

                    EmergencyTopicChip(
                        emoji = "🩹",
                        title = if (lang == Language.TELUGU) "కాలిన గాయం" else "Burns / Fire",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నాకు మంటగా ఉంది" else "burns") }
                    )

                    EmergencyTopicChip(
                        emoji = "🚗",
                        title = if (lang == Language.TELUGU) "ప్రమాదం జరిగింది" else "Road Accident",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "నాకు ప్రమాదం జరిగింది" else "accident") }
                    )

                    EmergencyTopicChip(
                        emoji = "🐍",
                        title = if (lang == Language.TELUGU) "పాము కాటు" else "Snake Bite",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "పాము కాటు" else "snake bite") }
                    )

                    EmergencyTopicChip(
                        emoji = "🚑",
                        title = if (lang == Language.TELUGU) "అంబులెన్స్" else "Ambulance",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "అంబులెన్స్ కావాలి" else "need ambulance") }
                    )

                    EmergencyTopicChip(
                        emoji = "👮",
                        title = if (lang == Language.TELUGU) "పోలీసులు" else "Police",
                        onClick = { onSelectEmergencySituation(if (lang == Language.TELUGU) "పోలీసులు కావాలి" else "need police") }
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("dismiss_voice_help_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = if (lang == Language.TELUGU) "ముగించండి" else "DONE",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun EmergencyTopicChip(
    emoji: String,
    title: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF1F5F9))
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = emoji, fontSize = 16.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = ImmersiveTextPrimary
            )
        }
    }
}
