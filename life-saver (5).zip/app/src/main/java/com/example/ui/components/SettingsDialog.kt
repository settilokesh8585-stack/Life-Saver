package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.EmergencyContact
import com.example.model.Language
import com.example.model.MedicalProfile
import com.example.model.UserEmergencyProfile
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.ImmersiveActiveGreen
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveHospitalBlue
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveRedSos
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings

@Composable
fun SettingsDialog(
    lang: Language,
    currentProfile: UserEmergencyProfile,
    isShakeSosEnabled: Boolean,
    onToggleShakeSos: (Boolean) -> Unit,
    isAudioFeedbackEnabled: Boolean,
    onToggleAudioFeedback: (Boolean) -> Unit,
    onSave: (UserEmergencyProfile) -> Unit,
    onDismiss: () -> Unit
) {
    var myPhone by remember { mutableStateOf(currentProfile.myPhoneNumber) }
    var primaryName by remember { mutableStateOf(currentProfile.primaryContact.name) }
    var primaryPhone by remember { mutableStateOf(currentProfile.primaryContact.phone) }
    var secondaryPhone by remember { mutableStateOf(currentProfile.secondaryContact.phone) }
    var customNote by remember { mutableStateOf(currentProfile.customNote) }

    // Medical fields
    var bloodGroup by remember { mutableStateOf(currentProfile.medicalProfile.bloodGroup) }
    var allergies by remember { mutableStateOf(currentProfile.medicalProfile.allergies) }
    var medications by remember { mutableStateOf(currentProfile.medicalProfile.medications) }
    var medicalConditions by remember { mutableStateOf(currentProfile.medicalProfile.medicalConditions) }
    var emergencyNotes by remember { mutableStateOf(currentProfile.medicalProfile.emergencyNotes) }

    val bloodGroups = listOf("O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp)
                .testTag("settings_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = ImmersiveSurface),
            border = BorderStroke(1.dp, ImmersiveBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Title Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = EmergencyStrings.settingsTitle(lang),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveTextPrimary
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = ImmersiveTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // SECTION 1: SAFETY & CONTROLS (Shake SOS & Audio Feedback)
                Text(
                    text = if (lang == Language.TELUGU) "భద్రత & అలర్ట్ సెట్టింగులు" else "Safety & Alert Controls",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ImmersiveLavender
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Shake SOS Toggle Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(ImmersiveSurfaceVariant)
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Vibration,
                                contentDescription = null,
                                tint = if (isShakeSosEnabled) ImmersiveRedSos else ImmersiveTextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = EmergencyStrings.shakeSosTitle(lang),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveTextPrimary
                                )
                                Text(
                                    text = EmergencyStrings.shakeSosSensorStatus(lang, isShakeSosEnabled),
                                    fontSize = 11.sp,
                                    color = if (isShakeSosEnabled) ImmersiveActiveGreen else ImmersiveTextSecondary
                                )
                            }
                        }
                        Switch(
                            checked = isShakeSosEnabled,
                            onCheckedChange = { onToggleShakeSos(it) },
                            modifier = Modifier.testTag("shake_sos_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = ImmersiveRedSos,
                                uncheckedThumbColor = ImmersiveTextSecondary,
                                uncheckedTrackColor = ImmersiveSurface
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Audio Feedback Toggle Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(ImmersiveSurfaceVariant)
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = if (isAudioFeedbackEnabled) ImmersiveHospitalBlue else ImmersiveTextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = EmergencyStrings.audioFeedbackTitle(lang),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveTextPrimary
                                )
                                Text(
                                    text = EmergencyStrings.audioFeedbackStatus(lang, isAudioFeedbackEnabled),
                                    fontSize = 11.sp,
                                    color = if (isAudioFeedbackEnabled) ImmersiveHospitalBlue else EmergencyAlertYellow
                                )
                            }
                        }
                        Switch(
                            checked = isAudioFeedbackEnabled,
                            onCheckedChange = { onToggleAudioFeedback(it) },
                            modifier = Modifier.testTag("audio_feedback_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = ImmersiveHospitalBlue,
                                uncheckedThumbColor = ImmersiveTextSecondary,
                                uncheckedTrackColor = ImmersiveSurface
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // SECTION 2: CONTACTS
                Text(
                    text = if (lang == Language.TELUGU) "అత్యవసర కాంటాక్టులు" else "Emergency Contacts",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ImmersiveLavender
                )
                Spacer(modifier = Modifier.height(8.dp))

                // My Phone Number Field
                OutlinedTextField(
                    value = myPhone,
                    onValueChange = { myPhone = it },
                    label = { Text(EmergencyStrings.myPhoneNumberLabel(lang)) },
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = ImmersiveLavender)
                    },
                    placeholder = { Text("+91 98765 43210") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("my_phone_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder,
                        focusedLabelColor = ImmersiveLavender,
                        unfocusedLabelColor = ImmersiveTextSecondary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Primary Emergency Contact Name
                OutlinedTextField(
                    value = primaryName,
                    onValueChange = { primaryName = it },
                    label = { Text(EmergencyStrings.primaryContactName(lang)) },
                    leadingIcon = {
                        Icon(Icons.Default.Person, contentDescription = null, tint = ImmersiveHospitalBlue)
                    },
                    placeholder = { Text("Spouse / Parent / Friend") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("primary_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveHospitalBlue,
                        unfocusedBorderColor = ImmersiveBorder,
                        focusedLabelColor = ImmersiveHospitalBlue,
                        unfocusedLabelColor = ImmersiveTextSecondary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Primary Emergency Contact Phone
                OutlinedTextField(
                    value = primaryPhone,
                    onValueChange = { primaryPhone = it },
                    label = { Text(EmergencyStrings.primaryContactPhone(lang)) },
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = ImmersiveHospitalBlue)
                    },
                    placeholder = { Text("+91 91234 56789") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("primary_phone_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveHospitalBlue,
                        unfocusedBorderColor = ImmersiveBorder,
                        focusedLabelColor = ImmersiveHospitalBlue,
                        unfocusedLabelColor = ImmersiveTextSecondary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Secondary Emergency Contact Phone
                OutlinedTextField(
                    value = secondaryPhone,
                    onValueChange = { secondaryPhone = it },
                    label = { Text(EmergencyStrings.secondaryContactPhone(lang)) },
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = ImmersiveTextSecondary)
                    },
                    placeholder = { Text("+91 90000 00000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("secondary_phone_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder,
                        focusedLabelColor = ImmersiveLavender,
                        unfocusedLabelColor = ImmersiveTextSecondary
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                // SECTION 3: MEDICAL INFO CARD DETAILS
                Text(
                    text = EmergencyStrings.medicalInfoTitle(lang),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ImmersiveRedSos
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Blood Group Selector
                Text(
                    text = "${EmergencyStrings.bloodGroupLabel(lang)}:",
                    fontSize = 12.sp,
                    color = ImmersiveTextSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    bloodGroups.take(4).forEach { bg ->
                        val isSelected = bloodGroup.equals(bg, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) ImmersiveRedSos else ImmersiveSurfaceVariant
                                )
                                .clickable { bloodGroup = bg }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bg,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else ImmersiveTextPrimary
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    bloodGroups.takeLast(4).forEach { bg ->
                        val isSelected = bloodGroup.equals(bg, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) ImmersiveRedSos else ImmersiveSurfaceVariant
                                )
                                .clickable { bloodGroup = bg }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bg,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else ImmersiveTextPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = allergies,
                    onValueChange = { allergies = it },
                    label = { Text(EmergencyStrings.allergiesLabel(lang)) },
                    placeholder = { Text("e.g., Penicillin, Peanuts") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = medications,
                    onValueChange = { medications = it },
                    label = { Text(EmergencyStrings.medicationsLabel(lang)) },
                    placeholder = { Text("e.g., Insulin, BP medication") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = medicalConditions,
                    onValueChange = { medicalConditions = it },
                    label = { Text(EmergencyStrings.conditionsLabel(lang)) },
                    placeholder = { Text("e.g., Diabetic, Asthma, Heart condition") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = emergencyNotes,
                    onValueChange = { emergencyNotes = it },
                    label = { Text(EmergencyStrings.emergencyNotesLabel(lang)) },
                    placeholder = { Text("e.g., Organ donor, emergency notes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Note
                OutlinedTextField(
                    value = customNote,
                    onValueChange = { customNote = it },
                    label = { Text(if (lang == Language.TELUGU) "అదనపు సూచనలు (ఐచ్ఛికం)" else "Additional SOS Message Note") },
                    placeholder = { Text("e.g., Key under the mat, gate code") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_note_input"),
                    maxLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Save Button
                Button(
                    onClick = {
                        val updated = UserEmergencyProfile(
                            myPhoneNumber = myPhone.trim(),
                            primaryContact = EmergencyContact(
                                name = primaryName.trim(),
                                phone = primaryPhone.trim()
                            ),
                            secondaryContact = EmergencyContact(
                                name = "",
                                phone = secondaryPhone.trim()
                            ),
                            customNote = customNote.trim(),
                            medicalProfile = MedicalProfile(
                                bloodGroup = bloodGroup.trim(),
                                allergies = allergies.trim(),
                                medications = medications.trim(),
                                medicalConditions = medicalConditions.trim(),
                                emergencyNotes = emergencyNotes.trim()
                            )
                        )
                        onSave(updated)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_settings_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ImmersiveRedSos)
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = "Save",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = EmergencyStrings.save(lang),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // ABOUT SECTION WITH ORIGINAL LIFE SAVER LOGO
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(ImmersiveSurfaceVariant)
                        .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
                        .padding(16.dp)
                        .testTag("settings_about_section")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF4A0518)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_life_saver_logo),
                                    contentDescription = "Life Saver Original Logo",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .size(54.dp)
                                        .testTag("settings_life_saver_logo")
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Life Saver",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = ImmersiveTextPrimary
                                )
                                Text(
                                    text = if (lang == Language.TELUGU) "అత్యవసర రక్షణ • ఆఫ్‌లైన్" else "Emergency SOS & Offline First Aid",
                                    fontSize = 12.sp,
                                    color = ImmersiveLavender,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "v1.0 • Water-Drop Life Saving Emblem",
                                    fontSize = 10.sp,
                                    color = Color(0xFFFFD54F),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = if (lang == Language.TELUGU)
                                "నీటి బిందువు మరియు మానవ ఆకారంతో కూడిన ఈ అధికారిక లోగో జీవ రక్షణను సూచిస్తుంది. ఇంటర్నెట్ లేకపోయినా 108, 112, 101 కి తక్షణమే కాల్ చేయవచ్చు."
                            else
                                "Original water-drop design with human silhouette representing immediate life preservation and emergency care. 100% offline-ready for 108, 112, and 101 emergency response.",
                            fontSize = 11.sp,
                            color = ImmersiveTextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
