package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveSurfaceCard
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings

/**
 * High-Accessibility Emergency Action Grid designed for EVERYONE,
 * especially elderly individuals and users with limited literacy.
 *
 * Features:
 * - 6 Large, unmistakable emergency actions: Ambulance 108, Police 112, Fire 101, Hospital, My Location, Voice Help
 * - Very large recognizable icons (34dp inside 54dp high-contrast circular badges)
 * - Minimal, high-contrast written text
 * - Substantial touch targets (>90dp height, easily tap-able under panic)
 * - Immediate Text-To-Speech (TTS) spoken voice confirmation in Telugu or English
 */
@Composable
fun AccessibleEmergencyGrid(
    lang: Language,
    address: String?,
    onDialAmbulance: () -> Unit,
    onDialPolice: () -> Unit,
    onDialFire: () -> Unit,
    onOpenHospitals: () -> Unit,
    onMyLocationClick: () -> Unit,
    onVoiceHelpClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Row 1: Ambulance 108 & Police 112
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AccessibleEmergencyActionCard(
                number = "108",
                label = EmergencyStrings.ambulanceLabel(lang),
                subLabel = EmergencyStrings.tapToCall(lang),
                icon = Icons.Default.LocalHospital,
                iconTint = Color(0xFF059669),
                iconBgColor = Color(0xFFECFDF5),
                borderColor = Color(0xFFA7F3D0),
                numberColor = Color(0xFF065F46),
                testTag = "dial_108_button",
                modifier = Modifier.weight(1f),
                onClick = onDialAmbulance
            )

            AccessibleEmergencyActionCard(
                number = "112",
                label = EmergencyStrings.policeLabel(lang),
                subLabel = EmergencyStrings.tapToCall(lang),
                icon = Icons.Default.Security,
                iconTint = Color(0xFF1D4ED8),
                iconBgColor = Color(0xFFEFF6FF),
                borderColor = Color(0xFFBFDBFE),
                numberColor = Color(0xFF1E40AF),
                testTag = "dial_112_button",
                modifier = Modifier.weight(1f),
                onClick = onDialPolice
            )
        }

        // Row 2: Fire 101 & Hospital (Nearby Maps)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AccessibleEmergencyActionCard(
                number = "101",
                label = EmergencyStrings.fireLabel(lang),
                subLabel = EmergencyStrings.tapToCall(lang),
                icon = Icons.Default.LocalFireDepartment,
                iconTint = Color(0xFFEA580C),
                iconBgColor = Color(0xFFFFF7ED),
                borderColor = Color(0xFFFED7AA),
                numberColor = Color(0xFFC2410C),
                testTag = "dial_101_button",
                modifier = Modifier.weight(1f),
                onClick = onDialFire
            )

            AccessibleEmergencyActionCard(
                number = null,
                badgeTag = "MAPS",
                label = EmergencyStrings.hospitalLabel(lang),
                subLabel = EmergencyStrings.nearbyMaps(lang),
                icon = Icons.Default.MedicalServices,
                iconTint = Color(0xFF0284C7),
                iconBgColor = Color(0xFFF0F9FF),
                borderColor = Color(0xFFBAE6FD),
                numberColor = Color(0xFF0369A1),
                testTag = "nearby_hospitals_button",
                modifier = Modifier.weight(1f),
                onClick = onOpenHospitals
            )
        }

        // Row 3: My Location & Voice Help
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AccessibleEmergencyActionCard(
                number = null,
                badgeTag = "GPS",
                label = EmergencyStrings.myLocationLabel(lang),
                subLabel = EmergencyStrings.findMyLocation(lang),
                icon = Icons.Default.LocationOn,
                iconTint = Color(0xFFD97706),
                iconBgColor = Color(0xFFFFFBEB),
                borderColor = Color(0xFFFDE68A),
                numberColor = Color(0xFFB45309),
                testTag = "my_location_action_button",
                modifier = Modifier.weight(1f),
                onClick = onMyLocationClick
            )

            AccessibleEmergencyActionCard(
                number = null,
                badgeTag = "VOICE",
                label = EmergencyStrings.voiceHelpLabel(lang),
                subLabel = EmergencyStrings.tapToSpeak(lang),
                icon = Icons.Default.Mic,
                iconTint = Color(0xFF7C3AED),
                iconBgColor = Color(0xFFF5F3FF),
                borderColor = Color(0xFFDDD6FE),
                numberColor = Color(0xFF6D28D9),
                testTag = "voice_help_action_button",
                modifier = Modifier.weight(1f),
                onClick = onVoiceHelpClick
            )
        }
    }
}

@Composable
private fun AccessibleEmergencyActionCard(
    number: String?,
    label: String,
    subLabel: String,
    icon: ImageVector,
    iconTint: Color,
    iconBgColor: Color,
    borderColor: Color,
    numberColor: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    badgeTag: String? = null,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Large circular icon badge (>48dp touch and visual clarity)
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(iconBgColor)
                    .border(2.dp, borderColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconTint,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Number if helpline, or prominent title
            if (number != null) {
                Text(
                    text = number,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = numberColor,
                    textAlign = TextAlign.Center
                )
            } else if (badgeTag != null) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(iconBgColor)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeTag,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = numberColor,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = label,
                fontSize = if (number != null) 14.sp else 15.sp,
                fontWeight = FontWeight.Bold,
                color = ImmersiveTextPrimary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subLabel,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = ImmersiveTextSecondary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
