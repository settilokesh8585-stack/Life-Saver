package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.example.service.VoiceEmergencyService
import com.example.ui.LifeSaverScreen
import com.example.ui.LifeSaverViewModel
import com.example.ui.SplashScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LifeSaverViewModel by viewModels()

    private val voiceCommandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(VoiceEmergencyService.EXTRA_DETECTED_TEXT)
            if (!text.isNullOrBlank()) {
                viewModel.handleVoiceCommand(text)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val isDirectSosTrigger = intent?.getBooleanExtra("TRIGGER_SOS_NOW", false) == true
        handleIntent(intent)

        val filter = IntentFilter(VoiceEmergencyService.ACTION_VOICE_COMMAND_DETECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(voiceCommandReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(voiceCommandReceiver, filter)
        }

        setContent {
            MyApplicationTheme(darkTheme = true) {
                var showSplash by remember { mutableStateOf(!isDirectSosTrigger) }

                if (showSplash) {
                    SplashScreen(
                        onSplashFinished = { showSplash = false }
                    )
                } else {
                    LifeSaverScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.getBooleanExtra("TRIGGER_SOS_NOW", false) == true) {
            viewModel.startSosCountdown(this)
        }
        val detectedVoice = intent?.getStringExtra(VoiceEmergencyService.EXTRA_DETECTED_TEXT)
        if (!detectedVoice.isNullOrBlank()) {
            viewModel.handleVoiceCommand(detectedVoice)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(voiceCommandReceiver)
        } catch (e: Exception) {
            // Receiver might not be registered
        }
        super.onDestroy()
    }
}
