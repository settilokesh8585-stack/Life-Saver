package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PreferencesManager
import com.example.model.Language
import com.example.model.MedicalProfile
import com.example.util.EmergencyStrings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Life Saver", appName)
  }

  @Test
  fun `medical profile persists correctly in preferences`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = PreferencesManager(context)

    val medical = MedicalProfile(
      bloodGroup = "O+",
      allergies = "Penicillin, Sulfa",
      medications = "Insulin",
      medicalConditions = "Type 1 Diabetic",
      emergencyNotes = "Organ Donor"
    )

    prefs.saveMedicalProfile(medical)

    val loadedProfile = prefs.userProfile.value
    assertEquals("O+", loadedProfile.medicalProfile.bloodGroup)
    assertEquals("Penicillin, Sulfa", loadedProfile.medicalProfile.allergies)
    assertEquals("Insulin", loadedProfile.medicalProfile.medications)
    assertEquals("Type 1 Diabetic", loadedProfile.medicalProfile.medicalConditions)
    assertEquals("Organ Donor", loadedProfile.medicalProfile.emergencyNotes)
    assertTrue(loadedProfile.medicalProfile.isConfigured)
  }

  @Test
  fun `shake sos and audio feedback toggles persist correctly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = PreferencesManager(context)

    // Initial defaults: Shake SOS is optional (disabled by default until user enables it)
    assertFalse(prefs.isShakeSosEnabled.value)
    assertTrue(prefs.isAudioFeedbackEnabled.value)

    prefs.setShakeSosEnabled(true)
    assertTrue(prefs.isShakeSosEnabled.value)

    prefs.setAudioFeedbackEnabled(false)
    assertFalse(prefs.isAudioFeedbackEnabled.value)

    prefs.setShakeSosEnabled(false)
    assertFalse(prefs.isShakeSosEnabled.value)
  }

  @Test
  fun `buildSosMessage formats medical details in English and Telugu`() {
    val medical = MedicalProfile(
      bloodGroup = "B+",
      allergies = "Peanuts",
      medications = "Asthma Inhaler"
    )

    val englishMsg = EmergencyStrings.buildSosMessage(
      lang = Language.ENGLISH,
      myPhone = "+91 99999 11111",
      latitude = 17.4399,
      longitude = 78.3908,
      address = "HITEC City, Hyderabad",
      timestamp = "10:30 AM",
      customNote = "Urgent",
      medicalProfile = medical
    )

    assertTrue(englishMsg.contains("Blood: B+"))
    assertTrue(englishMsg.contains("Allergies: Peanuts"))
    assertTrue(englishMsg.contains("Meds: Asthma Inhaler"))
    assertTrue(englishMsg.contains("HITEC City, Hyderabad"))

    val teluguMsg = EmergencyStrings.buildSosMessage(
      lang = Language.TELUGU,
      myPhone = "+91 99999 11111",
      latitude = 17.4399,
      longitude = 78.3908,
      address = "హైటెక్ సిటీ, హైదరాబాద్",
      timestamp = "10:30 AM",
      customNote = "అత్యవసరం",
      medicalProfile = medical
    )

    assertTrue(teluguMsg.contains("Blood: B+"))
    assertTrue(teluguMsg.contains("Allergies: Peanuts"))
  }

  @Test
  fun `medical strings and localization verify correctly`() {
    assertEquals("Add Medical Info", EmergencyStrings.addMedicalInfo(Language.ENGLISH))
    assertEquals("వైద్య వివరాలు జోడించండి", EmergencyStrings.addMedicalInfo(Language.TELUGU))

    assertEquals("Edit Medical Info", EmergencyStrings.editMedicalInfo(Language.ENGLISH))
    assertEquals("వైద్య వివరాలు సవరించండి", EmergencyStrings.editMedicalInfo(Language.TELUGU))

    assertEquals("Important Medical Notes", EmergencyStrings.importantMedicalNotes(Language.ENGLISH))
    assertEquals("ముఖ్యమైన వైద్య సూచనలు", EmergencyStrings.importantMedicalNotes(Language.TELUGU))

    assertEquals("CANCEL", EmergencyStrings.cancel(Language.ENGLISH))
    assertEquals("రద్దు చేయండి", EmergencyStrings.cancel(Language.TELUGU))
  }

  @Test
  fun `launcher icon and life saver logo resource exist and load properly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // 1. Verify the original Life Saver logo drawable exists and resolves
    val logoDrawable = androidx.core.content.ContextCompat.getDrawable(context, R.drawable.img_life_saver_logo)
    org.junit.Assert.assertNotNull("Life Saver logo drawable must exist", logoDrawable)

    // 2. Verify launcher icon is set in ApplicationInfo
    val appInfo = context.packageManager.getApplicationInfo(context.packageName, 0)
    assertTrue("Launcher icon must be configured", appInfo.icon != 0)

    // 3. Verify launcher icon drawable loads properly
    val launcherDrawable = context.packageManager.getApplicationIcon(appInfo)
    org.junit.Assert.assertNotNull("Launcher icon must load from package manager", launcherDrawable)
  }

  @Test
  fun `voice triage detects respiratory emergency in Telugu and English`() {
    val teluguResult = com.example.voice.VoiceTriageEngine.triageSymptom(
      "నాకు ఊపిరి తీసుకోవడం కష్టంగా ఉంది",
      Language.TELUGU
    )
    assertTrue(teluguResult.isEmergency)
    assertEquals(com.example.voice.BodyPartCategory.LUNGS_BREATHING, teluguResult.identifiedCategory)
    assertTrue(teluguResult.spokenResponse.contains("నిశ్శబ్దంగా") || teluguResult.spokenResponse.contains("108"))
    assertTrue(teluguResult.pendingAction is com.example.voice.PendingVoiceAction.CallEmergency)
    assertEquals("108", (teluguResult.pendingAction as com.example.voice.PendingVoiceAction.CallEmergency).number)

    val englishResult = com.example.voice.VoiceTriageEngine.triageSymptom(
      "i am having trouble breathing",
      Language.ENGLISH
    )
    assertTrue(englishResult.isEmergency)
    assertEquals(com.example.voice.BodyPartCategory.LUNGS_BREATHING, englishResult.identifiedCategory)
    assertTrue(englishResult.spokenResponse.contains("Sit upright") || englishResult.spokenResponse.contains("108"))
  }

  @Test
  fun `voice triage detects chest pain emergency in Telugu and English`() {
    val resultTe = com.example.voice.VoiceTriageEngine.triageSymptom(
      "నాకు ఛాతిలో నొప్పి ఉంది",
      Language.TELUGU
    )
    assertTrue(resultTe.isEmergency)
    assertEquals(com.example.voice.BodyPartCategory.CHEST_HEART, resultTe.identifiedCategory)
    assertTrue(resultTe.pendingAction is com.example.voice.PendingVoiceAction.CallEmergency)

    val resultEn = com.example.voice.VoiceTriageEngine.triageSymptom(
      "i have severe chest pain",
      Language.ENGLISH
    )
    assertTrue(resultEn.isEmergency)
    assertEquals(com.example.voice.BodyPartCategory.CHEST_HEART, resultEn.identifiedCategory)
  }

  @Test
  fun `voice triage handles bleeding with direct pressure advice`() {
    val resultTe = com.example.voice.VoiceTriageEngine.triageSymptom(
      "నాకు రక్తం వస్తోంది",
      Language.TELUGU
    )
    assertTrue(resultTe.isEmergency)
    assertEquals(com.example.voice.BodyPartCategory.SKIN_WHOLE_BODY, resultTe.identifiedCategory)
    assertTrue(resultTe.spokenResponse.contains("ఒత్తిడి") || resultTe.spokenResponse.contains("గుడ్డతో"))

    val resultEn = com.example.voice.VoiceTriageEngine.triageSymptom(
      "heavy bleeding from wound",
      Language.ENGLISH
    )
    assertTrue(resultEn.isEmergency)
    assertEquals(com.example.voice.BodyPartCategory.SKIN_WHOLE_BODY, resultEn.identifiedCategory)
    assertTrue(resultEn.spokenResponse.contains("pressure") || resultEn.spokenResponse.contains("cloth"))
  }

  @Test
  fun `voice triage handles fracture and snake bite instructions`() {
    val fractureResult = com.example.voice.VoiceTriageEngine.triageSymptom(
      "నా కాలు విరిగింది",
      Language.TELUGU
    )
    assertEquals(com.example.voice.BodyPartCategory.LEGS_FEET, fractureResult.identifiedCategory)
    assertTrue(fractureResult.spokenResponse.contains("కదల్చవద్దు"))

    val snakeBiteResult = com.example.voice.VoiceTriageEngine.triageSymptom(
      "snake bit my leg",
      Language.ENGLISH
    )
    assertEquals(com.example.voice.BodyPartCategory.SKIN_WHOLE_BODY, snakeBiteResult.identifiedCategory)
    assertTrue(snakeBiteResult.spokenResponse.contains("calm") || snakeBiteResult.spokenResponse.contains("Do not cut"))
  }

  @Test
  fun `voice triage handles direct dispatch keywords for ambulance police fire and sos`() {
    val ambTe = com.example.voice.VoiceTriageEngine.triageSymptom("అంబులెన్స్ కావాలి", Language.TELUGU)
    assertEquals("108", (ambTe.pendingAction as com.example.voice.PendingVoiceAction.CallEmergency).number)

    val polTe = com.example.voice.VoiceTriageEngine.triageSymptom("పోలీసులు కావాలి", Language.TELUGU)
    assertEquals("112", (polTe.pendingAction as com.example.voice.PendingVoiceAction.CallEmergency).number)

    val fireEn = com.example.voice.VoiceTriageEngine.triageSymptom("fire brigade 101", Language.ENGLISH)
    assertEquals("101", (fireEn.pendingAction as com.example.voice.PendingVoiceAction.CallEmergency).number)

    val sosTe = com.example.voice.VoiceTriageEngine.triageSymptom("నాకు సహాయం కావాలి ఎస్ఓఎస్", Language.TELUGU)
    assertTrue(sosTe.pendingAction is com.example.voice.PendingVoiceAction.TriggerSos)
  }

  @Test
  fun `voice confirmation parser correctly identifies yes and no in Telugu and English`() {
    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationAffirmative("yes"))
    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationAffirmative("yeah call"))
    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationAffirmative("అవును"))
    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationAffirmative("కాల్ చేయండి"))

    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationNegative("no"))
    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationNegative("cancel that"))
    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationNegative("వద్దు"))
    assertTrue(com.example.voice.VoiceTriageEngine.isConfirmationNegative("రద్దు చేయి"))
  }
}

