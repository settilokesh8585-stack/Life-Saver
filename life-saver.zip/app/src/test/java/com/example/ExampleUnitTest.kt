package com.example

import com.example.model.CachedEmergencyPlace
import com.example.model.Language
import com.example.model.OfflineMapArea
import com.example.model.PlaceType
import com.example.util.BatteryState
import com.example.util.EmergencyStrings
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testBatteryAlertThresholds() {
    val normalBattery = BatteryState(level = 85, isCharging = false, isLow = false, isCritical = false)
    assertFalse(normalBattery.isLow)
    assertFalse(normalBattery.isCritical)

    val lowBattery = BatteryState(level = 18, isCharging = false, isLow = true, isCritical = false)
    assertTrue(lowBattery.isLow)
    assertFalse(lowBattery.isCritical)

    val criticalBattery = BatteryState(level = 8, isCharging = false, isLow = true, isCritical = true)
    assertTrue(criticalBattery.isLow)
    assertTrue(criticalBattery.isCritical)

    val chargingBattery = BatteryState(level = 15, isCharging = true, isLow = false, isCritical = false)
    assertFalse(chargingBattery.isLow)
    assertFalse(chargingBattery.isCritical)
  }

  @Test
  fun testBatteryStringsTranslation() {
    val enLow = EmergencyStrings.lowBatteryWarningTitle(Language.ENGLISH, 15)
    val teLow = EmergencyStrings.lowBatteryWarningTitle(Language.TELUGU, 15)
    assertTrue(enLow.contains("LOW BATTERY WARNING"))
    assertTrue(teLow.contains("తక్కువ బ్యాటరీ"))

    val enCrit = EmergencyStrings.criticalBatteryWarningTitle(Language.ENGLISH, 8)
    val teCrit = EmergencyStrings.criticalBatteryWarningTitle(Language.TELUGU, 8)
    assertTrue(enCrit.contains("CRITICAL BATTERY"))
    assertTrue(teCrit.contains("అత్యంత క్లిష్టమైన బ్యాటరీ"))
  }

  @Test
  fun testOfflineMapsStringsTranslation() {
    val enTitle = EmergencyStrings.offlineMapsSectionTitle(Language.ENGLISH)
    val teTitle = EmergencyStrings.offlineMapsSectionTitle(Language.TELUGU)
    assertEquals("Offline Maps & Emergency Cache", enTitle)
    assertEquals("ఆఫ్‌లైన్ మ్యాప్స్ & అత్యవసర కాష్", teTitle)

    val enBadge = EmergencyStrings.areaAvailableOfflineBadge(Language.ENGLISH)
    val teBadge = EmergencyStrings.areaAvailableOfflineBadge(Language.TELUGU)
    assertEquals("OFFLINE READY", enBadge)
    assertEquals("ఆఫ్‌లైన్ సిద్ధం", teBadge)
  }

  @Test
  fun testOfflineMapAreaStructure() {
    val place = CachedEmergencyPlace(
      id = "test_hospital",
      name = "Emergency Trauma Care",
      type = PlaceType.HOSPITAL,
      phone = "108",
      address = "Station Road",
      latitude = 17.44,
      longitude = 78.38,
      distanceKm = 1.2,
      bearingDegrees = 45f
    )
    val area = OfflineMapArea(
      id = "zone_1",
      name = "City Safe Zone",
      latitude = 17.44,
      longitude = 78.38,
      address = "Central District",
      cachedAtTimestamp = System.currentTimeMillis(),
      places = listOf(place),
      isOfflineAvailable = true
    )

    assertEquals(1, area.places.size)
    assertTrue(area.isOfflineAvailable)
    assertEquals(PlaceType.HOSPITAL, area.places[0].type)
    assertEquals("108", area.places[0].phone)
  }
}

