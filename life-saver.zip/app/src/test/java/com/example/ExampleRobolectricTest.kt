package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PreferencesManager
import com.example.model.Language
import com.example.model.MedicalProfile
import com.example.util.EmergencyStrings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Life Saver", appName)
  }

  @Test
  fun `medical profile persists correctly in preferences`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = PreferencesManager(context)

    val medical = MedicalProfile(
      bloodGroup = "O+",
      allergies = "Penicillin, Sulfa",
      medications = "Insulin",
      medicalConditions = "Type 1 Diabetic",
      emergencyNotes = "Organ Donor"
    )

    prefs.saveMedicalProfile(medical)

    val loadedProfile = prefs.userProfile.value
    assertEquals("O+", loadedProfile.medicalProfile.bloodGroup)
    assertEquals("Penicillin, Sulfa", loadedProfile.medicalProfile.allergies)
    assertEquals("Insulin", loadedProfile.medicalProfile.medications)
    assertEquals("Type 1 Diabetic", loadedProfile.medicalProfile.medicalConditions)
    assertEquals("Organ Donor", loadedProfile.medicalProfile.emergencyNotes)
    assertTrue(loadedProfile.medicalProfile.isConfigured)
  }

  @Test
  fun `shake sos and audio feedback toggles persist correctly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = PreferencesManager(context)

    // Initial defaults: Shake SOS is optional (disabled by default until user enables it)
    assertFalse(prefs.isShakeSosEnabled.value)
    assertTrue(prefs.isAudioFeedbackEnabled.value)

    prefs.setShakeSosEnabled(true)
    assertTrue(prefs.isShakeSosEnabled.value)

    prefs.setAudioFeedbackEnabled(false)
    assertFalse(prefs.isAudioFeedbackEnabled.value)

    prefs.setShakeSosEnabled(false)
    assertFalse(prefs.isShakeSosEnabled.value)
  }

  @Test
  fun `buildSosMessage formats medical details in English and Telugu`() {
    val medical = MedicalProfile(
      bloodGroup = "B+",
      allergies = "Peanuts",
      medications = "Asthma Inhaler"
    )

    val englishMsg = EmergencyStrings.buildSosMessage(
      lang = Language.ENGLISH,
      myPhone = "+91 99999 11111",
      latitude = 17.4399,
      longitude = 78.3908,
      address = "HITEC City, Hyderabad",
      timestamp = "10:30 AM",
      customNote = "Urgent",
      medicalProfile = medical
    )

    assertTrue(englishMsg.contains("Blood: B+"))
    assertTrue(englishMsg.contains("Allergies: Peanuts"))
    assertTrue(englishMsg.contains("Meds: Asthma Inhaler"))
    assertTrue(englishMsg.contains("HITEC City, Hyderabad"))

    val teluguMsg = EmergencyStrings.buildSosMessage(
      lang = Language.TELUGU,
      myPhone = "+91 99999 11111",
      latitude = 17.4399,
      longitude = 78.3908,
      address = "హైటెక్ సిటీ, హైదరాబాద్",
      timestamp = "10:30 AM",
      customNote = "అత్యవసరం",
      medicalProfile = medical
    )

    assertTrue(teluguMsg.contains("Blood: B+"))
    assertTrue(teluguMsg.contains("Allergies: Peanuts"))
  }

  @Test
  fun `medical strings and localization verify correctly`() {
    assertEquals("Add Medical Info", EmergencyStrings.addMedicalInfo(Language.ENGLISH))
    assertEquals("వైద్య వివరాలు జోడించండి", EmergencyStrings.addMedicalInfo(Language.TELUGU))

    assertEquals("Edit Medical Info", EmergencyStrings.editMedicalInfo(Language.ENGLISH))
    assertEquals("వైద్య వివరాలు సవరించండి", EmergencyStrings.editMedicalInfo(Language.TELUGU))

    assertEquals("Important Medical Notes", EmergencyStrings.importantMedicalNotes(Language.ENGLISH))
    assertEquals("ముఖ్యమైన వైద్య సూచనలు", EmergencyStrings.importantMedicalNotes(Language.TELUGU))

    assertEquals("CANCEL", EmergencyStrings.cancel(Language.ENGLISH))
    assertEquals("రద్దు చేయండి", EmergencyStrings.cancel(Language.TELUGU))
  }
}

