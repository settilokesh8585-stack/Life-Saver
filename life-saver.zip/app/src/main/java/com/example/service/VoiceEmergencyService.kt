package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.Language
import com.example.util.EmergencyActions
import java.util.Locale

class VoiceEmergencyService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var recognizerIntent: Intent? = null
    private var isListening = false
    private var tts: TextToSpeech? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this, this)
        initSpeechRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildForegroundNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        startListeningLoop()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Life Saver Voice Emergency Listener",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors for the wake phrase 'Life Saver' when foreground service is active"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, VoiceEmergencyService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Life Saver Voice Service Active")
            .setContentText("Listening for wake phrase 'Life Saver' or emergency commands...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(this@VoiceEmergencyService)
            }
            recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
        }
    }

    private fun startListeningLoop() {
        if (isListening || speechRecognizer == null) return
        try {
            isListening = true
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            isListening = false
            scheduleRestart(2000)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        mainHandler.postDelayed({
            if (!isListening) {
                startListeningLoop()
            }
        }, delayMs)
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spokenText = matches[0].lowercase(Locale.ROOT)
            handleSpokenText(spokenText)
        }
        scheduleRestart(800)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spokenText = matches[0].lowercase(Locale.ROOT)
            if (spokenText.contains("life saver") || spokenText.contains("లైఫ్ సేవర్") ||
                spokenText.contains("emergency") || spokenText.contains("help")
            ) {
                handleSpokenText(spokenText)
            }
        }
    }

    private fun handleSpokenText(spoken: String) {
        val intent = Intent(ACTION_VOICE_COMMAND_DETECTED).apply {
            putExtra(EXTRA_DETECTED_TEXT, spoken)
            setPackage(packageName)
        }
        sendBroadcast(intent)

        when {
            spoken.contains("life saver") || spoken.contains("లైఫ్ సేవర్") -> {
                speakText("Life Saver activated. How can I help you? You can say ambulance, 112, fire, or send SOS.")
            }
            spoken.contains("ambulance") || spoken.contains("108") || spoken.contains("అంబులెన్స్") -> {
                speakText("Calling 108 Ambulance right now.")
                EmergencyActions.dialEmergency(this, "108")
            }
            spoken.contains("police") || spoken.contains("112") || spoken.contains("పోలీస్") -> {
                speakText("Calling 112 National Emergency.")
                EmergencyActions.dialEmergency(this, "112")
            }
            spoken.contains("fire") || spoken.contains("101") || spoken.contains("ఫైర్") -> {
                speakText("Calling 101 Fire Brigade.")
                EmergencyActions.dialEmergency(this, "101")
            }
            spoken.contains("sos") || spoken.contains("help") || spoken.contains("సహాయం") || spoken.contains("కాపాడండి") -> {
                speakText("Sending emergency alert and calling emergency contact.")
                val openIntent = Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("TRIGGER_SOS_NOW", true)
                }
                startActivity(openIntent)
            }
        }
    }

    private fun speakText(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "life_saver_tts")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    override fun onError(error: Int) {
        isListening = false
        scheduleRestart(1500)
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {
        isListening = false
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onDestroy() {
        isListening = false
        mainHandler.removeCallbacksAndMessages(null)
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // Ignore
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // Ignore
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "life_saver_voice_channel"
        const val NOTIFICATION_ID = 9110
        const val ACTION_STOP_SERVICE = "com.example.service.STOP_VOICE_SERVICE"
        const val ACTION_VOICE_COMMAND_DETECTED = "com.example.service.VOICE_COMMAND_DETECTED"
        const val EXTRA_DETECTED_TEXT = "extra_detected_text"

        fun start(context: Context) {
            val intent = Intent(context, VoiceEmergencyService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, VoiceEmergencyService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
