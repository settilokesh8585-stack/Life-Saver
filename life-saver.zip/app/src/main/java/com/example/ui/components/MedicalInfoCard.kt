package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.Language
import com.example.model.MedicalProfile
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveRedSos
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceCard
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings

@Composable
fun MedicalInfoCard(
    medicalProfile: MedicalProfile,
    lang: Language,
    modifier: Modifier = Modifier,
    onOpenEditDialog: (() -> Unit)? = null,
    onSaveMedicalProfile: ((MedicalProfile) -> Unit)? = null
) {
    var internalDialogOpen by remember { mutableStateOf(false) }

    val handleOpenEdit = {
        if (onOpenEditDialog != null) {
            onOpenEditDialog()
        } else {
            internalDialogOpen = true
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("medical_info_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = ImmersiveSurfaceCard
        ),
        border = BorderStroke(1.dp, ImmersiveBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Title & Add/Edit Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(ImmersiveRedSos.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MedicalServices,
                            contentDescription = "Medical",
                            tint = ImmersiveRedSos,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = EmergencyStrings.medicalInfoTitle(lang),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveTextPrimary
                        )
                        Text(
                            text = EmergencyStrings.medicalInfoSubtitle(lang),
                            fontSize = 11.sp,
                            color = ImmersiveTextSecondary
                        )
                    }
                }

                // Header Action: Prominent Add "+" Button or Edit Button
                if (!medicalProfile.isConfigured) {
                    Button(
                        onClick = handleOpenEdit,
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("add_medical_info_button")
                            .testTag("edit_medical_info_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ImmersiveRedSos
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = EmergencyStrings.addMedicalInfo(lang),
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (lang == Language.TELUGU) "జోడించు +" else "Add +",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = handleOpenEdit,
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("add_medical_info_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = EmergencyStrings.addMedicalInfo(lang),
                                tint = ImmersiveRedSos,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(
                            onClick = handleOpenEdit,
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("edit_medical_info_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = EmergencyStrings.editMedicalInfo(lang),
                                tint = ImmersiveLavender,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (!medicalProfile.isConfigured) {
                // Empty state prompt: High-contrast, fully clickable banner with explicit "+" button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(ImmersiveSurfaceVariant)
                        .border(
                            1.dp,
                            EmergencyAlertYellow.copy(alpha = 0.5f),
                            RoundedCornerShape(14.dp)
                        )
                        .clickable(onClick = handleOpenEdit)
                        .padding(14.dp)
                        .testTag("add_medical_info_banner")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(EmergencyAlertYellow.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HealthAndSafety,
                                    contentDescription = null,
                                    tint = EmergencyAlertYellow,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = EmergencyStrings.medicalInfoNotSetNotice(lang),
                                    fontSize = 12.sp,
                                    color = EmergencyAlertYellow,
                                    fontWeight = FontWeight.SemiBold,
                                    lineHeight = 16.sp
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = EmergencyStrings.tapToAddMedicalInfo(lang),
                                    fontSize = 11.sp,
                                    color = ImmersiveTextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // Circular "+" badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ImmersiveRedSos),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = EmergencyStrings.addMedicalInfo(lang),
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            } else {
                // Configured state: Display medical badges & details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (medicalProfile.bloodGroup.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(ImmersiveRedSos.copy(alpha = 0.25f))
                                .border(1.dp, ImmersiveRedSos.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .clickable(onClick = handleOpenEdit)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("blood_group_badge")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "🩸 ",
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "${EmergencyStrings.bloodGroupLabel(lang)}: ${medicalProfile.bloodGroup}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFF8A80)
                                )
                            }
                        }
                    }

                    if (medicalProfile.allergies.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .clip(RoundedCornerShape(10.dp))
                                .background(EmergencyAlertYellow.copy(alpha = 0.15f))
                                .border(1.dp, EmergencyAlertYellow.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .clickable(onClick = handleOpenEdit)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "⚠️ ",
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "${EmergencyStrings.allergiesLabel(lang)}: ${medicalProfile.allergies}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EmergencyAlertYellow,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                if (medicalProfile.medications.isNotBlank() || medicalProfile.medicalConditions.isNotBlank() || medicalProfile.emergencyNotes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ImmersiveSurfaceVariant)
                            .clickable(onClick = handleOpenEdit)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        if (medicalProfile.medications.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "💊 ", fontSize = 12.sp)
                                Text(
                                    text = "${EmergencyStrings.medicationsLabel(lang)}: ",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveTextPrimary
                                )
                                Text(
                                    text = medicalProfile.medications,
                                    fontSize = 12.sp,
                                    color = ImmersiveTextSecondary
                                )
                            }
                        }

                        if (medicalProfile.medicalConditions.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "📋 ", fontSize = 12.sp)
                                Text(
                                    text = "${EmergencyStrings.conditionsLabel(lang)}: ",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveTextPrimary
                                )
                                Text(
                                    text = medicalProfile.medicalConditions,
                                    fontSize = 12.sp,
                                    color = ImmersiveTextSecondary
                                )
                            }
                        }

                        if (medicalProfile.emergencyNotes.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "ℹ️ ", fontSize = 12.sp)
                                Text(
                                    text = "${EmergencyStrings.emergencyNotesLabel(lang)}: ",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveTextPrimary
                                )
                                Text(
                                    text = medicalProfile.emergencyNotes,
                                    fontSize = 12.sp,
                                    color = ImmersiveTextSecondary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Privacy Guarantee Notice
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = ImmersiveTextSecondary,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = EmergencyStrings.medicalInfoSavedLocally(lang),
                    fontSize = 10.sp,
                    color = ImmersiveTextSecondary
                )
            }
        }
    }

    // Fallback Internal Dialog (when not hoisted by caller)
    if (internalDialogOpen) {
        MedicalInfoEditDialog(
            currentProfile = medicalProfile,
            lang = lang,
            onSave = { updated ->
                onSaveMedicalProfile?.invoke(updated)
                internalDialogOpen = false
            },
            onDismiss = { internalDialogOpen = false }
        )
    }
}

@Composable
fun MedicalInfoEditDialog(
    currentProfile: MedicalProfile,
    lang: Language,
    onSave: (MedicalProfile) -> Unit,
    onDismiss: () -> Unit
) {
    var bloodGroup by remember { mutableStateOf(currentProfile.bloodGroup) }
    var allergies by remember { mutableStateOf(currentProfile.allergies) }
    var medications by remember { mutableStateOf(currentProfile.medications) }
    var conditions by remember { mutableStateOf(currentProfile.medicalConditions) }
    var notes by remember { mutableStateOf(currentProfile.emergencyNotes) }

    val bloodGroups = listOf("O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 520.dp)
                .padding(vertical = 16.dp)
                .testTag("medical_info_edit_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = ImmersiveSurface),
            border = BorderStroke(1.dp, ImmersiveBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header with Title & Close Action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ImmersiveRedSos.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MedicalServices,
                                contentDescription = null,
                                tint = ImmersiveRedSos,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = EmergencyStrings.editMedicalInfo(lang),
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = ImmersiveTextPrimary
                            )
                            Text(
                                text = EmergencyStrings.medicalInfoSubtitle(lang),
                                fontSize = 11.sp,
                                color = ImmersiveTextSecondary
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("close_medical_info_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = EmergencyStrings.cancel(lang),
                            tint = ImmersiveTextSecondary
                        )
                    }
                }

                // Blood Group Quick Selector
                Text(
                    text = "${EmergencyStrings.bloodGroupLabel(lang)}:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ImmersiveTextPrimary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    bloodGroups.take(4).forEach { bg ->
                        val isSelected = bloodGroup.equals(bg, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) ImmersiveRedSos else ImmersiveSurfaceVariant
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) ImmersiveRedSos else ImmersiveBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { bloodGroup = bg }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bg,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else ImmersiveTextPrimary
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    bloodGroups.takeLast(4).forEach { bg ->
                        val isSelected = bloodGroup.equals(bg, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) ImmersiveRedSos else ImmersiveSurfaceVariant
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) ImmersiveRedSos else ImmersiveBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { bloodGroup = bg }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bg,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else ImmersiveTextPrimary
                            )
                        }
                    }
                }

                // Custom Blood Group Input
                OutlinedTextField(
                    value = bloodGroup,
                    onValueChange = { bloodGroup = it.take(8).uppercase() },
                    label = { Text(EmergencyStrings.bloodGroupLabel(lang)) },
                    placeholder = { Text("e.g. O+, B+, A-, AB+") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("blood_group_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveRedSos,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                // Allergies Input
                OutlinedTextField(
                    value = allergies,
                    onValueChange = { allergies = it },
                    label = { Text(EmergencyStrings.allergiesLabel(lang)) },
                    placeholder = { Text(if (lang == Language.TELUGU) "ఉదా: పెన్సిలిన్, వేరుశెనగలు" else "e.g. Penicillin, Peanuts, Sulfa, Dust") },
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("allergies_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                // Medications Input
                OutlinedTextField(
                    value = medications,
                    onValueChange = { medications = it },
                    label = { Text(EmergencyStrings.medicationsLabel(lang)) },
                    placeholder = { Text(if (lang == Language.TELUGU) "ఉదా: ఇన్సులిన్, బీపీ మాత్రలు" else "e.g. Insulin, BP tablets, Blood thinners") },
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("medications_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                // Important Medical Notes Input
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(EmergencyStrings.importantMedicalNotes(lang)) },
                    placeholder = { Text(if (lang == Language.TELUGU) "ఉదా: డయాబెటిస్, ఆస్తమా, అవయవ దాత" else "e.g. Diabetic, Asthma, Cardiac stent, Organ donor") },
                    singleLine = false,
                    maxLines = 4,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("medical_notes_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary,
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder
                    )
                )

                // Privacy Indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = ImmersiveTextSecondary,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = EmergencyStrings.medicalInfoSavedLocally(lang),
                        fontSize = 11.sp,
                        color = ImmersiveTextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Action Buttons: Cancel and Save Details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("cancel_medical_info_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ImmersiveBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = ImmersiveTextPrimary
                        )
                    ) {
                        Text(
                            text = EmergencyStrings.cancel(lang),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ImmersiveTextPrimary
                        )
                    }

                    Button(
                        onClick = {
                            onSave(
                                MedicalProfile(
                                    bloodGroup = bloodGroup.trim(),
                                    allergies = allergies.trim(),
                                    medications = medications.trim(),
                                    medicalConditions = conditions.trim(),
                                    emergencyNotes = notes.trim()
                                )
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("save_medical_info_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ImmersiveRedSos)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = EmergencyStrings.save(lang),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
