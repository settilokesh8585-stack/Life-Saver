package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// "Immersive UI" Theme Palette
val ImmersiveBackground = Color(0xFF1C1B1F)
val ImmersiveSurface = Color(0xFF1C1B1F)
val ImmersiveSurfaceVariant = Color(0xFF49454F)
val ImmersiveSurfaceCard = Color(0x4D49454F) // #49454F with 30% alpha
val ImmersiveBorder = Color(0xFF49454F)
val ImmersiveTextPrimary = Color(0xFFE6E1E5)
val ImmersiveTextSecondary = Color(0xFFCAC4D0)

// Immersive Action Accents
val ImmersiveRedSos = Color(0xFFB3261E)
val ImmersiveRedActive = Color(0xFF8C1D18)
val ImmersiveRedBorder = Color(0x33FFB4AB)
val ImmersiveRedGlow = Color(0x80B3261E)
val ImmersiveRedText = Color(0xFFFFB4AB)

// Immersive Lavender & Blue Accents
val ImmersiveLavender = Color(0xFFD0BCFF)
val ImmersiveLavenderDark = Color(0xFF381E72)
val ImmersiveHospitalBlue = Color(0xFFD1E1FF)
val ImmersiveHospitalBlueDark = Color(0xFF001D36)
val ImmersiveActiveGreen = Color(0xFF4CAF50)

// High-contrast emergency theme colors
val EmergencyRed = Color(0xFFB3261E)
val EmergencyRedDark = Color(0xFF8C1D18)
val EmergencyRedBright = Color(0xFFE0382B)
val EmergencyRedContainer = Color(0xFFFFDAD6)
val EmergencyRedOnContainer = Color(0xFF410002)

val EmergencyAmbulanceTeal = Color(0xFF00897B)
val EmergencyAmbulanceTealDark = Color(0xFF004D40)

val EmergencyFireOrange = Color(0xFFF4511E)
val EmergencyFireOrangeDark = Color(0xFFBF360C)

val EmergencyPoliceBlue = Color(0xFF1565C0)
val EmergencyPoliceBlueDark = Color(0xFF0D47A1)

val EmergencyHospitalGreen = Color(0xFF2E7D32)
val EmergencyAlertYellow = Color(0xFFFFD600)

val DarkSurface = Color(0xFF1C1B1F)
val DarkSurfaceElevated = Color(0xFF2B2930)
val DarkSurfaceCard = Color(0xFF49454F)
val DarkBorder = Color(0xFF49454F)
val LightSurface = Color(0xFFF8F9FA)
val LightSurfaceCard = Color(0xFFFFFFFF)
