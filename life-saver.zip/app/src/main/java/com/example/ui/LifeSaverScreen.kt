package com.example.ui

import android.Manifest
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Language
import com.example.ui.components.BatteryAlertCard
import com.example.ui.components.EmergencyDialGrid
import com.example.ui.components.GpsLocationCard
import com.example.ui.components.MedicalInfoCard
import com.example.ui.components.MedicalInfoEditDialog
import com.example.ui.components.NearbyMapsSection
import com.example.ui.components.OfflineMapsSection
import com.example.ui.components.OfflineSmsDialog
import com.example.ui.components.SettingsDialog
import com.example.ui.components.ShakeSosCountdownDialog
import com.example.ui.components.SosButtonSection
import com.example.ui.components.VoiceAssistantCard
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.ImmersiveBackground
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveLavenderDark
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyActions
import com.example.util.EmergencyStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeSaverScreen(
    viewModel: LifeSaverViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val locationState by viewModel.locationState.collectAsState()
    val sosCountdown by viewModel.sosCountdown.collectAsState()
    val isSirenActive by viewModel.isSirenActive.collectAsState()
    val isStrobeActive by viewModel.isStrobeActive.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val recognizedText by viewModel.voiceRecognizedText.collectAsState()
    val assistantFeedback by viewModel.voiceFeedback.collectAsState()
    val isVoiceServiceActive by viewModel.isVoiceServiceActive.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val readySosMessage by viewModel.readySosMessage.collectAsState()

    val batteryState by viewModel.batteryState.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val cachedAreas by viewModel.cachedMapAreas.collectAsState()
    val selectedArea by viewModel.selectedMapArea.collectAsState()
    val isCachingArea by viewModel.isCachingArea.collectAsState()

    val isShakeSosEnabled by viewModel.isShakeSosEnabled.collectAsState()
    val isAudioFeedbackEnabled by viewModel.isAudioFeedbackEnabled.collectAsState()
    val shakeSosCountdown by viewModel.shakeSosCountdown.collectAsState()
    val isOfflineSmsDialogOpen by viewModel.isOfflineSmsDialogOpen.collectAsState()
    val isMedicalEditDialogOpen by viewModel.isMedicalEditDialogOpen.collectAsState()

    // Manage shake sensor listener strictly based on user toggle
    DisposableEffect(isShakeSosEnabled) {
        if (isShakeSosEnabled) {
            viewModel.startShakeDetection()
        } else {
            viewModel.stopShakeDetection()
        }
        onDispose {
            viewModel.stopShakeDetection()
        }
    }

    // Permissions launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        ) {
            viewModel.refreshLocation()
        }
    }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionsLauncher.launch(permissions.toTypedArray())
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_life_saver_logo),
                            contentDescription = "Life Saver Logo",
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = EmergencyStrings.appTitle(lang),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = ImmersiveTextPrimary
                            )
                            Text(
                                text = EmergencyStrings.appSubtitle(lang),
                                fontSize = 11.sp,
                                color = ImmersiveLavender,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                actions = {
                    // Language Switcher Badge (English / తెలుగు)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(ImmersiveSurfaceVariant.copy(alpha = 0.6f))
                            .border(1.dp, ImmersiveBorder, RoundedCornerShape(50))
                            .clickable { viewModel.toggleLanguage() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("language_toggle_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = "Switch Language",
                                tint = ImmersiveLavender,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (lang == Language.ENGLISH) "తెలుగు" else "ENG",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ImmersiveTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Settings Icon Button
                    IconButton(
                        onClick = { viewModel.setSettingsOpen(true) },
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = ImmersiveTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ImmersiveBackground
                )
            )
        },
        containerColor = ImmersiveBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Battery Level Emergency Alert & Status Card
                BatteryAlertCard(
                    batteryState = batteryState,
                    lang = lang,
                    onTriggerSos = { viewModel.startSosCountdown(context) },
                    onShareLocation = {
                        EmergencyActions.shareSosMessage(
                            context = context,
                            message = readySosMessage
                        )
                    },
                    onSendOfflineSms = { viewModel.openOfflineSmsDialog() }
                )

                // 1. Large Red SEND SOS Button Section
                SosButtonSection(
                    lang = lang,
                    countdown = sosCountdown,
                    isSirenActive = isSirenActive,
                    isStrobeActive = isStrobeActive,
                    onSosClick = { viewModel.startSosCountdown(context) },
                    onCancelSos = { viewModel.cancelSosCountdown() },
                    onToggleSiren = { viewModel.toggleSiren() },
                    onToggleStrobe = { viewModel.toggleStrobe() }
                )

                // 2. Emergency Medical Info Card (Locally stored for paramedics & first responders)
                MedicalInfoCard(
                    medicalProfile = userProfile.medicalProfile,
                    lang = lang,
                    onOpenEditDialog = { viewModel.openMedicalEditDialog() },
                    onSaveMedicalProfile = { updatedMedical ->
                        viewModel.saveMedicalProfile(updatedMedical)
                        Toast.makeText(
                            context,
                            if (lang == Language.TELUGU) "వైద్య వివరాలు భద్రపరచబడ్డాయి" else "Medical profile saved locally",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )

                // 3. Quick Emergency Helplines: 112, 108, 101
                EmergencyDialGrid(
                    lang = lang,
                    onDial = { number ->
                        EmergencyActions.dialEmergency(context, number)
                    }
                )

                // 4. Google Maps: Nearby Hospitals and Police (Live when online)
                NearbyMapsSection(
                    lang = lang,
                    onNearbyHospitalsClick = {
                        EmergencyActions.openNearbyHospitals(
                            context = context,
                            lat = locationState.latitude,
                            lng = locationState.longitude
                        )
                    },
                    onNearbyPoliceClick = {
                        EmergencyActions.openNearbyPolice(
                            context = context,
                            lat = locationState.latitude,
                            lng = locationState.longitude
                        )
                    }
                )

                // 5. Offline Maps & Emergency Cache (100% Offline Access)
                OfflineMapsSection(
                    lang = lang,
                    isInternetAvailable = isInternetAvailable,
                    cachedAreas = cachedAreas,
                    selectedArea = selectedArea,
                    isCaching = isCachingArea,
                    onCacheCurrentArea = { viewModel.cacheCurrentArea() },
                    onSelectArea = { areaId -> viewModel.selectMapArea(areaId) },
                    onDeleteArea = { areaId -> viewModel.deleteMapArea(areaId) },
                    onDialNumber = { number -> EmergencyActions.dialEmergency(context, number) }
                )

                // 6. GPS Live Location and Ready-to-Share SOS Message Card
                GpsLocationCard(
                    lang = lang,
                    locationState = locationState,
                    sosMessageText = readySosMessage,
                    onRefreshLocation = { viewModel.refreshLocation() },
                    onCopyMessage = {
                        EmergencyActions.copyToClipboard(
                            context = context,
                            text = readySosMessage,
                            toastMessage = EmergencyStrings.messageCopied(lang)
                        )
                    },
                    onShareAll = {
                        EmergencyActions.shareSosMessage(
                            context = context,
                            message = readySosMessage
                        )
                    },
                    onSendSms = {
                        viewModel.openOfflineSmsDialog()
                    }
                )

                // 7. Voice Emergency Assistant with "Life Saver" Wake Phrase
                VoiceAssistantCard(
                    lang = lang,
                    isListening = isListening,
                    recognizedText = recognizedText,
                    assistantFeedback = assistantFeedback,
                    isServiceActive = isVoiceServiceActive,
                    onToggleListen = { viewModel.startListeningInApp(context) },
                    onToggleService = { viewModel.toggleVoiceService(context) }
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Settings Dialog Modal
        if (isSettingsOpen) {
            SettingsDialog(
                lang = lang,
                currentProfile = userProfile,
                isShakeSosEnabled = isShakeSosEnabled,
                onToggleShakeSos = { viewModel.setShakeSosEnabled(it) },
                isAudioFeedbackEnabled = isAudioFeedbackEnabled,
                onToggleAudioFeedback = { viewModel.setAudioFeedbackEnabled(it) },
                onSave = { updatedProfile ->
                    viewModel.saveProfile(updatedProfile)
                    Toast.makeText(
                        context,
                        EmergencyStrings.settingsSaved(lang),
                        Toast.LENGTH_SHORT
                    ).show()
                },
                onDismiss = { viewModel.setSettingsOpen(false) }
            )
        }

        // Shake SOS Countdown Dialog Modal
        shakeSosCountdown?.let { count ->
            ShakeSosCountdownDialog(
                secondsRemaining = count,
                totalSeconds = 5,
                lang = lang,
                onCancel = { viewModel.cancelShakeSos() }
            )
        }

        // Offline SOS SMS Dispatch Modal with User Confirmation
        if (isOfflineSmsDialogOpen) {
            OfflineSmsDialog(
                initialRecipientPhone = userProfile.primaryContact.phone,
                initialRecipientName = userProfile.primaryContact.name,
                sosMessage = readySosMessage,
                lang = lang,
                onConfirmSend = { phone, msg ->
                    viewModel.sendOfflineSms(context, phone, msg)
                },
                onDismiss = { viewModel.closeOfflineSmsDialog() }
            )
        }

        // Emergency Medical Info Edit Modal
        if (isMedicalEditDialogOpen) {
            MedicalInfoEditDialog(
                currentProfile = userProfile.medicalProfile,
                lang = lang,
                onSave = { updatedMedical ->
                    viewModel.saveMedicalProfile(updatedMedical)
                    viewModel.closeMedicalEditDialog()
                    Toast.makeText(
                        context,
                        if (lang == Language.TELUGU) "వైద్య వివరాలు భద్రపరచబడ్డాయి" else "Medical profile saved locally",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                onDismiss = { viewModel.closeMedicalEditDialog() }
            )
        }
    }
}
