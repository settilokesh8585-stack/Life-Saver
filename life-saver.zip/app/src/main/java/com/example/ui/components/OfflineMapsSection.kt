package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CachedEmergencyPlace
import com.example.model.Language
import com.example.model.OfflineMapArea
import com.example.model.PlaceType
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.EmergencyPoliceBlue
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.ImmersiveActiveGreen
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveHospitalBlue
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveLavenderDark
import com.example.ui.theme.ImmersiveSurfaceCard
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyActions
import com.example.util.EmergencyStrings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OfflineMapsSection(
    lang: Language,
    isInternetAvailable: Boolean,
    cachedAreas: List<OfflineMapArea>,
    selectedArea: OfflineMapArea?,
    isCaching: Boolean,
    onCacheCurrentArea: () -> Unit,
    onSelectArea: (String) -> Unit,
    onDeleteArea: (String) -> Unit,
    onDialNumber: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showNoticeExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("offline_maps_section"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = ImmersiveSurfaceCard
        ),
        border = BorderStroke(1.dp, ImmersiveBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(ImmersiveLavenderDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = "Offline Maps",
                            tint = ImmersiveLavender,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = EmergencyStrings.offlineMapsSectionTitle(lang),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveTextPrimary
                        )
                        Text(
                            text = EmergencyStrings.offlineMapsSubtitle(lang),
                            fontSize = 11.sp,
                            color = ImmersiveTextSecondary
                        )
                    }
                }

                // Network Status Indicator Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(
                            if (isInternetAvailable) ImmersiveActiveGreen.copy(alpha = 0.15f)
                            else EmergencyAlertYellow.copy(alpha = 0.15f)
                        )
                        .border(
                            1.dp,
                            if (isInternetAvailable) ImmersiveActiveGreen.copy(alpha = 0.5f)
                            else EmergencyAlertYellow.copy(alpha = 0.5f),
                            RoundedCornerShape(50)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isInternetAvailable) Icons.Default.Wifi else Icons.Default.WifiOff,
                            contentDescription = null,
                            tint = if (isInternetAvailable) ImmersiveActiveGreen else EmergencyAlertYellow,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isInternetAvailable) "ONLINE" else "OFFLINE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = if (isInternetAvailable) ImmersiveActiveGreen else EmergencyAlertYellow
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action: Cache Current Area Button
            Button(
                onClick = onCacheCurrentArea,
                enabled = !isCaching,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("cache_current_area_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ImmersiveLavender,
                    contentColor = ImmersiveLavenderDark
                )
            ) {
                if (isCaching) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = ImmersiveLavenderDark,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = EmergencyStrings.cachingInProgress(lang),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.CloudDownload,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = EmergencyStrings.cacheCurrentAreaButton(lang),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Cached Area Selector / Status Banner
            if (selectedArea != null) {
                val dateStr = remember(selectedArea.cachedAtTimestamp) {
                    SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                        .format(Date(selectedArea.cachedAtTimestamp))
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(ImmersiveSurfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = selectedArea.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveTextPrimary
                                )
                                Text(
                                    text = "📍 ${selectedArea.address}",
                                    fontSize = 11.sp,
                                    color = ImmersiveTextSecondary,
                                    maxLines = 1
                                )
                            }

                            // Offline Availability Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (selectedArea.isOfflineAvailable) ImmersiveActiveGreen.copy(alpha = 0.15f)
                                        else Color.Gray.copy(alpha = 0.2f)
                                    )
                                    .border(
                                        1.dp,
                                        if (selectedArea.isOfflineAvailable) ImmersiveActiveGreen.copy(alpha = 0.6f)
                                        else Color.Gray,
                                        RoundedCornerShape(50)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = ImmersiveActiveGreen,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = EmergencyStrings.areaAvailableOfflineBadge(lang),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ImmersiveActiveGreen
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "🕒 ${EmergencyStrings.cachedAtLabel(lang, dateStr)} • Radius: ${selectedArea.radiusKm.toInt()} km",
                                fontSize = 11.sp,
                                color = ImmersiveLavender
                            )

                            if (cachedAreas.size > 1) {
                                Text(
                                    text = "🗑️ ${EmergencyStrings.deleteCachedArea(lang)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFFF8A80),
                                    modifier = Modifier
                                        .clickable { onDeleteArea(selectedArea.id) }
                                        .padding(4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Cached Emergency Facilities Title
            Text(
                text = EmergencyStrings.offlineEmergencyFacilitiesTitle(lang),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = ImmersiveTextPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Facilities List
            val places = selectedArea?.places.orEmpty()
            if (places.isNotEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    places.forEach { place ->
                        CachedPlaceRow(
                            place = place,
                            lang = lang,
                            onDial = { onDialNumber(place.phone) },
                            onOpenMap = {
                                openMapCoordinates(context, place.latitude, place.longitude, place.name)
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Direct Link to Download Full Google Maps Offline Area
            OutlinedButton(
                onClick = {
                    openGoogleMapsOfflineManager(context)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .testTag("download_gmaps_offline_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = ImmersiveSurfaceVariant.copy(alpha = 0.4f),
                    contentColor = ImmersiveLavender
                ),
                border = BorderStroke(1.dp, ImmersiveBorder)
            ) {
                Icon(
                    imageVector = Icons.Default.Explore,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = ImmersiveLavender
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = EmergencyStrings.openGoogleMapsOfflineTitle(lang),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = ImmersiveTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Transparent Honest Notice Accordion
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ImmersiveSurfaceVariant.copy(alpha = 0.3f))
                    .clickable { showNoticeExpanded = !showNoticeExpanded }
                    .padding(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Notice",
                    tint = ImmersiveLavender,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(top = 1.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = if (showNoticeExpanded) EmergencyStrings.offlineMapsDisclaimer(lang)
                        else "ℹ️ ${EmergencyStrings.offlineMapsDisclaimer(lang).take(95)}...",
                        fontSize = 10.sp,
                        color = ImmersiveTextSecondary,
                        lineHeight = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun CachedPlaceRow(
    place: CachedEmergencyPlace,
    lang: Language,
    onDial: () -> Unit,
    onOpenMap: () -> Unit
) {
    val (typeColor, typeBg) = when (place.type) {
        PlaceType.HOSPITAL -> Pair(ImmersiveHospitalBlue, ImmersiveHospitalBlue.copy(alpha = 0.15f))
        PlaceType.POLICE -> Pair(EmergencyPoliceBlue, EmergencyPoliceBlue.copy(alpha = 0.15f))
        PlaceType.FIRE -> Pair(EmergencyRed, EmergencyRed.copy(alpha = 0.15f))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ImmersiveSurfaceVariant.copy(alpha = 0.45f))
            .border(1.dp, ImmersiveBorder, RoundedCornerShape(14.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(typeBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = place.type.iconLabel,
                    fontSize = 16.sp
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = place.name,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ImmersiveTextPrimary,
                    maxLines = 1
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "📏 ${place.distanceKm} km",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ImmersiveActiveGreen
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "🧭 ${formatBearing(place.bearingDegrees)}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ImmersiveLavender
                    )
                }
                Text(
                    text = place.address,
                    fontSize = 10.sp,
                    color = ImmersiveTextSecondary,
                    maxLines = 1
                )
            }
        }

        // Action Buttons: Call & Navigate
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Direct call button (works offline via GSM voice network!)
            Button(
                onClick = onDial,
                modifier = Modifier
                    .height(34.dp)
                    .testTag("call_cached_place_${place.id}"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ImmersiveActiveGreen
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = "Call",
                    tint = Color.White,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = place.phone,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Map view button
            IconButton(
                onClick = onOpenMap,
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.NearMe,
                    contentDescription = "Navigate",
                    tint = ImmersiveLavender,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

private fun formatBearing(degrees: Float): String {
    val dir = when (((degrees + 22.5) % 360 / 45).toInt()) {
        0 -> "N"
        1 -> "NE"
        2 -> "E"
        3 -> "SE"
        4 -> "S"
        5 -> "SW"
        6 -> "W"
        7 -> "NW"
        else -> "N"
    }
    return "$dir (${degrees.toInt()}°)"
}

private fun openMapCoordinates(context: Context, lat: Double, lng: Double, label: String) {
    try {
        val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open map: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openGoogleMapsOfflineManager(context: Context) {
    try {
        // Try opening Google Maps offline area downloader directly
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=offline")).apply {
            setPackage("com.google.android.apps.maps")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback to normal maps intent
        try {
            val fallback = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(fallback)
        } catch (ex: Exception) {
            Toast.makeText(context, "Open Google Maps App to download offline areas", Toast.LENGTH_LONG).show()
        }
    }
}
