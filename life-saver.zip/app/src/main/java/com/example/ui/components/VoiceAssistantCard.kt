package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.EmergencyPoliceBlue
import com.example.ui.theme.ImmersiveActiveGreen
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveHospitalBlue
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveLavenderDark
import com.example.ui.theme.ImmersiveRedSos
import com.example.ui.theme.ImmersiveRedText
import com.example.ui.theme.ImmersiveSurfaceCard
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings

@Composable
fun VoiceAssistantCard(
    lang: Language,
    isListening: Boolean,
    recognizedText: String,
    assistantFeedback: String,
    isServiceActive: Boolean,
    onToggleListen: () -> Unit,
    onToggleService: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val micScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_scale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("voice_assistant_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = ImmersiveSurfaceCard
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header with Wake Word badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(ImmersiveLavenderDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Voice Assistant",
                            tint = ImmersiveLavender,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = EmergencyStrings.voiceAssistantTitle(lang),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveTextPrimary
                    )
                }

                // Wake word pill badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(ImmersiveLavender.copy(alpha = 0.15f))
                        .border(1.dp, ImmersiveLavender.copy(alpha = 0.6f), RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "⚡ \"Life Saver\"",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = ImmersiveLavender
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Voice Interaction Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ImmersiveSurfaceVariant.copy(alpha = 0.45f))
                    .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Mic Button
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .scale(if (isListening) micScale else 1f)
                        .clip(CircleShape)
                        .background(
                            if (isListening) ImmersiveRedSos else ImmersiveLavender
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = onToggleListen,
                        modifier = Modifier
                            .size(54.dp)
                            .testTag("voice_mic_button"),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Hearing else Icons.Default.Mic,
                            contentDescription = "Microphone",
                            tint = if (isListening) Color.White else ImmersiveLavenderDark,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isListening) EmergencyStrings.listeningNow(lang) else EmergencyStrings.startListening(lang),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isListening) ImmersiveRedText else ImmersiveTextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = EmergencyStrings.wakeWordBadge(lang),
                        fontSize = 11.sp,
                        color = ImmersiveTextSecondary
                    )
                }
            }

            // Real-time voice transcript & feedback
            AnimatedVisibility(visible = recognizedText.isNotBlank() || assistantFeedback.isNotBlank()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(ImmersiveSurfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, ImmersiveBorder, RoundedCornerShape(14.dp))
                        .padding(10.dp)
                ) {
                    if (recognizedText.isNotBlank()) {
                        Text(
                            text = "🗣️ \"$recognizedText\"",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ImmersiveHospitalBlue
                        )
                    }
                    if (assistantFeedback.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "🤖 $assistantFeedback",
                            fontSize = 12.sp,
                            color = ImmersiveTextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Commands hint
            Text(
                text = EmergencyStrings.voiceCommandsHint(lang),
                fontSize = 11.sp,
                color = ImmersiveTextSecondary,
                lineHeight = 14.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Foreground Service Toggle Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ImmersiveSurfaceVariant.copy(alpha = 0.45f))
                    .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = EmergencyStrings.backgroundServiceToggle(lang),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveTextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = EmergencyStrings.backgroundServiceDesc(lang),
                        fontSize = 10.sp,
                        color = ImmersiveTextSecondary,
                        lineHeight = 13.sp
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Switch(
                    checked = isServiceActive,
                    onCheckedChange = { onToggleService() },
                    modifier = Modifier.testTag("voice_service_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = ImmersiveActiveGreen,
                        uncheckedThumbColor = ImmersiveTextSecondary,
                        uncheckedTrackColor = ImmersiveSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Crucial Android OS privacy requirement display
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ImmersiveLavenderDark.copy(alpha = 0.35f))
                    .border(1.dp, ImmersiveLavender.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Notice",
                    tint = ImmersiveLavender,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(top = 1.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = EmergencyStrings.osPrivacyNotice(lang),
                    fontSize = 10.sp,
                    color = ImmersiveTextPrimary,
                    lineHeight = 13.sp
                )
            }
        }
    }
}
