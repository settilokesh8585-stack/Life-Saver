package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.ImmersiveActiveGreen
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveRedBorder
import com.example.ui.theme.ImmersiveRedSos
import com.example.ui.theme.ImmersiveRedText
import com.example.ui.theme.ImmersiveSurfaceCard
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.BatteryState
import com.example.util.EmergencyStrings

import androidx.compose.material.icons.filled.Sms
import com.example.ui.theme.ImmersiveHospitalBlue

@Composable
fun BatteryAlertCard(
    batteryState: BatteryState,
    lang: Language,
    onTriggerSos: () -> Unit,
    onShareLocation: () -> Unit,
    onSendOfflineSms: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "batteryPulse"
    )

    val chargingStatusText = if (batteryState.isCharging) {
        if (lang == Language.TELUGU) "⚡ చార్జింగ్ అవుతోంది" else "⚡ Charging"
    } else {
        if (lang == Language.TELUGU) "చార్జింగ్ కావట్లేదు" else "Not Charging"
    }

    when {
        // 1. CRITICAL BATTERY (< 10%) - High-Contrast Emergency Red Alert
        batteryState.isCritical -> {
            Card(
                modifier = modifier
                    .fillMaxWidth()
                    .testTag("battery_critical_alert_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF2E1010)
                ),
                border = BorderStroke(2.dp, ImmersiveRedSos)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(ImmersiveRedSos),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BatteryAlert,
                                    contentDescription = "Critical Battery",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = EmergencyStrings.criticalBatteryWarningTitle(lang, batteryState.level),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    color = ImmersiveRedText
                                )
                                Text(
                                    text = if (lang == Language.TELUGU) "మిగిలిన చార్జ్: ${batteryState.level}% • $chargingStatusText" else "Remaining: ${batteryState.level}% • $chargingStatusText",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = EmergencyStrings.criticalBatteryWarningDesc(lang),
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        color = Color(0xFFFFCDD2)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onTriggerSos,
                            modifier = Modifier
                                .weight(1.1f)
                                .height(44.dp)
                                .testTag("battery_emergency_sos_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ImmersiveRedSos
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = EmergencyStrings.sendSos(lang),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }

                        if (onSendOfflineSms != null) {
                            Button(
                                onClick = onSendOfflineSms,
                                modifier = Modifier
                                    .weight(1.1f)
                                    .height(44.dp)
                                    .testTag("battery_offline_sms_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF5D1010)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sms,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                    tint = Color.White
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = EmergencyStrings.offlineSmsTitle(lang),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onShareLocation,
                            modifier = Modifier
                                .weight(0.9f)
                                .height(44.dp)
                                .testTag("battery_share_location_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = ImmersiveSurfaceVariant,
                                contentColor = Color.White
                            ),
                            border = BorderStroke(1.dp, ImmersiveRedBorder)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = ImmersiveLavender
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = EmergencyStrings.copyMessage(lang),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 2. LOW BATTERY (< 20%) - High-Contrast Amber/Yellow Warning
        batteryState.isLow -> {
            Card(
                modifier = modifier
                    .fillMaxWidth()
                    .testTag("battery_low_alert_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF2B210B)
                ),
                border = BorderStroke(1.5.dp, EmergencyAlertYellow)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(EmergencyAlertYellow.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BatteryAlert,
                                    contentDescription = "Low Battery",
                                    tint = EmergencyAlertYellow,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = EmergencyStrings.lowBatteryWarningTitle(lang, batteryState.level),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmergencyAlertYellow
                                )
                                Text(
                                    text = "$chargingStatusText • ${EmergencyStrings.batterySaverTip(lang)}",
                                    fontSize = 11.sp,
                                    color = ImmersiveTextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = EmergencyStrings.lowBatteryWarningDesc(lang),
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        color = Color(0xFFFFECB3)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (onSendOfflineSms != null) {
                            Button(
                                onClick = onSendOfflineSms,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("battery_low_offline_sms_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF634B0B)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sms,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = EmergencyAlertYellow
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = EmergencyStrings.offlineSmsTitle(lang),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmergencyAlertYellow
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onShareLocation,
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("battery_low_share_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = ImmersiveSurfaceVariant.copy(alpha = 0.5f),
                                contentColor = Color.White
                            ),
                            border = BorderStroke(1.dp, EmergencyAlertYellow.copy(alpha = 0.6f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = EmergencyAlertYellow
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (lang == Language.TELUGU) "లొకేషన్ షేర్" else "Share Location",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmergencyAlertYellow
                            )
                        }
                    }
                }
            }
        }

        // 3. NORMAL BATTERY (>= 20%) - Clean status pill banner
        else -> {
            Card(
                modifier = modifier
                    .fillMaxWidth()
                    .testTag("battery_status_bar"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = ImmersiveSurfaceCard
                ),
                border = BorderStroke(1.dp, ImmersiveBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (batteryState.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                            contentDescription = "Battery",
                            tint = if (batteryState.isCharging) ImmersiveActiveGreen else ImmersiveLavender,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = EmergencyStrings.batteryNormal(lang, batteryState.level, batteryState.isCharging),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ImmersiveTextPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (batteryState.isCharging) ImmersiveActiveGreen.copy(alpha = 0.15f)
                                else ImmersiveLavender.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (batteryState.isCharging) "⚡ ${batteryState.level}%" else "${batteryState.level}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (batteryState.isCharging) ImmersiveActiveGreen else ImmersiveLavender
                        )
                    }
                }
            }
        }
    }
}
