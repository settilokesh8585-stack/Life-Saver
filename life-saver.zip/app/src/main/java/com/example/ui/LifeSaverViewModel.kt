package com.example.ui

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.OfflineMapsRepository
import com.example.data.PreferencesManager
import com.example.location.LocationHelper
import com.example.model.GpsLocationState
import com.example.model.Language
import com.example.model.MedicalProfile
import com.example.model.OfflineMapArea
import com.example.model.UserEmergencyProfile
import com.example.service.VoiceEmergencyService
import com.example.util.BatteryMonitor
import com.example.util.BatteryState
import com.example.util.EmergencyActions
import com.example.util.EmergencyAlarmManager
import com.example.util.EmergencyStrings
import com.example.util.ShakeDetector
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class LifeSaverViewModel(application: Application) : AndroidViewModel(application), RecognitionListener, TextToSpeech.OnInitListener {

    private val prefsManager = PreferencesManager(application)
    private val locationHelper = LocationHelper(application)
    private val alarmManager = EmergencyAlarmManager(application)
    private val batteryMonitor = BatteryMonitor(application)
    private val offlineMapsRepo = OfflineMapsRepository(application)

    val userProfile: StateFlow<UserEmergencyProfile> = prefsManager.userProfile
    val language: StateFlow<Language> = prefsManager.language
    val isVoiceServiceActive: StateFlow<Boolean> = prefsManager.isVoiceServiceActive
    val isShakeSosEnabled: StateFlow<Boolean> = prefsManager.isShakeSosEnabled
    val isAudioFeedbackEnabled: StateFlow<Boolean> = prefsManager.isAudioFeedbackEnabled

    val batteryState: StateFlow<BatteryState> = batteryMonitor.batteryState
    val isInternetAvailable: StateFlow<Boolean> = offlineMapsRepo.isInternetAvailable
    val cachedMapAreas: StateFlow<List<OfflineMapArea>> = offlineMapsRepo.cachedAreas
    val selectedMapArea: StateFlow<OfflineMapArea?> = offlineMapsRepo.selectedArea

    private val _isCachingArea = MutableStateFlow(false)
    val isCachingArea: StateFlow<Boolean> = _isCachingArea.asStateFlow()

    private val _locationState = MutableStateFlow(GpsLocationState(isLoading = true))
    val locationState: StateFlow<GpsLocationState> = _locationState.asStateFlow()

    private val _sosCountdown = MutableStateFlow<Int?>(null)
    val sosCountdown: StateFlow<Int?> = _sosCountdown.asStateFlow()

    private val _shakeSosCountdown = MutableStateFlow<Int?>(null)
    val shakeSosCountdown: StateFlow<Int?> = _shakeSosCountdown.asStateFlow()

    private val _isOfflineSmsDialogOpen = MutableStateFlow(false)
    val isOfflineSmsDialogOpen: StateFlow<Boolean> = _isOfflineSmsDialogOpen.asStateFlow()

    private val _isMedicalEditDialogOpen = MutableStateFlow(false)
    val isMedicalEditDialogOpen: StateFlow<Boolean> = _isMedicalEditDialogOpen.asStateFlow()

    private val _isSirenActive = MutableStateFlow(false)
    val isSirenActive: StateFlow<Boolean> = _isSirenActive.asStateFlow()

    private val _isStrobeActive = MutableStateFlow(false)
    val isStrobeActive: StateFlow<Boolean> = _isStrobeActive.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _voiceRecognizedText = MutableStateFlow("")
    val voiceRecognizedText: StateFlow<String> = _voiceRecognizedText.asStateFlow()

    private val _voiceFeedback = MutableStateFlow("")
    val voiceFeedback: StateFlow<String> = _voiceFeedback.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private var countdownJob: Job? = null
    private var shakeCountdownJob: Job? = null
    private var inAppSpeechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private val shakeDetector = ShakeDetector(application) {
        triggerShakeSos()
    }

    // Compute ready-to-share message automatically whenever profile, location or language changes
    val readySosMessage: StateFlow<String> = combine(
        language,
        userProfile,
        locationState
    ) { lang, profile, loc ->
        EmergencyStrings.buildSosMessage(
            lang = lang,
            myPhone = profile.myPhoneNumber,
            latitude = loc.latitude,
            longitude = loc.longitude,
            address = loc.address,
            timestamp = loc.timestampFormatted.ifBlank { "Just now" },
            customNote = profile.customNote,
            medicalProfile = profile.medicalProfile
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ""
    )

    private val voiceCommandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val command = intent?.getStringExtra(VoiceEmergencyService.EXTRA_DETECTED_TEXT) ?: return
            _voiceRecognizedText.value = command
            handleVoiceCommand(command)
        }
    }

    init {
        tts = TextToSpeech(application, this)
        batteryMonitor.startMonitoring()
        refreshLocation()

        alarmManager.isAudioEnabled = isAudioFeedbackEnabled.value
        shakeDetector.setEnabled(isShakeSosEnabled.value)

        val filter = IntentFilter(VoiceEmergencyService.ACTION_VOICE_COMMAND_DETECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            application.registerReceiver(voiceCommandReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            application.registerReceiver(voiceCommandReceiver, filter)
        }
    }

    fun toggleLanguage() {
        val next = if (language.value == Language.ENGLISH) Language.TELUGU else Language.ENGLISH
        prefsManager.setLanguage(next)
        updateTtsLocale(next)
    }

    fun setLanguage(lang: Language) {
        prefsManager.setLanguage(lang)
        updateTtsLocale(lang)
    }

    fun saveProfile(profile: UserEmergencyProfile) {
        prefsManager.saveProfile(profile)
        _isSettingsOpen.value = false
    }

    fun saveMedicalProfile(medicalProfile: MedicalProfile) {
        prefsManager.saveMedicalProfile(medicalProfile)
    }

    fun setShakeSosEnabled(enabled: Boolean) {
        prefsManager.setShakeSosEnabled(enabled)
        shakeDetector.setEnabled(enabled)
    }

    fun setAudioFeedbackEnabled(enabled: Boolean) {
        prefsManager.setAudioFeedbackEnabled(enabled)
        alarmManager.isAudioEnabled = enabled
    }

    fun startShakeDetection() {
        if (isShakeSosEnabled.value) {
            shakeDetector.startListening()
        }
    }

    fun stopShakeDetection() {
        shakeDetector.stopListening()
    }

    fun triggerShakeSos() {
        if (_shakeSosCountdown.value != null || _sosCountdown.value != null) return
        shakeCountdownJob?.cancel()
        _shakeSosCountdown.value = 5

        speak(
            if (language.value == Language.TELUGU) "ఫోన్ షేక్ గుర్తించబడింది. 5 సెకన్లలో ఎస్ఓఎస్."
            else "Phone shake detected. Emergency SOS triggering in 5 seconds."
        )

        shakeCountdownJob = viewModelScope.launch {
            for (sec in 5 downTo 1) {
                _shakeSosCountdown.value = sec
                delay(1000)
            }
            _shakeSosCountdown.value = null
            executeSosNow(getApplication<Application>())
        }
    }

    fun cancelShakeSos() {
        shakeCountdownJob?.cancel()
        shakeCountdownJob = null
        _shakeSosCountdown.value = null
        speak(
            if (language.value == Language.TELUGU) "షేక్ ఎస్ఓఎస్ రద్దు చేయబడింది"
            else "Shake SOS cancelled"
        )
    }

    fun openOfflineSmsDialog() {
        _isOfflineSmsDialogOpen.value = true
    }

    fun closeOfflineSmsDialog() {
        _isOfflineSmsDialogOpen.value = false
    }

    fun openMedicalEditDialog() {
        _isMedicalEditDialogOpen.value = true
    }

    fun closeMedicalEditDialog() {
        _isMedicalEditDialogOpen.value = false
    }

    fun sendOfflineSms(context: Context, recipientPhone: String, message: String) {
        _isOfflineSmsDialogOpen.value = false
        EmergencyActions.sendSmsToContact(context, recipientPhone, message)
    }

    fun setSettingsOpen(open: Boolean) {
        _isSettingsOpen.value = open
    }

    fun refreshLocation() {
        viewModelScope.launch {
            _locationState.value = _locationState.value.copy(isLoading = true, errorMessage = null)
            val updated = locationHelper.getCurrentLocation()
            _locationState.value = updated
            if (updated.latitude != null && updated.longitude != null) {
                offlineMapsRepo.recalculateDistances(updated.latitude, updated.longitude)
            }
        }
    }

    fun cacheCurrentArea(customName: String? = null) {
        viewModelScope.launch {
            _isCachingArea.value = true
            val loc = _locationState.value
            val lat = loc.latitude ?: 17.4399
            val lng = loc.longitude ?: 78.3908
            val addr = loc.address ?: "Current Location Area"

            delay(500) // Brief UI feedback
            offlineMapsRepo.cacheCurrentArea(
                latitude = lat,
                longitude = lng,
                address = addr,
                customName = customName
            )
            offlineMapsRepo.recalculateDistances(lat, lng)
            _isCachingArea.value = false

            speak(
                if (language.value == Language.TELUGU) "ప్రాంతం విజయవంతంగా ఆఫ్‌లైన్ కోసం సేవ్ చేయబడింది"
                else "Area cached successfully for offline use"
            )
        }
    }

    fun selectMapArea(areaId: String) {
        offlineMapsRepo.selectArea(areaId)
        val loc = _locationState.value
        offlineMapsRepo.recalculateDistances(loc.latitude, loc.longitude)
    }

    fun deleteMapArea(areaId: String) {
        offlineMapsRepo.deleteArea(areaId)
    }

    fun startSosCountdown(context: Context) {
        if (_sosCountdown.value != null) return
        countdownJob?.cancel()
        _sosCountdown.value = 3

        speak(
            if (language.value == Language.TELUGU) "అత్యవసర సహాయం 3 సెకన్లలో ప్రారంభమవుతుంది"
            else "Emergency SOS triggering in three seconds"
        )

        countdownJob = viewModelScope.launch {
            for (sec in 3 downTo 1) {
                _sosCountdown.value = sec
                delay(1000)
            }
            _sosCountdown.value = null
            executeSosNow(context)
        }
    }

    fun cancelSosCountdown() {
        countdownJob?.cancel()
        countdownJob = null
        _sosCountdown.value = null
        speak(
            if (language.value == Language.TELUGU) "ఎస్ఓఎస్ రద్దు చేయబడింది"
            else "SOS cancelled"
        )
    }

    fun executeSosNow(context: Context) {
        _sosCountdown.value = null
        // Trigger loud siren
        if (!_isSirenActive.value) {
            toggleSiren()
        }
        // Also trigger strobe
        if (!_isStrobeActive.value) {
            toggleStrobe()
        }

        val profile = userProfile.value
        val message = readySosMessage.value

        // If user has a primary emergency contact, send SMS
        if (profile.primaryContact.phone.isNotBlank()) {
            EmergencyActions.sendSmsToContact(
                context = context,
                phoneNumber = profile.primaryContact.phone,
                message = message
            )
        } else {
            // General share chooser
            EmergencyActions.shareSosMessage(context, message)
        }

        speak(
            if (language.value == Language.TELUGU) "అత్యవసర సందేశం పంపబడింది. సైరన్ మోగుతోంది."
            else "Emergency alert sent. Alarm is sounding."
        )
    }

    fun toggleSiren() {
        alarmManager.toggleSiren { isPlaying ->
            _isSirenActive.value = isPlaying
        }
    }

    fun toggleStrobe() {
        alarmManager.toggleStrobe { isPlaying ->
            _isStrobeActive.value = isPlaying
        }
    }

    fun toggleVoiceService(context: Context) {
        val newState = !isVoiceServiceActive.value
        prefsManager.setVoiceServiceActive(newState)
        if (newState) {
            VoiceEmergencyService.start(context)
            speak(
                if (language.value == Language.TELUGU) "లైఫ్ సేవర్ వాయిస్ సర్వీస్ ఆన్ చేయబడింది"
                else "Life Saver voice service activated"
            )
        } else {
            VoiceEmergencyService.stop(context)
            speak(
                if (language.value == Language.TELUGU) "వాయిస్ సర్వీస్ ఆఫ్ చేయబడింది"
                else "Voice service stopped"
            )
        }
    }

    fun startListeningInApp(context: Context) {
        if (_isListening.value) {
            stopListeningInApp()
            return
        }

        try {
            if (inAppSpeechRecognizer == null) {
                inAppSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(this@LifeSaverViewModel)
                }
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                val langTag = if (language.value == Language.TELUGU) "te-IN" else "en-US"
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Say 'Life Saver', 'Ambulance', or 'Send SOS'")
            }

            _voiceRecognizedText.value = ""
            _voiceFeedback.value = if (language.value == Language.TELUGU) "వింటోంది... 'లైఫ్ సేవర్' లేదా ఆదేశం చెప్పండి"
            else "Listening... Say 'Life Saver' or your command"
            _isListening.value = true

            inAppSpeechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isListening.value = false
            _voiceFeedback.value = "Speech recognition error: ${e.message}"
        }
    }

    fun stopListeningInApp() {
        _isListening.value = false
        try {
            inAppSpeechRecognizer?.stopListening()
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun handleVoiceCommand(spokenText: String) {
        val lower = spokenText.lowercase(Locale.ROOT)
        val context = getApplication<Application>()

        when {
            lower.contains("life saver") || lower.contains("లైఫ్ సేవర్") -> {
                val reply = if (language.value == Language.TELUGU)
                    "లైఫ్ సేవర్ సిద్ధంగా ఉంది! అంబులెన్స్, 112, లేదా ఎస్ఓఎస్ చెప్పండి."
                else
                    "Life Saver is ready! Say Ambulance, 112, or Send SOS."
                _voiceFeedback.value = reply
                speak(reply)
            }
            lower.contains("ambulance") || lower.contains("108") || lower.contains("అంబులెన్స్") -> {
                val reply = if (language.value == Language.TELUGU) "108 అంబులెన్స్ కాల్ చేయబడుతోంది" else "Dialing 108 Ambulance"
                _voiceFeedback.value = reply
                speak(reply)
                EmergencyActions.dialEmergency(context, "108")
            }
            lower.contains("police") || lower.contains("112") || lower.contains("పోలీస్") -> {
                val reply = if (language.value == Language.TELUGU) "112 అత్యవసర నంబర్ కాల్ చేయబడుతోంది" else "Dialing 112 National Emergency"
                _voiceFeedback.value = reply
                speak(reply)
                EmergencyActions.dialEmergency(context, "112")
            }
            lower.contains("fire") || lower.contains("101") || lower.contains("ఫైర్") -> {
                val reply = if (language.value == Language.TELUGU) "101 ఫైర్ బ్రిగేడ్ కాల్ చేయబడుతోంది" else "Dialing 101 Fire Brigade"
                _voiceFeedback.value = reply
                speak(reply)
                EmergencyActions.dialEmergency(context, "101")
            }
            lower.contains("hospital") || lower.contains("ఆసుపత్రి") -> {
                val reply = if (language.value == Language.TELUGU) "సమీప ఆసుపత్రులు తెరవబడుతున్నాయి" else "Opening nearby hospitals on Google Maps"
                _voiceFeedback.value = reply
                speak(reply)
                EmergencyActions.openNearbyHospitals(context, locationState.value.latitude, locationState.value.longitude)
            }
            lower.contains("where am i") || lower.contains("location") || lower.contains("లొకేషన్") || lower.contains("ఎక్కడ") -> {
                val loc = locationState.value
                val reply = if (loc.isValid) {
                    if (language.value == Language.TELUGU) "మీ ప్రస్తుత లొకేషన్: ${loc.address ?: "కోఆర్డినేట్స్ రికార్డ్ చేయబడ్డాయి"}"
                    else "Your location is: ${loc.address ?: "Coordinates: %.4f, %.4f".format(loc.latitude, loc.longitude)}"
                } else {
                    if (language.value == Language.TELUGU) "లొకేషన్ అందుబాటులో లేదు. GPS రిఫ్రెష్ చేయండి."
                    else "Location not available yet. Please refresh GPS."
                }
                _voiceFeedback.value = reply
                speak(reply)
            }
            lower.contains("sos") || lower.contains("help") || lower.contains("సహాయం") || lower.contains("కాపాడండి") -> {
                val reply = if (language.value == Language.TELUGU) "ఎస్ఓఎస్ ప్రారంభించబడుతోంది!" else "Triggering SOS alert!"
                _voiceFeedback.value = reply
                speak(reply)
                startSosCountdown(context)
            }
            else -> {
                val reply = if (language.value == Language.TELUGU)
                    "ఆదేశం అర్థం కాలేదు. 'Life Saver', 'అంబులెన్స్' లేదా 'సహాయం' చెప్పండి."
                else
                    "Command not recognized. Say 'Life Saver', 'Ambulance', or 'Send SOS'."
                _voiceFeedback.value = reply
                speak(reply)
            }
        }
    }

    private fun speak(text: String) {
        if (!isAudioFeedbackEnabled.value) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "life_saver_in_app")
    }

    private fun updateTtsLocale(lang: Language) {
        val loc = if (lang == Language.TELUGU) Locale("te", "IN") else Locale.US
        val res = tts?.setLanguage(loc)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            updateTtsLocale(language.value)
        }
    }

    override fun onResults(results: Bundle?) {
        _isListening.value = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spoken = matches[0]
            _voiceRecognizedText.value = spoken
            handleVoiceCommand(spoken)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            _voiceRecognizedText.value = matches[0]
        }
    }

    override fun onError(error: Int) {
        _isListening.value = false
        _voiceFeedback.value = "Voice input stopped or timed out."
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {
        _isListening.value = false
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onCleared() {
        countdownJob?.cancel()
        shakeCountdownJob?.cancel()
        shakeDetector.stopListening()
        alarmManager.releaseAll()
        batteryMonitor.stopMonitoring()
        try {
            inAppSpeechRecognizer?.destroy()
        } catch (e: Exception) {
            // Ignore
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // Ignore
        }
        try {
            getApplication<Application>().unregisterReceiver(voiceCommandReceiver)
        } catch (e: Exception) {
            // Ignore
        }
        super.onCleared()
    }
}
