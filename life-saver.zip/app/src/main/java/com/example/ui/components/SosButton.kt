package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.EmergencyRedBright
import com.example.ui.theme.EmergencyRedDark
import com.example.ui.theme.ImmersiveBackground
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveRedActive
import com.example.ui.theme.ImmersiveRedBorder
import com.example.ui.theme.ImmersiveRedGlow
import com.example.ui.theme.ImmersiveRedSos
import com.example.ui.theme.ImmersiveRedText
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceCard
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings

@Composable
fun SosButtonSection(
    lang: Language,
    countdown: Int?,
    isSirenActive: Boolean,
    isStrobeActive: Boolean,
    onSosClick: () -> Unit,
    onCancelSos: () -> Unit,
    onToggleSiren: () -> Unit,
    onToggleStrobe: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sos_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.16f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sos_pulse_scale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("sos_section_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = ImmersiveSurfaceCard
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (countdown != null) {
                // Countdown Active View
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .background(ImmersiveRedSos)
                        .border(8.dp, ImmersiveRedBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$countdown",
                            fontSize = 64.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = EmergencyStrings.sosTriggeringIn(lang, countdown),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveRedText,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onCancelSos,
                    colors = ButtonDefaults.buttonColors(containerColor = ImmersiveSurfaceVariant),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .testTag("cancel_sos_button")
                        .height(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel",
                        tint = ImmersiveRedText
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = EmergencyStrings.cancel(lang),
                        fontWeight = FontWeight.Black,
                        color = ImmersiveRedText,
                        fontSize = 16.sp
                    )
                }
            } else {
                // Primary Large Red SEND SOS Button with Immersive UI ping & glow
                Box(
                    modifier = Modifier
                        .size(230.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer pulsating glowing aura
                    Box(
                        modifier = Modifier
                            .size(220.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(ImmersiveRedSos.copy(alpha = 0.15f))
                    )

                    // Secondary glow ring
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .clip(CircleShape)
                            .background(ImmersiveRedGlow)
                    )

                    // Main interactive button: w-56 h-56 bg-[#B3261E] border-8 border-[#FFB4AB]/20
                    Box(
                        modifier = Modifier
                            .size(185.dp)
                            .clip(CircleShape)
                            .background(ImmersiveRedSos)
                            .border(8.dp, ImmersiveRedBorder, CircleShape)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                onClick = onSosClick
                            )
                            .testTag("send_sos_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "SOS Alert",
                                tint = Color.White,
                                modifier = Modifier.size(46.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = EmergencyStrings.sendSos(lang),
                                fontSize = if (lang == Language.TELUGU) 20.sp else 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 6.dp)
                            )
                            Text(
                                text = EmergencyStrings.tapToTrigger(lang),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.85f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Siren & Strobe controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Siren Toggle
                OutlinedButton(
                    onClick = onToggleSiren,
                    modifier = Modifier
                        .testTag("toggle_siren_button")
                        .weight(1f)
                        .height(46.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isSirenActive) ImmersiveLavender else ImmersiveSurfaceVariant,
                        contentColor = if (isSirenActive) Color(0xFF381E72) else ImmersiveTextPrimary
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = EmergencyStrings.sirenAlarm(lang),
                        tint = if (isSirenActive) Color(0xFF381E72) else ImmersiveLavender,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = EmergencyStrings.sirenAlarm(lang),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSirenActive) Color(0xFF381E72) else ImmersiveTextPrimary
                    )
                }

                // Strobe Flashlight Toggle
                OutlinedButton(
                    onClick = onToggleStrobe,
                    modifier = Modifier
                        .testTag("toggle_strobe_button")
                        .weight(1f)
                        .height(46.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isStrobeActive) Color.White else ImmersiveSurfaceVariant,
                        contentColor = if (isStrobeActive) Color.Black else ImmersiveTextPrimary
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = EmergencyStrings.strobeLight(lang),
                        tint = if (isStrobeActive) Color.Black else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = EmergencyStrings.strobeLight(lang),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isStrobeActive) Color.Black else ImmersiveTextPrimary
                    )
                }
            }
        }
    }
}
