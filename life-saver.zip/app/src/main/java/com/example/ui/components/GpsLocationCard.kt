package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GpsLocationState
import com.example.model.Language
import com.example.ui.theme.EmergencyAlertYellow
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.ImmersiveActiveGreen
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveHospitalBlue
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveRedBorder
import com.example.ui.theme.ImmersiveRedSos
import com.example.ui.theme.ImmersiveRedText
import com.example.ui.theme.ImmersiveSurfaceCard
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.util.EmergencyStrings

@Composable
fun GpsLocationCard(
    lang: Language,
    locationState: GpsLocationState,
    sosMessageText: String,
    onRefreshLocation: () -> Unit,
    onCopyMessage: () -> Unit,
    onShareAll: () -> Unit,
    onSendSms: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("gps_location_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = ImmersiveSurfaceCard
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(ImmersiveSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "GPS",
                            tint = ImmersiveActiveGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = EmergencyStrings.locationTitle(lang),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveTextPrimary
                        )
                        if (locationState.accuracy != null) {
                            Text(
                                text = EmergencyStrings.accuracy(lang, locationState.accuracy),
                                fontSize = 11.sp,
                                color = ImmersiveLavender
                            )
                        }
                    }
                }

                // Refresh Button
                OutlinedButton(
                    onClick = onRefreshLocation,
                    modifier = Modifier
                        .testTag("refresh_gps_button")
                        .height(36.dp),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = ImmersiveSurfaceVariant,
                        contentColor = ImmersiveTextPrimary
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder)
                ) {
                    if (locationState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = ImmersiveLavender,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            modifier = Modifier.size(15.dp),
                            tint = ImmersiveLavender
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = EmergencyStrings.refreshLocation(lang),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ImmersiveTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Location coordinates / address readout
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ImmersiveSurfaceVariant.copy(alpha = 0.5f))
                    .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
                    .padding(12.dp)
            ) {
                if (locationState.isLoading) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = ImmersiveLavender,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = EmergencyStrings.fetchingLocation(lang),
                            fontSize = 13.sp,
                            color = ImmersiveTextSecondary
                        )
                    }
                } else if (locationState.isValid) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "LAT: ${"%.5f".format(locationState.latitude)}",
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = ImmersiveHospitalBlue
                            )
                            Text(
                                text = "LNG: ${"%.5f".format(locationState.longitude)}",
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = ImmersiveHospitalBlue
                            )
                        }
                        if (!locationState.address.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "📍 ${locationState.address}",
                                fontSize = 12.sp,
                                color = ImmersiveTextPrimary
                            )
                        }
                        if (locationState.timestampFormatted.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "🕒 ${locationState.timestampFormatted}",
                                fontSize = 11.sp,
                                color = ImmersiveTextSecondary
                            )
                        }
                    }
                } else {
                    Text(
                        text = locationState.errorMessage ?: EmergencyStrings.locationUnavailable(lang),
                        fontSize = 12.sp,
                        color = ImmersiveRedText
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Ready-to-share SOS message preview box
            Text(
                text = EmergencyStrings.sosMessageHeader(lang),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = ImmersiveLavender
            )

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ImmersiveSurfaceVariant.copy(alpha = 0.4f))
                    .border(1.dp, ImmersiveRedBorder, RoundedCornerShape(16.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = sosMessageText,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        color = ImmersiveRedText,
                        fontFamily = FontFamily.SansSerif
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = onCopyMessage,
                            modifier = Modifier
                                .testTag("copy_sos_message_button")
                                .height(32.dp),
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = ImmersiveSurfaceVariant,
                                contentColor = ImmersiveTextPrimary
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                modifier = Modifier.size(14.dp),
                                tint = ImmersiveLavender
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = EmergencyStrings.copyMessage(lang),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ImmersiveTextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Share buttons (WhatsApp / All and SMS Contact)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onShareAll,
                    modifier = Modifier
                        .testTag("share_sos_all_button")
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ImmersiveActiveGreen
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = EmergencyStrings.shareWhatsAppAll(lang),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Button(
                    onClick = onSendSms,
                    modifier = Modifier
                        .testTag("send_sos_sms_button")
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ImmersiveRedSos
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "SMS",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = EmergencyStrings.sendSmsContact(lang),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
