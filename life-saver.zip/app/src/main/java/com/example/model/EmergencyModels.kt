package com.example.model

enum class Language(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    TELUGU("te", "Telugu", "తెలుగు")
}

data class EmergencyContact(
    val name: String = "",
    val phone: String = ""
)

data class MedicalProfile(
    val bloodGroup: String = "",
    val allergies: String = "",
    val medications: String = "",
    val medicalConditions: String = "",
    val emergencyNotes: String = ""
) {
    val isConfigured: Boolean
        get() = bloodGroup.isNotBlank() || allergies.isNotBlank() || medications.isNotBlank() || medicalConditions.isNotBlank() || emergencyNotes.isNotBlank()
}

data class UserEmergencyProfile(
    val myPhoneNumber: String = "",
    val primaryContact: EmergencyContact = EmergencyContact(),
    val secondaryContact: EmergencyContact = EmergencyContact(),
    val customNote: String = "",
    val medicalProfile: MedicalProfile = MedicalProfile()
)

data class GpsLocationState(
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accuracy: Float? = null,
    val address: String? = null,
    val timestampFormatted: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null
) {
    val isValid: Boolean get() = latitude != null && longitude != null
    val mapsUrl: String get() = if (isValid) "https://maps.google.com/?q=$latitude,$longitude" else ""
}

data class VoiceState(
    val isListening: Boolean = false,
    val recognizedText: String = "",
    val assistantFeedback: String = "",
    val isServiceActive: Boolean = false,
    val errorMessage: String? = null
)
