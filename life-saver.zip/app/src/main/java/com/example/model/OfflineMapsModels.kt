package com.example.model

enum class PlaceType(val displayName: String, val iconLabel: String) {
    HOSPITAL("Hospital / Trauma", "🏥"),
    POLICE("Police Station", "👮"),
    FIRE("Fire & Rescue", "🚒")
}

data class CachedEmergencyPlace(
    val id: String,
    val name: String,
    val type: PlaceType,
    val phone: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val distanceKm: Double = 0.0,
    val bearingDegrees: Float = 0f
)

data class OfflineMapArea(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val cachedAtTimestamp: Long,
    val radiusKm: Double = 10.0,
    val places: List<CachedEmergencyPlace> = emptyList(),
    val isOfflineAvailable: Boolean = true,
    val notes: String = ""
)
