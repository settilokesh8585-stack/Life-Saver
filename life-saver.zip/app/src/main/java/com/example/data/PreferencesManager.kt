package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.EmergencyContact
import com.example.model.Language
import com.example.model.MedicalProfile
import com.example.model.UserEmergencyProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfile())
    val userProfile: StateFlow<UserEmergencyProfile> = _userProfile.asStateFlow()

    private val _language = MutableStateFlow(loadLanguage())
    val language: StateFlow<Language> = _language.asStateFlow()

    private val _isVoiceServiceActive = MutableStateFlow(prefs.getBoolean(KEY_VOICE_SERVICE, false))
    val isVoiceServiceActive: StateFlow<Boolean> = _isVoiceServiceActive.asStateFlow()

    private val _isShakeSosEnabled = MutableStateFlow(prefs.getBoolean(KEY_SHAKE_SOS_ENABLED, false))
    val isShakeSosEnabled: StateFlow<Boolean> = _isShakeSosEnabled.asStateFlow()

    private val _isAudioFeedbackEnabled = MutableStateFlow(prefs.getBoolean(KEY_AUDIO_FEEDBACK_ENABLED, true))
    val isAudioFeedbackEnabled: StateFlow<Boolean> = _isAudioFeedbackEnabled.asStateFlow()

    private fun loadProfile(): UserEmergencyProfile {
        return UserEmergencyProfile(
            myPhoneNumber = prefs.getString(KEY_MY_PHONE, "") ?: "",
            primaryContact = EmergencyContact(
                name = prefs.getString(KEY_PRIMARY_NAME, "") ?: "",
                phone = prefs.getString(KEY_PRIMARY_PHONE, "") ?: ""
            ),
            secondaryContact = EmergencyContact(
                name = prefs.getString(KEY_SECONDARY_NAME, "") ?: "",
                phone = prefs.getString(KEY_SECONDARY_PHONE, "") ?: ""
            ),
            customNote = prefs.getString(KEY_CUSTOM_NOTE, "") ?: "",
            medicalProfile = MedicalProfile(
                bloodGroup = prefs.getString(KEY_BLOOD_GROUP, "") ?: "",
                allergies = prefs.getString(KEY_ALLERGIES, "") ?: "",
                medications = prefs.getString(KEY_MEDICATIONS, "") ?: "",
                medicalConditions = prefs.getString(KEY_MEDICAL_CONDITIONS, "") ?: "",
                emergencyNotes = prefs.getString(KEY_MEDICAL_NOTES, "") ?: ""
            )
        )
    }

    private fun loadLanguage(): Language {
        val code = prefs.getString(KEY_LANGUAGE, Language.ENGLISH.code) ?: Language.ENGLISH.code
        return if (code == Language.TELUGU.code) Language.TELUGU else Language.ENGLISH
    }

    fun saveProfile(profile: UserEmergencyProfile) {
        prefs.edit()
            .putString(KEY_MY_PHONE, profile.myPhoneNumber)
            .putString(KEY_PRIMARY_NAME, profile.primaryContact.name)
            .putString(KEY_PRIMARY_PHONE, profile.primaryContact.phone)
            .putString(KEY_SECONDARY_NAME, profile.secondaryContact.name)
            .putString(KEY_SECONDARY_PHONE, profile.secondaryContact.phone)
            .putString(KEY_CUSTOM_NOTE, profile.customNote)
            .putString(KEY_BLOOD_GROUP, profile.medicalProfile.bloodGroup)
            .putString(KEY_ALLERGIES, profile.medicalProfile.allergies)
            .putString(KEY_MEDICATIONS, profile.medicalProfile.medications)
            .putString(KEY_MEDICAL_CONDITIONS, profile.medicalProfile.medicalConditions)
            .putString(KEY_MEDICAL_NOTES, profile.medicalProfile.emergencyNotes)
            .apply()
        _userProfile.value = profile
    }

    fun saveMedicalProfile(medicalProfile: MedicalProfile) {
        val current = _userProfile.value
        val updated = current.copy(medicalProfile = medicalProfile)
        saveProfile(updated)
    }

    fun setLanguage(language: Language) {
        prefs.edit().putString(KEY_LANGUAGE, language.code).apply()
        _language.value = language
    }

    fun setVoiceServiceActive(active: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_SERVICE, active).apply()
        _isVoiceServiceActive.value = active
    }

    fun setShakeSosEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SHAKE_SOS_ENABLED, enabled).apply()
        _isShakeSosEnabled.value = enabled
    }

    fun setAudioFeedbackEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUDIO_FEEDBACK_ENABLED, enabled).apply()
        _isAudioFeedbackEnabled.value = enabled
    }

    companion object {
        private const val PREF_NAME = "life_saver_prefs"
        private const val KEY_MY_PHONE = "key_my_phone"
        private const val KEY_PRIMARY_NAME = "key_primary_name"
        private const val KEY_PRIMARY_PHONE = "key_primary_phone"
        private const val KEY_SECONDARY_NAME = "key_secondary_name"
        private const val KEY_SECONDARY_PHONE = "key_secondary_phone"
        private const val KEY_CUSTOM_NOTE = "key_custom_note"
        private const val KEY_LANGUAGE = "key_language"
        private const val KEY_VOICE_SERVICE = "key_voice_service"

        private const val KEY_SHAKE_SOS_ENABLED = "key_shake_sos_enabled"
        private const val KEY_AUDIO_FEEDBACK_ENABLED = "key_audio_feedback_enabled"
        private const val KEY_BLOOD_GROUP = "key_blood_group"
        private const val KEY_ALLERGIES = "key_allergies"
        private const val KEY_MEDICATIONS = "key_medications"
        private const val KEY_MEDICAL_CONDITIONS = "key_medical_conditions"
        private const val KEY_MEDICAL_NOTES = "key_medical_notes"
    }
}
