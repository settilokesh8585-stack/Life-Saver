package com.example.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.model.GpsLocationState
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

class LocationHelper(private val context: Context) {

    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    fun hasLocationPermission(): Boolean {
        val fineLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseLocation = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fineLocation || coarseLocation
    }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(): GpsLocationState = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) {
            return@withContext GpsLocationState(
                errorMessage = "Location permission is not granted. Please enable GPS permissions."
            )
        }

        try {
            val location = fetchLocationInternal()
            if (location != null) {
                val address = resolveAddress(location.latitude, location.longitude)
                val timeFormat = SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.getDefault())
                val formattedTime = timeFormat.format(Date(location.time.takeIf { it > 0 } ?: System.currentTimeMillis()))

                GpsLocationState(
                    latitude = location.latitude,
                    longitude = location.longitude,
                    accuracy = location.accuracy,
                    address = address,
                    timestampFormatted = formattedTime,
                    isLoading = false,
                    errorMessage = null
                )
            } else {
                GpsLocationState(
                    errorMessage = "Unable to acquire GPS fix. Please ensure device location is turned on."
                )
            }
        } catch (e: Exception) {
            GpsLocationState(
                errorMessage = "Error acquiring location: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun fetchLocationInternal(): Location? = suspendCancellableCoroutine { continuation ->
        val cts = CancellationTokenSource()
        continuation.invokeOnCancellation {
            cts.cancel()
        }

        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    continuation.resume(location)
                } else {
                    // Fallback to last known location
                    fusedLocationClient.lastLocation
                        .addOnSuccessListener { lastLoc ->
                            continuation.resume(lastLoc)
                        }
                        .addOnFailureListener {
                            continuation.resume(null)
                        }
                }
            }
            .addOnFailureListener {
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { lastLoc ->
                        continuation.resume(lastLoc)
                    }
                    .addOnFailureListener {
                        continuation.resume(null)
                    }
            }
    }

    @Suppress("DEPRECATION")
    private fun resolveAddress(latitude: Double, longitude: Double): String? {
        return try {
            val geocoder = Geocoder(context, Locale.getDefault())
            val addresses: List<Address>? = geocoder.getFromLocation(latitude, longitude, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                val parts = mutableListOf<String>()
                addr.subLocality?.let { parts.add(it) }
                addr.locality?.let { parts.add(it) }
                addr.adminArea?.let { parts.add(it) }
                addr.postalCode?.let { parts.add(it) }
                if (parts.isNotEmpty()) parts.joinToString(", ") else addr.getAddressLine(0)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
