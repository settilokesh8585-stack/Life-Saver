package com.example.util

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

class ShakeDetector(
    context: Context,
    private val onShakeDetected: () -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accelerometer: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var isListening = false
    private var isEnabled = false

    private var shakeCount = 0
    private var lastShakeTimestamp: Long = 0
    private var lastEventTriggerTimestamp: Long = 0

    // Strong shake threshold (g-force relative to Earth's gravity)
    // 2.7g ensures regular walking, pocket movement, or setting the phone on a table will not trigger SOS
    private val SHAKE_THRESHOLD_G = 2.7f
    private val SHAKE_SLOP_TIME_MS = 500
    private val SHAKE_COUNT_RESET_TIME_MS = 1500
    private val SHAKE_COOLDOWN_MS = 4000

    fun setEnabled(enabled: Boolean) {
        isEnabled = enabled
        if (!enabled) {
            stopListening()
        } else {
            startListening()
        }
    }

    fun startListening() {
        if (!isEnabled || isListening || accelerometer == null || sensorManager == null) return
        try {
            sensorManager.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_UI
            )
            isListening = true
        } catch (e: Exception) {
            isListening = false
        }
    }

    fun stopListening() {
        if (!isListening || sensorManager == null) return
        try {
            sensorManager.unregisterListener(this)
        } catch (e: Exception) {
            // Ignore
        } finally {
            isListening = false
            shakeCount = 0
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || !isEnabled) return
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        val gX = x / SensorManager.GRAVITY_EARTH
        val gY = y / SensorManager.GRAVITY_EARTH
        val gZ = z / SensorManager.GRAVITY_EARTH

        // Calculate total g-force magnitude
        val gForce = sqrt(gX * gX + gY * gY + gZ * gZ)

        if (gForce > SHAKE_THRESHOLD_G) {
            val now = System.currentTimeMillis()

            // Discard shakes during cooldown
            if (now - lastEventTriggerTimestamp < SHAKE_COOLDOWN_MS) {
                return
            }

            // Reset shake count if too much time has elapsed since previous peak
            if (now - lastShakeTimestamp > SHAKE_COUNT_RESET_TIME_MS) {
                shakeCount = 0
            }

            // Must have a minimal slop time between peak directions to count as a deliberate shake
            if (now - lastShakeTimestamp > 120) {
                lastShakeTimestamp = now
                shakeCount++

                // When 2 deliberate direction peaks are detected within the window, trigger shake SOS
                if (shakeCount >= 2) {
                    shakeCount = 0
                    lastEventTriggerTimestamp = now
                    onShakeDetected()
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No-op
    }
}
