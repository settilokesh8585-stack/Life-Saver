package com.example.util

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat

object EmergencyActions {

    fun dialEmergency(context: Context, number: String) {
        val sanitized = number.trim()
        if (sanitized.isEmpty()) return

        try {
            // Check if CALL_PHONE permission is granted for direct call, otherwise open dialer
            val hasCallPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED

            val intent = if (hasCallPermission) {
                Intent(Intent.ACTION_CALL, Uri.parse("tel:$sanitized"))
            } else {
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$sanitized"))
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to dialer
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$sanitized")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(dialIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "Could not open dialer: ${ex.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun sendSmsToContact(context: Context, phoneNumber: String, message: String) {
        val sanitized = phoneNumber.trim()
        try {
            val uri = if (sanitized.isNotEmpty()) {
                Uri.parse("smsto:$sanitized")
            } else {
                Uri.parse("smsto:")
            }
            val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(smsIntent)
        } catch (e: Exception) {
            // Fallback to general share intent
            shareSosMessage(context, message)
        }
    }

    fun shareSosMessage(context: Context, message: String) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                putExtra(Intent.EXTRA_SUBJECT, "EMERGENCY SOS ALERT")
            }
            val chooser = Intent.createChooser(shareIntent, "Share Emergency SOS Alert").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to share message: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openNearbyHospitals(context: Context, lat: Double?, lng: Double?) {
        openMapsQuery(
            context = context,
            query = "hospitals emergency",
            lat = lat,
            lng = lng
        )
    }

    fun openNearbyPolice(context: Context, lat: Double?, lng: Double?) {
        openMapsQuery(
            context = context,
            query = "police stations",
            lat = lat,
            lng = lng
        )
    }

    private fun openMapsQuery(context: Context, query: String, lat: Double?, lng: Double?) {
        val encodedQuery = Uri.encode(query)
        val geoUriString = if (lat != null && lng != null) {
            "geo:$lat,$lng?q=$encodedQuery"
        } else {
            "geo:0,0?q=$encodedQuery"
        }

        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse(geoUriString)).apply {
            setPackage("com.google.android.apps.maps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            // If Google Maps app is not installed, open via browser URL
            val webUrl = if (lat != null && lng != null) {
                "https://www.google.com/maps/search/$encodedQuery/@$lat,$lng,14z"
            } else {
                "https://www.google.com/maps/search/$encodedQuery"
            }
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(browserIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "Could not open Google Maps: ${ex.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun copyToClipboard(context: Context, text: String, toastMessage: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = ClipData.newPlainText("Life Saver SOS", text)
        clipboard?.setPrimaryClip(clip)
        Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
    }
}
