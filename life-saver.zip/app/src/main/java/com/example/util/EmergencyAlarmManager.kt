package com.example.util

import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

class EmergencyAlarmManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var sirenJob: Job? = null
    private var strobeJob: Job? = null

    private var audioTrack: AudioTrack? = null
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private var rearCameraId: String? = null

    init {
        try {
            rearCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val hasFlash = chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                hasFlash
            }
        } catch (e: Exception) {
            rearCameraId = null
        }
    }

    var isSirenPlaying: Boolean = false
        private set

    var isStrobePlaying: Boolean = false
        private set

    var isAudioEnabled: Boolean = true

    fun toggleSiren(onStateChanged: (Boolean) -> Unit) {
        if (isSirenPlaying) {
            stopSiren()
        } else {
            startSiren()
        }
        onStateChanged(isSirenPlaying)
    }

    fun startSiren() {
        if (isSirenPlaying) return
        isSirenPlaying = true

        if (!isAudioEnabled) {
            // Audio feedback disabled in settings: visual alert remains active without sound
            return
        }

        sirenJob = scope.launch {
            try {
                val sampleRate = 44100
                val minBufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufferSize * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack = track
                track.play()

                // Oscillate between 700Hz and 1400Hz (classic emergency ambulance / fire siren)
                var currentFreq = 700.0
                var goingUp = true
                val buffer = ShortArray(1024)
                var phase = 0.0

                while (isActive && isSirenPlaying) {
                    for (i in buffer.indices) {
                        buffer[i] = (sin(phase) * Short.MAX_VALUE * 0.9).toInt().toShort()
                        phase += 2 * Math.PI * currentFreq / sampleRate
                        if (phase > 2 * Math.PI) phase -= 2 * Math.PI
                    }
                    track.write(buffer, 0, buffer.size)

                    if (goingUp) {
                        currentFreq += 15.0
                        if (currentFreq >= 1400.0) goingUp = false
                    } else {
                        currentFreq -= 15.0
                        if (currentFreq <= 700.0) goingUp = true
                    }
                }
            } catch (e: Exception) {
                // Ignore audio errors gracefully
            } finally {
                cleanupAudioTrack()
            }
        }
    }

    fun stopSiren() {
        isSirenPlaying = false
        sirenJob?.cancel()
        sirenJob = null
        cleanupAudioTrack()
    }

    private fun cleanupAudioTrack() {
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            // Ignore
        }
        audioTrack = null
    }

    fun toggleStrobe(onStateChanged: (Boolean) -> Unit) {
        if (isStrobePlaying) {
            stopStrobe()
        } else {
            startStrobe()
        }
        onStateChanged(isStrobePlaying)
    }

    fun startStrobe() {
        val camId = rearCameraId ?: return
        if (isStrobePlaying) return
        isStrobePlaying = true

        strobeJob = scope.launch {
            try {
                while (isActive && isStrobePlaying) {
                    // Flash SOS pattern: 3 rapid, 3 slow, 3 rapid
                    repeat(3) {
                        setTorch(camId, true)
                        delay(120)
                        setTorch(camId, false)
                        delay(120)
                    }
                    delay(200)
                    repeat(3) {
                        setTorch(camId, true)
                        delay(350)
                        setTorch(camId, false)
                        delay(200)
                    }
                    delay(200)
                    repeat(3) {
                        setTorch(camId, true)
                        delay(120)
                        setTorch(camId, false)
                        delay(120)
                    }
                    delay(700)
                }
            } catch (e: Exception) {
                // Torch mode might fail on some devices
            } finally {
                setTorch(camId, false)
            }
        }
    }

    fun stopStrobe() {
        isStrobePlaying = false
        strobeJob?.cancel()
        strobeJob = null
        rearCameraId?.let { setTorch(it, false) }
    }

    private fun setTorch(camId: String, enabled: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager?.setTorchMode(camId, enabled)
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun releaseAll() {
        stopSiren()
        stopStrobe()
    }
}
