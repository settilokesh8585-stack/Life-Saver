package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.model.Language
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BatteryState(
    val level: Int = 100,
    val isCharging: Boolean = false,
    val isLow: Boolean = false,       // level < 20
    val isCritical: Boolean = false,  // level < 10
    val statusText: String = "Normal"
)

class BatteryMonitor(private val context: Context) {

    private val _batteryState = MutableStateFlow(BatteryState())
    val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

    private var isReceiverRegistered = false
    private var lastNotifiedThreshold: Int = 100 // To prevent duplicate notification spam

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                updateBatteryFromIntent(intent)
            }
        }
    }

    init {
        createNotificationChannel()
        // Sticky query: ACTION_BATTERY_CHANGED can be read synchronously without waiting for broadcast
        val stickyIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (stickyIntent != null) {
            updateBatteryFromIntent(stickyIntent)
        }
    }

    fun startMonitoring() {
        if (!isReceiverRegistered) {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            context.registerReceiver(batteryReceiver, filter)
            isReceiverRegistered = true
        }
    }

    fun stopMonitoring() {
        if (isReceiverRegistered) {
            try {
                context.unregisterReceiver(batteryReceiver)
            } catch (e: Exception) {
                // Receiver might not be registered
            }
            isReceiverRegistered = false
        }
    }

    private fun updateBatteryFromIntent(intent: Intent) {
        val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val percentage = if (rawLevel >= 0 && scale > 0) {
            (rawLevel * 100) / scale
        } else {
            100
        }

        val isCritical = percentage < 10 && !isCharging
        val isLow = percentage < 20 && !isCharging

        val statusText = when {
            isCharging -> "Charging ($percentage%)"
            isCritical -> "CRITICAL (< 10%)"
            isLow -> "LOW (< 20%)"
            else -> "Normal ($percentage%)"
        }

        _batteryState.value = BatteryState(
            level = percentage,
            isCharging = isCharging,
            isLow = isLow,
            isCritical = isCritical,
            statusText = statusText
        )

        // Notification triggers
        checkAndTriggerNotifications(percentage, isCharging, isLow, isCritical)
    }

    private fun checkAndTriggerNotifications(
        level: Int,
        isCharging: Boolean,
        isLow: Boolean,
        isCritical: Boolean
    ) {
        if (isCharging) {
            // Reset threshold when user plugs in charger
            lastNotifiedThreshold = 100
            return
        }

        if (isCritical && lastNotifiedThreshold > 10) {
            lastNotifiedThreshold = 10
            showNotification(
                notificationId = NOTIF_ID_CRITICAL,
                title = "🚨 CRITICAL BATTERY: $level% - Shutdown Imminent!",
                body = "Battery is critically low! Tap to open Life Saver and send an SOS or share your location before device shuts down.",
                isCritical = true
            )
        } else if (isLow && !isCritical && lastNotifiedThreshold > 20) {
            lastNotifiedThreshold = 20
            showNotification(
                notificationId = NOTIF_ID_LOW,
                title = "⚠️ Low Battery Warning: $level%",
                body = "Your phone battery has dropped below 20%. Please conserve battery or share your emergency coordinates with family.",
                isCritical = false
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Emergency Battery Level Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Warns when device battery is critically low during emergencies"
                enableVibration(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    private fun showNotification(
        notificationId: Int,
        title: String,
        body: String,
        isCritical: Boolean
    ) {
        try {
            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingOpen = PendingIntent.getActivity(
                context,
                notificationId,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val sosIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("TRIGGER_SOS_NOW", true)
            }
            val pendingSos = PendingIntent.getActivity(
                context,
                notificationId + 100,
                sosIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(if (isCritical) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingOpen)
                .addAction(
                    android.R.drawable.ic_dialog_alert,
                    "SEND SOS NOW",
                    pendingSos
                )

            val notificationManager = NotificationManagerCompat.from(context)
            if (notificationManager.areNotificationsEnabled()) {
                notificationManager.notify(notificationId, builder.build())
            }
        } catch (e: Exception) {
            // Notification dispatch may fail if permission is revoked
        }
    }

    companion object {
        private const val CHANNEL_ID = "lifesaver_battery_alerts"
        private const val NOTIF_ID_LOW = 2001
        private const val NOTIF_ID_CRITICAL = 2002
    }
}
